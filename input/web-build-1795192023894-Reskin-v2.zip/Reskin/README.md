# Reskin

Android app (Kotlin + Jetpack Compose, dark only, SF Pro Display) that makes an edited copy of
any installed app with a new name and icon. The original is never touched.

## Run
1. Open this folder in Android Studio (Koala or newer), let Gradle sync (needs internet once).
2. Run on a device (Android 8.0+). First create asks you to allow "install unknown apps" for Reskin.

## How it works
`engine/ApkPatcher` (ARSCLib) renames package, label, icon, provider authorities and custom
permissions -> `ZipAligner` -> `ApkSignerHelper` (apksig, self-signed key made on first use)
-> `ApkInstaller` (PackageInstaller session, split APKs supported).

## Libraries
- ARSCLib 1.4.0 from Maven Central: io.github.reandroid:ARSCLib (manifest + resources.arsc editing)
- apksig 8.5.2, BouncyCastle bcpkix 1.78.1, Compose BOM 2024.09.03

## Known limits
- The copy has its own data (sign in again). Apps that verify their signature or package name may not open.
- Only the ARSCLib calls in the "ARSCLib shim" block at the bottom of ApkPatcher.kt depend on exact method names.
