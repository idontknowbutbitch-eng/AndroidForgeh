# Notes

A clean notes app (SF Pro Display Medium throughout). Behind the Settings icon is a second, hidden layer: a full web browser.

Android 10+ (minSdk 29). Kotlin, Material 3, WebView, SQLite. No extra dependencies.

## How it works
- **Notes**: create, edit, delete (long-press a note or use the bin), search, autosave, grouped by date. Sort order, text size and theme live in Settings.
- **Open the hidden area**: tap the **Settings (gear) icon three times** quickly. One tap opens the real Settings screen.
- **Browser**: glass-style address pill, blurred wallpaper home page with clock and bookmark shortcuts, floating toolbar. Swipe up on the small grabber (or tap the chevron) to slide up the options sheet: new tab, bookmark, bookmarks, history, downloads, share, desktop site, hide tab, settings, back to Notes, plus text-size and blur sliders. The gear next to the address bar opens browser settings.
- **Browser settings**: choose a gradient or your own photo as the background, blur and dimming, search engine (Google/DuckDuckGo/Bing), text size, clear data.
- **Tabs**: previews, favicons, switch/close, drag the grip to reorder. State is restored after a restart. **Long-press a tab > Hide tab** removes it from the list completely.
- **Hidden tabs** can only be reached in **Browser settings > Developer options**, which asks for the code **1111**. From there you can open, unhide or close them. Hidden tabs save no history, block screenshots, and re-lock when you leave the app.
- The app does not register itself as a web browser with Android and shows as "Notes" everywhere.

## Get an installable APK from a phone only
1. Make a free GitHub account and create a new empty repository.
2. Open it in a browser (Chrome menu > Desktop site) and start a Codespace (Code > Codespaces > Create).
3. In the Codespace Explorer upload `Memo.zip`, then in its terminal run:
   `unzip Memo.zip -d tmp && cp -a tmp/Memo/. . && rm -rf tmp Memo.zip && git add -A && git commit -m init && git push`
4. Open the repo's **Actions** tab > **Build APK** > latest run > download **Memo-debug-apk**.
5. Unzip it in your Files app and open `app-debug.apk` (allow "Install unknown apps" when asked).

## Build on a computer
Open the folder in Android Studio (JDK 17), let Gradle sync, press Run. Or `gradle assembleDebug` (Gradle 8.7) -> `app/build/outputs/apk/debug/app-debug.apk`.

## Notes on behaviour
- Blur: on Android 12+ the wallpaper and the page behind the options sheet use real GPU blur. On Android 10-11 a softened (downscaled) wallpaper is used instead.
- The developer code is fixed at 1111 in `Dialogs.DEV_CODE`. Hidden tab data is stored unencrypted in app-private storage, and WebView shares cookies between tabs.
- Written without an Android SDK available, so it has not been compiled or run here. If the build reports an error, send me the log.
