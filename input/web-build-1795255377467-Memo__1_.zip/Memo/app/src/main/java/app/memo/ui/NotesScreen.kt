package app.memo.ui

import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.memo.MainActivity
import app.memo.R
import app.memo.data.Note

class NotesScreen(act: MainActivity) : Screen(act) {
    private class Row(val head: String?, val note: Note?, val first: Boolean, val last: Boolean)

    private var rows: List<Row> = emptyList()
    private val handler = Handler(Looper.getMainLooper())
    private var taps = 0
    // One tap opens Settings; three quick taps on the same icon open the hidden area.
    private val tapRun = Runnable { if (taps == 1) act.push(NotesSettingsScreen(act)); taps = 0 }
    private val search = EditText(act)
    private val empty = act.label("", 15f, R.color.text2)
    private val countLabel = act.label("", 12f, R.color.text2)
    private val rv = RecyclerView(act)
    private val adapter = NoteAdapter()

    init {
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(act).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(12), 0)
        }
        top.addView(act.iconButton(R.drawable.ic_settings, "Settings", act.getColor(R.color.accent_text)) { onGear() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(act.label("Notes", 36f, R.color.text, true).apply { setPadding(dp(20), 0, dp(20), dp(8)) },
            LinearLayout.LayoutParams(MATCH, WRAP))

        search.apply {
            hint = "Search"
            textSize = 16f
            typeface = Fonts.get(act)
            isSingleLine = true
            setTextColor(act.getColor(R.color.text))
            setHintTextColor(act.getColor(R.color.text2))
            background = act.rounded(act.getColor(R.color.surface), 12)
            setPadding(dp(12), 0, dp(12), 0)
            setCompoundDrawablesRelativeWithIntrinsicBounds(
                act.tinted(R.drawable.ic_search, act.getColor(R.color.text2)), null, null, null)
            compoundDrawablePadding = dp(8)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { v, _, _ -> act.hideKeyboard(v); true }
            onChange { reload() }
        }
        col.addView(search, LinearLayout.LayoutParams(MATCH, dp(42)).apply { setMargins(dp(16), 0, dp(16), dp(4)) })

        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(0, dp(4), 0, dp(80))
        col.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        empty.gravity = Gravity.CENTER
        addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        val bottom = FrameLayout(act).apply { setBackgroundColor(act.getColor(R.color.bg)) }
        bottom.addView(View(act).apply { setBackgroundColor(act.getColor(R.color.divider)) },
            FrameLayout.LayoutParams(MATCH, 1, Gravity.TOP))
        bottom.addView(countLabel, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        bottom.addView(act.iconButton(R.drawable.ic_compose, "New note", act.getColor(R.color.accent_text)) {
            act.push(EditorScreen(act, null))
        }, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(12) })
        addView(bottom, FrameLayout.LayoutParams(MATCH, dp(56), Gravity.BOTTOM))
    }

    private fun onGear() {
        taps++
        handler.removeCallbacks(tapRun)
        if (taps >= 3) {
            taps = 0
            act.showBrowser()
        } else {
            handler.postDelayed(tapRun, 420)
        }
    }

    override fun refresh() {
        super.refresh()
        reload()
    }

    private fun section(ms: Long): String {
        val d = System.currentTimeMillis() - ms
        return when {
            DateUtils.isToday(ms) -> "Today"
            d < 7 * DateUtils.DAY_IN_MILLIS -> "Previous 7 Days"
            d < 30 * DateUtils.DAY_IN_MILLIS -> "Previous 30 Days"
            else -> "Older"
        }
    }

    private fun reload() {
        val q = search.text.toString().trim()
        val notes = act.db.notes(q, act.prefs.sort)
        val list = ArrayList<Row>()
        if (act.prefs.sort == 0 && q.isEmpty()) {
            var cur: String? = null
            notes.forEachIndexed { i, n ->
                val s = section(n.updated)
                var first = false
                if (s != cur) { list.add(Row(s, null, false, false)); cur = s; first = true }
                val nextSame = i + 1 < notes.size && section(notes[i + 1].updated) == s
                list.add(Row(null, n, first, !nextSame))
            }
        } else {
            if (notes.isNotEmpty()) list.add(Row(if (q.isEmpty()) "Notes" else "Results", null, false, false))
            notes.forEachIndexed { i, n -> list.add(Row(null, n, i == 0, i == notes.lastIndex)) }
        }
        rows = list
        adapter.notifyDataSetChanged()
        countLabel.text = "${notes.size} ${if (notes.size == 1) "Note" else "Notes"}"
        empty.text = if (q.isEmpty()) "No notes yet.\nTap the pencil to write one." else "No results."
        empty.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
    }

    private class VH(v: View, val title: TextView?, val sub: TextView?, val divider: View?) : RecyclerView.ViewHolder(v)

    private inner class NoteAdapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = rows.size
        override fun getItemViewType(position: Int) = if (rows[position].head != null) 0 else 1

        override fun onCreateViewHolder(p: ViewGroup, type: Int): VH {
            if (type == 0) {
                val h = act.label("", 18f, R.color.text, true).apply {
                    setPadding(dp(20), dp(18), dp(20), dp(8))
                    layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
                }
                return VH(h, h, null, null)
            }
            val card = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), 0, dp(16), 0) }
            }
            val body = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(11), dp(16), dp(11))
            }
            val title = act.label("", 16f, R.color.text).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            val sub = act.label("", 13.5f, R.color.text2).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(2), 0, 0)
            }
            body.addView(title)
            body.addView(sub)
            val div = View(act).apply { setBackgroundColor(act.getColor(R.color.divider)) }
            card.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))
            card.addView(div, LinearLayout.LayoutParams(MATCH, 1).apply { marginStart = dp(16) })
            return VH(card, title, sub, div)
        }

        override fun onBindViewHolder(h: VH, i: Int) {
            val r = rows[i]
            if (r.head != null) { h.title?.text = r.head; return }
            val n = r.note ?: return
            val firstLine = n.body.lineSequence().firstOrNull { it.isNotBlank() }?.trim() ?: ""
            h.title?.text = n.title.ifBlank { firstLine.ifBlank { "New Note" } }
            val flags = when {
                DateUtils.isToday(n.updated) -> DateUtils.FORMAT_SHOW_TIME
                System.currentTimeMillis() - n.updated < 7 * DateUtils.DAY_IN_MILLIS ->
                    DateUtils.FORMAT_SHOW_WEEKDAY or DateUtils.FORMAT_ABBREV_WEEKDAY
                else -> DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_NUMERIC_DATE or DateUtils.FORMAT_SHOW_YEAR
            }
            val preview = (if (n.title.isBlank()) n.body.trim().removePrefix(firstLine).trim() else n.body.trim()).replace("\n", " ")
            h.sub?.text = DateUtils.formatDateTime(act, n.updated, flags) + "   " + preview.ifBlank { "No additional text" }
            val t = if (r.first) dp(14).toFloat() else 0f
            val b = if (r.last) dp(14).toFloat() else 0f
            h.itemView.background = GradientDrawable().apply {
                setColor(act.getColor(R.color.surface))
                cornerRadii = floatArrayOf(t, t, t, t, b, b, b, b)
            }
            h.divider?.visibility = if (r.last) View.INVISIBLE else View.VISIBLE
            h.itemView.setOnClickListener { act.push(EditorScreen(act, n)) }
            h.itemView.setOnLongClickListener {
                act.confirm("Delete note?", "Delete") { act.db.deleteNote(n.id); reload() }
                true
            }
        }
    }
}
