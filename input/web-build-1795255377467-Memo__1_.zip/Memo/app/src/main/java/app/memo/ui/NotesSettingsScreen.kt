package app.memo.ui

import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatDelegate
import app.memo.MainActivity
import app.memo.R

/** Real notes settings (theme, sorting, text size). */
class NotesSettingsScreen(act: MainActivity) : Screen(act) {
    init {
        val inner = page("Settings", false)
        val p = act.prefs
        inner.addView(act.sectionLabel(false, "Appearance"))
        inner.addView(act.cardView(false,
            act.rowView(false, "Theme", null, act.segmented(listOf("Auto", "Light", "Dark"), p.theme, false) {
                p.theme = it
                act.applyTheme()
            })))
        inner.addView(act.sectionLabel(false, "Notes"))
        inner.addView(act.cardView(false,
            act.rowView(false, "Sort by", null, act.segmented(listOf("Edited", "Created", "Title"), p.sort, false) { p.sort = it }),
            act.rowView(false, "Text size", null, act.segmented(listOf("S", "M", "L"), p.textSize, false) { p.textSize = it })))
        inner.addView(act.sectionLabel(false, "About"))
        inner.addView(act.cardView(false, act.rowView(false, "Notes", "Version 1.0")))
    }
}
