package app.memo.ui

import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.format.DateUtils
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import app.memo.MainActivity
import app.memo.R
import app.memo.data.Note

/** Minimal note editor with debounced autosave. Empty notes are discarded. */
class EditorScreen(act: MainActivity, note: Note?) : Screen(act) {
    private var id = note?.id ?: 0L
    private val title = EditText(act)
    private val body = EditText(act)
    private val status = act.label("", 13f, R.color.text2)
    private val handler = Handler(Looper.getMainLooper())
    private val saveTask = Runnable { save() }
    private var dirty = false

    init {
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), 0)
        }
        bar.addView(act.iconButton(R.drawable.ic_back, "Back", act.getColor(R.color.accent_text)) { act.back() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        status.gravity = Gravity.CENTER
        bar.addView(status, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(act.iconButton(R.drawable.ic_delete, "Delete note", act.getColor(R.color.accent_text)) { confirmDelete() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))

        val size = when (act.prefs.textSize) { 0 -> 16f; 2 -> 21f; else -> 18f }
        val scroll = ScrollView(act).apply { isFillViewport = true }
        val inner = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(4), dp(22), dp(48))
        }
        val stamp = if (note != null) note.updated else System.currentTimeMillis()
        inner.addView(act.label(
            DateUtils.formatDateTime(act, stamp, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_SHOW_YEAR),
            12.5f, R.color.text2).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) },
            LinearLayout.LayoutParams(MATCH, WRAP))
        title.apply {
            hint = "Title"
            textSize = size + 10
            typeface = Typeface.create(Fonts.get(act), Typeface.BOLD)
            background = null
            setTextColor(act.getColor(R.color.text))
            setHintTextColor(act.getColor(R.color.text2))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_NEXT
            setPadding(0, dp(6), 0, dp(6))
            setText(note?.title ?: "")
            setOnEditorActionListener { _, _, _ -> body.requestFocus(); true }
        }
        body.apply {
            hint = "Start writing…"
            textSize = size
            typeface = Fonts.get(act)
            background = null
            setTextColor(act.getColor(R.color.text))
            setHintTextColor(act.getColor(R.color.text2))
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setLineSpacing(0f, 1.25f)
            minLines = 14
            setPadding(0, dp(6), 0, 0)
            setText(note?.body ?: "")
        }
        title.onChange { schedule() }
        body.onChange { schedule() }
        inner.addView(title, LinearLayout.LayoutParams(MATCH, WRAP))
        inner.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))
        scroll.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        if (note == null) title.post { act.showKeyboard(title) }
    }

    private fun schedule() {
        dirty = true
        status.text = ""
        handler.removeCallbacks(saveTask)
        handler.postDelayed(saveTask, 600)
    }

    private fun save() {
        if (!dirty) return
        dirty = false
        val t = title.text.toString().trim()
        val b = body.text.toString()
        if (t.isEmpty() && b.isBlank()) {
            if (id != 0L) { act.db.deleteNote(id); id = 0L }
            return
        }
        id = act.db.saveNote(id, t, b)
        status.text = "Saved"
    }

    override fun flush() {
        handler.removeCallbacks(saveTask)
        save()
    }

    override fun onDestroyScreen() {
        flush()
        act.hideKeyboard(this)
    }

    private fun confirmDelete() {
        act.confirm("Delete note?", "Delete") {
            handler.removeCallbacks(saveTask)
            dirty = false
            if (id != 0L) act.db.deleteNote(id)
            id = 0L
            act.back()
        }
    }
}
