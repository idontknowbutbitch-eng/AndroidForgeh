package app.memo.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import app.memo.MainActivity
import app.memo.R
import app.memo.web.Tab
import app.memo.web.Url
import java.util.Collections

/** Tab switcher. Long-press a tab for "Hide tab" / "Close tab". Hidden tabs never appear here. */
class TabsScreen(act: MainActivity) : BScreen(act) {
    private val tm = act.tabs
    private val items = ArrayList<Tab>()
    private val rv = RecyclerView(act)
    private val empty = act.labelC("No open tabs", 15f, W2)
    private val adapter = TabAdapter()
    private val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
        ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
    ) {
        override fun isLongPressDragEnabled() = false

        override fun onMove(r: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
            val a = vh.bindingAdapterPosition
            val b = target.bindingAdapterPosition
            if (a < 0 || b < 0) return false
            Collections.swap(items, a, b)
            adapter.notifyItemMoved(a, b)
            return true
        }

        override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

        override fun clearView(r: RecyclerView, vh: RecyclerView.ViewHolder) {
            super.clearView(r, vh)
            tm.reorder(items)
        }
    })

    init {
        tm.active?.let { tm.capture(it) }
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val plus = act.iconButton(R.drawable.ic_add, "New tab", W) { tm.newTab(); act.showBrowser() }
        plus.background = glassCircle()
        val head = header("Tabs", true, plus)
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        rv.layoutManager = GridLayoutManager(act, if (act.resources.configuration.screenWidthDp >= 600) 3 else 2)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(dp(10), dp(6), dp(10), dp(40))
        touch.attachToRecyclerView(rv)
        col.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        load()
    }

    private fun glassCircle() = act.glass(22)

    override fun refresh() {
        super.refresh()
        load()
    }

    private fun load() {
        items.clear()
        items.addAll(tm.all.filter { !it.isHidden })
        adapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun menu(anchor: View, t: Tab) {
        Menus.show(anchor, listOf(
            "Hide tab" to { tm.setHidden(t, true); act.toast("Tab hidden"); load() },
            "Close tab" to { tm.close(t); load() }
        ))
    }

    private class Holder(
        val card: LinearLayout, val thumb: ImageView, val fav: ImageView,
        val title: TextView, val close: ImageButton, val grip: ImageView
    ) : RecyclerView.ViewHolder(card)

    private inner class TabAdapter : RecyclerView.Adapter<Holder>() {
        override fun getItemCount() = items.size

        private fun chip(res: Int): ImageButton = ImageButton(act).apply {
            setImageResource(res)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            background = act.rounded(Color.argb(140, 0, 0, 0), 15)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(7), dp(7), dp(7), dp(7))
        }

        override fun onCreateViewHolder(p: ViewGroup, type: Int): Holder {
            val card = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                clipToOutline = true
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            }
            val top = FrameLayout(act)
            val thumb = ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.argb(60, 255, 255, 255))
            }
            top.addView(thumb, FrameLayout.LayoutParams(MATCH, dp(170)))
            val m = dp(6)
            val close = chip(R.drawable.ic_close)
            top.addView(close, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.END).apply { setMargins(m, m, m, m) })
            val grip = chip(R.drawable.ic_drag)
            top.addView(grip, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.START).apply { setMargins(m, m, m, m) })
            val row = LinearLayout(act).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
            }
            val fav = ImageView(act)
            val title = act.labelC("", 13f, W).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(8), 0, 0, 0)
            }
            row.addView(fav, LinearLayout.LayoutParams(dp(16), dp(16)))
            row.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
            card.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
            card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            return Holder(card, thumb, fav, title, close, grip)
        }

        override fun onBindViewHolder(h: Holder, i: Int) {
            val t = items[i]
            h.title.text = t.title.ifBlank { Url.display(t.url).ifBlank { "New tab" } }
            h.thumb.setImageBitmap(tm.thumbOf(t))
            val icon = tm.iconOf(t)
            if (icon != null) {
                h.fav.imageTintList = null
                h.fav.setImageBitmap(icon)
            } else {
                h.fav.setImageResource(R.drawable.ic_globe)
                h.fav.imageTintList = ColorStateList.valueOf(W2)
            }
            val stroke = if (t === tm.active) 2 else 1
            val sc = if (t === tm.active) act.getColor(R.color.accent) else Color.argb(45, 255, 255, 255)
            h.card.background = act.rounded(Color.argb(110, 0, 0, 0), 18, sc, stroke)
            h.card.setOnClickListener { tm.activate(t); act.showBrowser() }
            h.card.setOnLongClickListener { menu(it, t); true }
            h.close.setOnClickListener { tm.close(t); load() }
            h.grip.setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) touch.startDrag(h)
                false
            }
        }
    }
}
