package app.memo.ui

import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.memo.MainActivity
import app.memo.R
import app.memo.data.Link

/** Bookmarks / History. */
class LinkListScreen(act: MainActivity, private val history: Boolean) : BScreen(act) {
    private var items: List<Link> = emptyList()
    private val rv = RecyclerView(act)
    private val empty = act.labelC(if (history) "No history yet." else "No bookmarks yet.", 15f, W2)
    private val adapter = RowAdapter()

    init {
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val clear = if (history) act.labelC("Clear", 16f, act.getColor(R.color.accent), true).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { act.confirm("Clear all history?", "Clear") { act.db.clearHistory(); refresh() } }
        } else null
        col.addView(header(if (history) "History" else "Bookmarks", true, clear), LinearLayout.LayoutParams(MATCH, WRAP))
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(dp(12), dp(4), dp(12), dp(24))
        col.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
    }

    override fun refresh() {
        super.refresh()
        items = if (history) act.db.history() else act.db.bookmarks()
        adapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private class VH(v: View, val title: TextView, val url: TextView, val del: ImageButton) : RecyclerView.ViewHolder(v)

    private inner class RowAdapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = items.size

        override fun onCreateViewHolder(p: ViewGroup, type: Int): VH {
            val row = LinearLayout(act).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(10), dp(6), dp(10))
                background = act.glass(16)
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(4), 0, dp(4)) }
            }
            val texts = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            val title = act.labelC("", 15.5f, W).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            val url = act.labelC("", 12.5f, W2).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            texts.addView(title); texts.addView(url)
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
            val del = act.iconButton(R.drawable.ic_close, "Delete", W2) {}
            row.addView(del, LinearLayout.LayoutParams(dp(44), dp(44)))
            return VH(row, title, url, del)
        }

        override fun onBindViewHolder(h: VH, i: Int) {
            val l = items[i]
            h.title.text = l.title.ifBlank { l.url }
            h.url.text = l.url
            h.itemView.setOnClickListener { act.openUrl(l.url) }
            h.del.setOnClickListener {
                if (history) act.db.deleteHistory(l.id) else act.db.deleteBookmark(l.id)
                refresh()
            }
        }
    }
}
