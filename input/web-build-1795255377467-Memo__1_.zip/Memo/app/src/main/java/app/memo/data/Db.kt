package app.memo.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Note(val id: Long, val title: String, val body: String, val updated: Long)
data class Link(val id: Long, val title: String, val url: String, val time: Long)
class TabRec(val id: Long, val title: String, val url: String, val isHidden: Boolean, val pos: Int, val state: ByteArray?)

/** Single local SQLite store: notes, bookmarks, history and persisted tabs. */
class Db(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "notes.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, updated INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, url TEXT NOT NULL UNIQUE, added INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, url TEXT NOT NULL, visited INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE tabs(id INTEGER PRIMARY KEY, title TEXT NOT NULL, url TEXT NOT NULL, is_hidden INTEGER NOT NULL, pos INTEGER NOT NULL, state BLOB)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---- notes ----
    fun notes(q: String = "", sort: Int = 0): List<Note> {
        val order = when (sort) { 1 -> "id DESC"; 2 -> "title COLLATE NOCASE ASC"; else -> "updated DESC" }
        val out = ArrayList<Note>()
        val c = if (q.isBlank())
            readableDatabase.rawQuery("SELECT id,title,body,updated FROM notes ORDER BY $order", null)
        else {
            val like = "%$q%"
            readableDatabase.rawQuery("SELECT id,title,body,updated FROM notes WHERE title LIKE ? OR body LIKE ? ORDER BY $order", arrayOf(like, like))
        }
        c.use { while (it.moveToNext()) out.add(Note(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3))) }
        return out
    }

    fun saveNote(id: Long, title: String, body: String): Long {
        val cv = ContentValues().apply {
            put("title", title); put("body", body); put("updated", System.currentTimeMillis())
        }
        if (id == 0L) return writableDatabase.insert("notes", null, cv)
        writableDatabase.update("notes", cv, "id=?", arrayOf(id.toString()))
        return id
    }

    fun deleteNote(id: Long) { writableDatabase.delete("notes", "id=?", arrayOf(id.toString())) }

    // ---- bookmarks ----
    fun bookmarks(): List<Link> = links("SELECT id,title,url,added FROM bookmarks ORDER BY added DESC", null)

    fun isBookmarked(url: String): Boolean =
        readableDatabase.rawQuery("SELECT 1 FROM bookmarks WHERE url=?", arrayOf(url)).use { it.moveToFirst() }

    /** Returns true if the page is now bookmarked. */
    fun toggleBookmark(title: String, url: String): Boolean {
        if (isBookmarked(url)) {
            writableDatabase.delete("bookmarks", "url=?", arrayOf(url)); return false
        }
        val cv = ContentValues().apply { put("title", title); put("url", url); put("added", System.currentTimeMillis()) }
        writableDatabase.insertWithOnConflict("bookmarks", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        return true
    }

    fun deleteBookmark(id: Long) { writableDatabase.delete("bookmarks", "id=?", arrayOf(id.toString())) }

    // ---- history ----
    fun history(): List<Link> = links("SELECT id,title,url,visited FROM history ORDER BY visited DESC LIMIT 300", null)

    fun addHistory(title: String, url: String) {
        val db = writableDatabase
        val last = db.rawQuery("SELECT id,url FROM history ORDER BY visited DESC LIMIT 1", null).use {
            if (it.moveToFirst()) Pair(it.getLong(0), it.getString(1)) else null
        }
        val now = System.currentTimeMillis()
        if (last != null && last.second == url) {
            val cv = ContentValues().apply { put("title", title); put("visited", now) }
            db.update("history", cv, "id=?", arrayOf(last.first.toString()))
        } else {
            val cv = ContentValues().apply { put("title", title); put("url", url); put("visited", now) }
            db.insert("history", null, cv)
            db.execSQL("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY visited DESC LIMIT 500)")
        }
    }

    fun deleteHistory(id: Long) { writableDatabase.delete("history", "id=?", arrayOf(id.toString())) }
    fun clearHistory() { writableDatabase.delete("history", null, null) }

    private fun links(sql: String, args: Array<String>?): List<Link> {
        val out = ArrayList<Link>()
        readableDatabase.rawQuery(sql, args).use {
            while (it.moveToNext()) out.add(Link(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3)))
        }
        return out
    }

    // ---- tabs ----
    fun tabs(): List<TabRec> {
        val out = ArrayList<TabRec>()
        readableDatabase.rawQuery("SELECT id,title,url,is_hidden,pos,state FROM tabs ORDER BY pos", null).use {
            while (it.moveToNext()) {
                val state = try { if (it.isNull(5)) null else it.getBlob(5) } catch (e: Exception) { null }
                out.add(TabRec(it.getLong(0), it.getString(1), it.getString(2), it.getInt(3) == 1, it.getInt(4), state))
            }
        }
        return out
    }

    /** Inserts or updates a tab's metadata without touching its saved web state. */
    fun saveTab(id: Long, title: String, url: String, isHidden: Boolean, pos: Int) {
        val cv = ContentValues().apply {
            put("id", id); put("title", title); put("url", url)
            put("is_hidden", if (isHidden) 1 else 0); put("pos", pos)
        }
        val db = writableDatabase
        db.insertWithOnConflict("tabs", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        db.update("tabs", cv, "id=?", arrayOf(id.toString()))
    }

    fun saveTabState(id: Long, state: ByteArray) {
        val cv = ContentValues().apply { put("state", state) }
        writableDatabase.update("tabs", cv, "id=?", arrayOf(id.toString()))
    }

    fun deleteTab(id: Long) { writableDatabase.delete("tabs", "id=?", arrayOf(id.toString())) }
}
