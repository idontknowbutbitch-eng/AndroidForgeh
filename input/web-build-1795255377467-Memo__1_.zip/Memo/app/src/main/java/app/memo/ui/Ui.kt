package app.memo.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import app.memo.MainActivity
import app.memo.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val DARK_BAR = Color.parseColor("#0B0B0F")
val W = Color.WHITE
val W2 = Color.argb(170, 255, 255, 255)

/** The app-wide typeface (SF Pro Display Medium). */
object Fonts {
    private var f: Typeface? = null
    fun get(c: Context): Typeface = f ?: c.resources.getFont(R.font.sf_pro_display_medium).also { f = it }
    fun applyTo(v: View) {
        if (v is TextView) v.typeface = get(v.context)
        if (v is ViewGroup) for (i in 0 until v.childCount) applyTo(v.getChildAt(i))
    }
}

fun Context.dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rounded(fill: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
    }

/** Dark frosted-glass panel (used by all browser-side screens). */
fun Context.glass(radius: Int, fill: Int = Color.argb(105, 0, 0, 0), stroke: Int = Color.argb(45, 255, 255, 255)) =
    rounded(fill, radius, stroke, 1)

fun Context.tinted(res: Int, color: Int): Drawable = getDrawable(res)!!.mutate().also { it.setTint(color) }

fun Context.labelC(s: String, sp: Float, color: Int, heavy: Boolean = false): TextView = TextView(this).apply {
    text = s
    textSize = sp
    setTextColor(color)
    typeface = if (heavy) Typeface.create(Fonts.get(context), Typeface.BOLD) else Fonts.get(context)
}

fun Context.label(s: String, sp: Float, colorRes: Int = R.color.text, heavy: Boolean = false): TextView =
    labelC(s, sp, getColor(colorRes), heavy)

fun Context.iconButton(res: Int, desc: String, tint: Int = getColor(R.color.text), onClick: () -> Unit): ImageButton =
    ImageButton(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(tint)
        contentDescription = desc
        val a = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
        background = a.getDrawable(0)
        a.recycle()
        setOnClickListener { onClick() }
    }

fun EditText.onChange(f: (String) -> Unit) = addTextChangedListener(object : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
})

fun MainActivity.confirm(title: String, yes: String, onYes: () -> Unit) {
    val d = MaterialAlertDialogBuilder(this).setTitle(title)
        .setNegativeButton("Cancel", null)
        .setPositiveButton(yes) { _, _ -> onYes() }
        .create()
    d.show()
    d.window?.decorView?.let { Fonts.applyTo(it) }
}

/** Segmented control. [dark] = glass style for browser screens. */
fun Context.segmented(opts: List<String>, sel: Int, dark: Boolean, onSel: (Int) -> Unit): LinearLayout {
    val box = LinearLayout(this)
    val cells = ArrayList<TextView>()
    val fillBox = if (dark) Color.argb(50, 255, 255, 255) else getColor(R.color.seg)
    val fillOn = if (dark) Color.argb(120, 255, 255, 255) else getColor(R.color.seg_on)
    val on = if (dark) W else getColor(R.color.text)
    val off = if (dark) W2 else getColor(R.color.text2)
    box.background = rounded(fillBox, 10)
    box.setPadding(dp(2), dp(2), dp(2), dp(2))
    fun style(s: Int) {
        cells.forEachIndexed { i, c ->
            c.background = if (i == s) rounded(fillOn, 8) else null
            c.setTextColor(if (i == s) on else off)
        }
    }
    opts.forEachIndexed { i, o ->
        val c = labelC(o, 13.5f, off).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setOnClickListener { style(i); onSel(i) }
        }
        cells.add(c)
        box.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
    }
    style(sel)
    return box
}

fun Context.slider(title: String, minV: Int, maxV: Int, value: Int, unit: String, onChange: (Int) -> Unit): LinearLayout {
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(12), dp(16), dp(6))
    }
    val top = LinearLayout(this)
    val v = labelC("$value$unit", 14f, W2)
    top.addView(labelC(title, 15f, W), LinearLayout.LayoutParams(0, WRAP, 1f))
    top.addView(v)
    val sb = SeekBar(this)
    sb.max = maxV - minV
    sb.progress = value - minV
    sb.progressTintList = ColorStateList.valueOf(getColor(R.color.accent))
    sb.thumbTintList = ColorStateList.valueOf(getColor(R.color.accent))
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            v.text = "${p + minV}$unit"
            if (fromUser) onChange(p + minV)
        }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    })
    box.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
    box.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
    return box
}

// ---- grouped settings rows ----
fun Context.rowView(dark: Boolean, title: String, sub: String? = null, trailing: View? = null, onClick: (() -> Unit)? = null): LinearLayout {
    val fg = if (dark) W else getColor(R.color.text)
    val fg2 = if (dark) W2 else getColor(R.color.text2)
    val r = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(13), dp(16), dp(13))
    }
    val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    tx.addView(labelC(title, 16f, fg))
    if (sub != null) tx.addView(labelC(sub, 12.5f, fg2).apply {
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setPadding(0, dp(2), 0, 0)
    })
    r.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
    if (trailing != null) r.addView(trailing, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(12) })
    if (onClick != null) r.setOnClickListener { onClick() }
    return r
}

fun Context.cardView(dark: Boolean, vararg rows: View): LinearLayout {
    val c = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = if (dark) glass(18) else rounded(getColor(R.color.surface), 14)
    }
    rows.forEachIndexed { i, r ->
        if (i > 0) c.addView(View(this).apply {
            setBackgroundColor(if (dark) Color.argb(40, 255, 255, 255) else getColor(R.color.divider))
        }, LinearLayout.LayoutParams(MATCH, 1).apply { marginStart = dp(16) })
        c.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
    }
    return c
}

fun Context.sectionLabel(dark: Boolean, s: String): TextView =
    labelC(s.uppercase(), 12f, if (dark) W2 else getColor(R.color.text2)).apply {
        setPadding(dp(16), dp(22), dp(16), dp(8))
    }

/** Small floating context menu that uses the app font. */
object Menus {
    fun show(anchor: View, items: List<Pair<String, () -> Unit>>) {
        val ctx = anchor.context
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = ctx.rounded(Color.argb(245, 38, 38, 42), 16, Color.argb(50, 255, 255, 255), 1)
            setPadding(0, ctx.dp(6), 0, ctx.dp(6))
        }
        val pw = PopupWindow(box, ctx.dp(190), WRAP, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.elevation = ctx.dp(10).toFloat()
        for ((t, a) in items) {
            box.addView(ctx.labelC(t, 15f, W).apply {
                setPadding(ctx.dp(18), ctx.dp(12), ctx.dp(18), ctx.dp(12))
                setOnClickListener { pw.dismiss(); a() }
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        pw.showAsDropDown(anchor, 0, -anchor.height / 2)
    }
}

object Dialogs {
    const val DEV_CODE = "1111"

    fun code(act: MainActivity, onOk: () -> Unit) {
        val et = EditText(act).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Code"
            gravity = Gravity.CENTER
            textSize = 22f
            typeface = Fonts.get(act)
        }
        val box = FrameLayout(act).apply { setPadding(act.dp(24), act.dp(8), act.dp(24), 0) }
        box.addView(et, FrameLayout.LayoutParams(MATCH, WRAP))
        val d = MaterialAlertDialogBuilder(act).setTitle("Developer options")
            .setMessage("Enter the developer code.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("OK", null)
            .create()
        d.setOnShowListener {
            et.requestFocus()
            d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (et.text.toString() == DEV_CODE) { d.dismiss(); onOk() }
                else { et.error = "Wrong code"; et.setText("") }
            }
        }
        d.show()
        d.window?.decorView?.let { Fonts.applyTo(it) }
    }
}

/** Base class for full-screen views managed by MainActivity's tiny navigation stack. */
abstract class Screen(val act: MainActivity) : FrameLayout(act) {
    init {
        setBackgroundColor(act.getColor(R.color.bg))
        isClickable = true
    }

    protected fun dp(n: Int) = act.dp(n)
    open fun refresh() {
        act.setSecure(false)
        act.setBars(act.getColor(R.color.bg), !act.isNight())
    }
    open fun onBack(): Boolean = false
    open fun flush() {}
    open fun onDestroyScreen() {}
    open fun showsPrivate(): Boolean = false

    protected fun header(title: String, dark: Boolean, trailing: View? = null): LinearLayout {
        val h = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(12), dp(4))
        }
        val tint = if (dark) W else act.getColor(R.color.accent_text)
        h.addView(act.iconButton(R.drawable.ic_back, "Back", tint) { act.back() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        h.addView(act.labelC(title, 20f, if (dark) W else act.getColor(R.color.text), true).apply {
            setPadding(dp(6), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (trailing != null) h.addView(trailing)
        return h
    }

    /** A header plus a scrolling column; returns the column to fill. */
    protected fun page(title: String, dark: Boolean, trailing: View? = null): LinearLayout {
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header(title, dark, trailing), LinearLayout.LayoutParams(MATCH, WRAP))
        val inner = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(32))
        }
        val sv = ScrollView(act)
        sv.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        return inner
    }
}
