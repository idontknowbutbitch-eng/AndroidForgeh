package app.memo.ui

import android.view.View
import android.widget.LinearLayout
import app.memo.MainActivity
import app.memo.R
import com.google.android.material.materialswitch.MaterialSwitch

/** Opened with the developer code. The only place hidden tabs can be reached. */
class DevOptionsScreen(act: MainActivity) : BScreen(act) {
    private val tm = act.tabs
    private val inner = page("Developer options", true)

    override fun showsPrivate() = true

    override fun refresh() {
        super.refresh()
        build()
    }

    private fun build() {
        inner.removeAllViews()
        val hidden = tm.all.filter { it.isHidden }
        inner.addView(act.sectionLabel(true, "Hidden tabs (${hidden.size})"))
        if (hidden.isEmpty()) {
            inner.addView(act.cardView(true, act.rowView(true, "No hidden tabs", "Long-press a tab and choose Hide tab.")))
        } else {
            val rows = hidden.map { t ->
                val actions = LinearLayout(act)
                val unhide = act.labelC("Unhide", 14f, act.getColor(R.color.accent), true).apply {
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                    setOnClickListener { tm.setHidden(t, false); build() }
                }
                val close = act.labelC("Close", 14f, W2).apply {
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                    setOnClickListener { act.confirm("Close this tab?", "Close") { tm.close(t); build() } }
                }
                actions.addView(unhide)
                actions.addView(close)
                act.rowView(true, t.title.ifBlank { "Untitled" }, t.url.ifBlank { "Blank tab" }, actions) {
                    tm.activate(t)
                    act.showBrowser()
                }
            }
            inner.addView(act.cardView(true, *rows.toTypedArray<View>()))
        }

        inner.addView(act.sectionLabel(true, "Engine"))
        val js = MaterialSwitch(act).apply {
            isChecked = act.prefs.js
            setOnCheckedChangeListener { _, c -> act.prefs.js = c; tm.applySettings() }
        }
        inner.addView(act.cardView(true,
            act.rowView(true, "JavaScript", "Turn off to block page scripts", js),
            act.rowView(true, "Clear cookies") {
                act.confirm("Clear all cookies?", "Clear") {
                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                    act.toast("Cookies cleared")
                }
            }))
        inner.addView(act.sectionLabel(true, ""))
        inner.addView(act.cardView(true,
            act.rowView(true, "Lock developer options") { act.devUnlocked = false; act.back() }))
    }
}
