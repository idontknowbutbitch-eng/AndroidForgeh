# Launcher Switcher (Android)
A simple native Android widget that opens a screen listing installed Home/launcher apps.

## Build
Open this folder in Android Studio or use a cloud Gradle builder. Build `app` > `assembleDebug`.
The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Widget
After installation: long-press the home screen > Widgets > Launcher Switcher > add it.
Tap widget to open app and choose a launcher. Android may show a system confirmation/default-home selection UI; the app cannot silently change your default launcher.

## Note
This first prototype lists launchers and requests Android's Home-role dialog. Android controls which launcher is ultimately selected, so the Switch button does not silently force a specific app.
