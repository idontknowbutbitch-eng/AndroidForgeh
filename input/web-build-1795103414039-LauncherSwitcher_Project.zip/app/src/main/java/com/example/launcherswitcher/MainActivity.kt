package com.example.launcherswitcher

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val pm by lazy { packageManager }
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 24)
            setBackgroundColor(Color.rgb(15, 16, 20))
        }
        val title = TextView(this).apply {
            text = "Launcher Switcher"
            textSize = 26f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 8)
        }
        val subtitle = TextView(this).apply {
            text = "Choose a home app to make it your default launcher."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 24)
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(title); root.addView(subtitle); root.addView(list)
        setContentView(root)
        loadLaunchers()
    }

    private fun loadLaunchers() {
        list.removeAllViews()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val matches = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        if (matches.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No launcher apps found."
                setTextColor(Color.WHITE)
            }
            list.addView(empty)
            return
        }

        matches.forEach { info ->
            val packageName = info.activityInfo.packageName
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(18, 14, 18, 14)
                setBackgroundColor(Color.rgb(35, 37, 44))
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(pm))
            }
            row.addView(icon, LinearLayout.LayoutParams(56, 56))
            val name = TextView(this).apply {
                text = info.loadLabel(pm).toString()
                textSize = 18f
                setTextColor(Color.WHITE)
                setPadding(18, 0, 8, 0)
            }
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            val button = Button(this).apply {
                text = "Switch"
                setOnClickListener { requestHomeRole(packageName) }
            }
            row.addView(button)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 12
            list.addView(row, lp)
        }
    }

    private fun requestHomeRole(packageName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                val request = roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME)
                startActivity(request)
                Toast.makeText(this, "Choose your preferred Home app in Android's system dialog.", Toast.LENGTH_LONG).show()
            } else {
                openDefaultAppsSettings()
            }
        } else {
            openDefaultAppsSettings()
        }
    }

    private fun openDefaultAppsSettings() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        }
    }
}
