package com.example.launcherswitcher

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(Color.rgb(18, 20, 26))
        }
        root.addView(TextView(this).apply {
            text = "Launcher Switcher"
            textSize = 26f
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Choose a home app. Android will confirm the default launcher."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 20)
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(root)
        fillLaunchers()
    }

    private fun fillLaunchers() {
        list.removeAllViews()
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val apps = packageManager.queryIntentActivities(query, PackageManager.MATCH_DEFAULT_ONLY)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        apps.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 10, 12, 10)
                setBackgroundColor(Color.rgb(38, 40, 48))
            }
            row.addView(ImageView(this).apply {
                setImageDrawable(app.loadIcon(packageManager))
            }, LinearLayout.LayoutParams(48, 48))
            row.addView(TextView(this).apply {
                text = app.loadLabel(packageManager).toString()
                textSize = 17f
                setTextColor(Color.WHITE)
                setPadding(12, 0, 6, 0)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Switch"
                setOnClickListener { askSystemToChooseHome() }
            })
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 10
            list.addView(row, lp)
        }
    }


    private fun askSystemToChooseHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME))
            } else {
                openSettings()
            }
        } else {
            openSettings()
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        }
    }
}
