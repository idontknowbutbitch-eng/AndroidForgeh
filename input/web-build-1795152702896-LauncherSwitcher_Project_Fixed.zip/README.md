Launcher Switcher Android project. Java and Kotlin JVM targets both set to 17 to fix AndroidForge compile target mismatch.
Build: gradle assembleDebug. Add widget via Home screen > Widgets.
