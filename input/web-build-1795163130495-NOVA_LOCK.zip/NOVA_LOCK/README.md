# NOVA LOCK — Dual Password App Locker (Kotlin, Jetpack Compose)

Each protected app has two passwords:

| Password | Result |
|---|---|
| **A** (primary) | Opens the real protected app |
| **B** (alternative) | Opens a destination *you* choose: another installed app, a built-in Calculator, or built-in Notes |

NOVA LOCK never clones apps; B just launches the destination you selected. Every app has its own independent pair (A and B must differ).

## Build
1. Open the `NOVA_LOCK` folder in **Android Studio Koala (2024.1) or newer** (JDK 17). Let it sync; it will download Gradle 8.7 and generate the wrapper jar (`gradle/wrapper/gradle-wrapper.properties` is included; run `gradle wrapper` if you build from the CLI).
2. Run on a device/emulator with Android 8.0+ (API 26+). Or `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.

## First run
1. Read the intro, set a **master PIN** (4–8 digits, confirm with ✓).
2. On the dashboard, grant (in system settings, never silently):
   - **Usage Access** – to see which app is in the foreground.
   - **Display over other apps** – so the lock screen can appear above a protected app.
   - **Notifications** (Android 13+, optional) – shows the "NOVA LOCK is active" notice.
3. **Add app** → pick an app → set Password A, Password B, choose the alternative destination → Save.
4. Tip: disable battery optimisation for NOVA LOCK on aggressive OEM ROMs so the watcher isn't killed.

## How it works
`GuardService` (foreground service, visible notification, restarted at boot) polls `UsageStatsManager` every 400 ms. When a protected app comes to the foreground it starts `LockActivity` on top. Password A marks the app unlocked until you leave it or the screen turns off; Password B opens the configured destination without unlocking the original.

## Security & limitations (be honest with yourself)
- Passwords are never stored: PBKDF2-HMAC-SHA256 (100k iterations, 16-byte random salt), then sealed with AES-GCM using a non-exportable **Android Keystore** key. Comparison is constant-time.
- Detection is polling-based, so a protected app may flash for a split second before the lock appears. Android does not allow third-party apps to truly block another app; this is a deterrent against casual access, not protection against someone who controls the device (safe mode, ADB, force-stopping NOVA LOCK).
- Biometrics unlock only NOVA LOCK itself, never a protected app (a fingerprint can't choose A or B).
- Some OEMs hide "Display over other apps" or Usage Access in different menus.
- NOVA LOCK is **not** a device administrator. Turn protection off per app or globally (Settings → Reset), or uninstall normally from system settings.
- No `INTERNET` permission, no ads, no analytics, `allowBackup=false`.

## Layout
```
app/src/main/java/com/novalock/
  MainActivity.kt   Root, navigation, permission & biometric helpers
  Screens.kt        Onboarding, Home, App picker, App configuration, Settings
  UI.kt             Theme, glass components, keypad, PIN entry
  LockActivity.kt   Lock screen (A → app, B → destination)
  DecoyActivity.kt  Built-in Calculator and Notes destinations
  Guard.kt          Permissions, foreground service, boot receiver
  Crypto.kt         Salted hashing + Keystore
  Store.kt          Local persistence
```
Typography uses the system sans-serif (SF Pro cannot be bundled for licensing reasons); swap in a font in `UI.kt` `T()` if you have one licensed.
