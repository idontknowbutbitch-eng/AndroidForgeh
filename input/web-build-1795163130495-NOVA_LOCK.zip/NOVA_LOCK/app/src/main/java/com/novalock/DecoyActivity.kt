package com.novalock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Built-in alternative destinations: a working calculator and a scratch notepad (notes are kept in memory only). */
class DecoyActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); enableEdgeToEdge(); Store.init(this)
        val notes = intent.getStringExtra("t") == "notes"
        setContent { NovaTheme { GlassBg { Box(Modifier.systemBarsPadding().padding(16.dp)) { if (notes) Notes() else Calc() } } } }
    }
    override fun onStop() { super.onStop(); finishAndRemoveTask() }
}

@Composable fun Notes() {
    var t by remember { mutableStateOf("") }
    Glass(Modifier.fillMaxSize()) {
        T("Notes", 28, FontWeight.Bold); Spacer(Modifier.height(10.dp))
        BasicTextField(t, { t = it }, Modifier.fillMaxSize(),
            textStyle = TextStyle(color = MaterialTheme.colorScheme.onBackground, fontSize = 18.sp),
            cursorBrush = SolidColor(Color(0xFF0A84FF)))
    }
}

@Composable fun Calc() {
    var cur by remember { mutableStateOf("0") }
    var acc by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<Char?>(null) }
    var fresh by remember { mutableStateOf(true) }
    fun fmt(d: Double) = if (d == d.toLong().toDouble()) d.toLong().toString() else "%.8g".format(d).trimEnd('0').trimEnd('.')
    fun calc(): Double {
        val a = acc ?: return cur.toDouble(); val b = cur.toDouble()
        return when (op) { '+' -> a + b; '−' -> a - b; '×' -> a * b; '÷' -> if (b == 0.0) 0.0 else a / b; else -> b }
    }
    fun press(k: String) {
        when (k) {
            "C" -> { cur = "0"; acc = null; op = null; fresh = true }
            "±" -> cur = fmt(-cur.toDouble())
            "%" -> cur = fmt(cur.toDouble() / 100)
            "+", "−", "×", "÷" -> { acc = calc(); cur = fmt(acc!!); op = k[0]; fresh = true }
            "=" -> { cur = fmt(calc()); acc = null; op = null; fresh = true }
            "." -> if (fresh) { cur = "0."; fresh = false } else if (!cur.contains('.')) cur += "."
            else -> { cur = if (fresh || cur == "0") k else cur + k; fresh = false }
        }
    }
    val ops = setOf("+", "−", "×", "÷", "=")
    Column(Modifier.fillMaxSize(), Arrangement.Bottom, Alignment.End) {
        T(cur, 64, FontWeight.Light, mod = Modifier.fillMaxWidth().padding(12.dp), align = TextAlign.End)
        listOf("C", "±", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ".", "=").chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), Arrangement.spacedBy(10.dp)) {
                row.forEach { k ->
                    val bg = when { k in ops -> Color(0xFFFF9F0A); k in setOf("C", "±", "%") -> Color.Gray.copy(.35f); else -> Color.Gray.copy(.18f) }
                    Box(Modifier.weight(if (k == "0") 2f else 1f).height(72.dp).clip(RoundedCornerShape(36.dp)).background(bg).clickable { press(k) }, Alignment.Center) {
                        T(k, 28, FontWeight.Medium, mod = Modifier, a = 1f)
                    }
                }
            }
        }
    }
}
