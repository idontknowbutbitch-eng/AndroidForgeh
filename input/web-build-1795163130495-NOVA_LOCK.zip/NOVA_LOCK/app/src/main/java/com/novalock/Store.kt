package com.novalock

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableIntStateOf
import org.json.JSONArray
import org.json.JSONObject

/** One protected app. dest: "calc" | "notes" | "app" (destPkg). hashA/hashB are Crypto.hash() outputs. */
data class Cfg(
    val pkg: String, val label: String, val enabled: Boolean = true,
    val hashA: String = "", val hashB: String = "", val dest: String = "calc", val destPkg: String = ""
)

object Store {
    private lateinit var sp: SharedPreferences
    val rev = mutableIntStateOf(0)          // bumped on every change so Compose re-reads
    val themeState = mutableIntStateOf(0)   // 0 system, 1 light, 2 dark
    @Volatile var unlocked: String? = null  // package currently unlocked with Password A (memory only)

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.applicationContext.getSharedPreferences("nova", Context.MODE_PRIVATE)
        themeState.intValue = sp.getInt("t", 0)
    }

    var onboarded: Boolean
        get() = sp.getBoolean("ob", false)
        set(v) { sp.edit().putBoolean("ob", v).apply() }
    var master: String
        get() = sp.getString("m", "") ?: ""
        set(v) { sp.edit().putString("m", v).apply() }
    var bio: Boolean
        get() = sp.getBoolean("bio", false)
        set(v) { sp.edit().putBoolean("bio", v).apply(); rev.intValue++ }
    var theme: Int
        get() = sp.getInt("t", 0)
        set(v) { sp.edit().putInt("t", v).apply(); themeState.intValue = v }

    fun all(): List<Cfg> = runCatching {
        val a = JSONArray(sp.getString("apps", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Cfg(o.getString("p"), o.getString("l"), o.getBoolean("e"), o.getString("a"), o.getString("b"), o.getString("d"), o.getString("dp"))
        }
    }.getOrDefault(emptyList())

    private fun save(l: List<Cfg>) {
        val arr = JSONArray(l.map {
            JSONObject().put("p", it.pkg).put("l", it.label).put("e", it.enabled).put("a", it.hashA)
                .put("b", it.hashB).put("d", it.dest).put("dp", it.destPkg)
        })
        sp.edit().putString("apps", arr.toString()).apply(); rev.intValue++
    }

    fun get(p: String) = all().firstOrNull { it.pkg == p }
    fun put(c: Cfg) = save(all().filter { it.pkg != c.pkg } + c)
    fun remove(p: String) = save(all().filter { it.pkg != p })
    fun reset() { sp.edit().clear().apply(); themeState.intValue = 0; unlocked = null; rev.intValue++ }
}
