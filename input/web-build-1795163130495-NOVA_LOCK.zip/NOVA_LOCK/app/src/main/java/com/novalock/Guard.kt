package com.novalock

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import androidx.core.content.ContextCompat

object Perms {
    @Suppress("DEPRECATION")
    fun usage(c: Context): Boolean {
        val m = c.getSystemService(AppOpsManager::class.java)
            .checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return m == AppOpsManager.MODE_ALLOWED ||
            (m == AppOpsManager.MODE_DEFAULT && c.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS") == PackageManager.PERMISSION_GRANTED)
    }
    fun overlay(c: Context) = android.provider.Settings.canDrawOverlays(c)
    fun notif(c: Context) = Build.VERSION.SDK_INT < 33 ||
        c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED
}

object Guard {
    /** Runs the watcher only while there is something to protect and the user has granted the permissions. */
    fun sync(c: Context) {
        val i = Intent(c, GuardService::class.java)
        val want = Store.all().any { it.enabled } && Perms.usage(c) && Perms.overlay(c)
        if (want) ContextCompat.startForegroundService(c, i) else c.stopService(i)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) { Store.init(c); Guard.sync(c) }
    }
}

/**
 * Foreground service with a visible notification. Polls UsageStatsManager every 400 ms for the app
 * that most recently moved to the foreground and shows LockActivity above it if it is protected.
 */
class GuardService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var last: String? = null
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { Store.unlocked = null; last = null }
    }
    private val loop = object : Runnable { override fun run() { poll(); h.postDelayed(this, 400) } }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate(); Store.init(this)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("guard", "NOVA LOCK protection", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "guard").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("NOVA LOCK is active")
            .setContentText("Protecting your selected apps. Tap to manage or turn off.")
            .setOngoing(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
        h.post(loop)
    }

    override fun onDestroy() { h.removeCallbacks(loop); unregisterReceiver(screenOff); super.onDestroy() }

    @Suppress("DEPRECATION")
    private fun foreground(): String? {
        val now = System.currentTimeMillis()
        val ev = getSystemService(UsageStatsManager::class.java).queryEvents(now - 5000, now)
        val e = UsageEvents.Event(); var p: String? = null
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) p = e.packageName }
        return p
    }

    private fun poll() {
        val p = foreground() ?: return
        if (p == last) return
        last = p
        if (p == packageName) return
        if (Store.unlocked != null && Store.unlocked != p) Store.unlocked = null   // leaving the app re-arms the lock
        val c = Store.get(p) ?: return
        if (!c.enabled || Store.unlocked == p) return
        startActivity(Intent(this, LockActivity::class.java).putExtra("pkg", p)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }
}
