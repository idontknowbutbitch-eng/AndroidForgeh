package com.novalock

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

sealed interface Scr {
    data object Gate : Scr; data object Onb : Scr; data object Home : Scr
    data object Pick : Scr; data object Settings : Scr; data class Edit(val pkg: String) : Scr
}

private val Green = Color(0xFF34C759)
private fun Cfg.destName(c: android.content.Context) = when (dest) { "calc" -> "Calculator"; "notes" -> "Notes"; else -> labelOf(c, destPkg) }

@Composable fun GateScreen(act: MainActivity, go: (Scr) -> Unit) {
    var shake by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { act.tryBio { go(Scr.Home) } }
    Box(Modifier.fillMaxSize()) {
        PinEntry("NOVA LOCK", "Enter your master PIN", shake) { if (Crypto.check(it, Store.master)) go(Scr.Home) else shake++ }
        if (Store.bio) TextButton({ act.tryBio { go(Scr.Home) } }, Modifier.align(Alignment.BottomCenter)) { Text("Use biometrics") }
    }
}

@Composable fun OnbScreen(go: (Scr) -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    if (step >= 2) { SetPin("Create master PIN") { Store.master = Crypto.hash(it); Store.onboarded = true; go(Scr.Home) }; return }
    Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.spacedBy(18.dp), Alignment.CenterHorizontally) {
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(96.dp).clip(CircleShape).background(Color(0xFF0A84FF)), Alignment.Center) { Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(44.dp)) }
        if (step == 0) {
            T("NOVA LOCK", 36, FontWeight.Bold)
            T("Lock any app behind your own password. Private, on-device, no accounts and no internet.", 17, a = .7f, align = TextAlign.Center)
        } else {
            T("Two passwords. Two outcomes.", 28, FontWeight.Bold, align = TextAlign.Center)
            Glass(Modifier.fillMaxWidth()) {
                T("Password A  →  the protected app", 16, FontWeight.SemiBold); Spacer(Modifier.height(8.dp))
                T("Password B  →  a destination you choose: another installed app, a calculator or notes", 16, FontWeight.SemiBold)
            }
            T("Every app has its own pair. NOVA LOCK never clones apps — password B simply opens the destination you picked.", 14, a = .65f, align = TextAlign.Center)
        }
        Spacer(Modifier.weight(1f))
        NovaButton(if (step == 0) "Continue" else "Set master PIN") { step++ }
    }
}

@Composable fun HomeScreen(act: MainActivity, go: (Scr) -> Unit) {
    val ctx = LocalContext.current
    val rev = Store.rev.intValue; val pt = act.permTick.intValue
    val list = remember(rev) { Store.all() }
    val usage = remember(pt) { Perms.usage(ctx) }; val ov = remember(pt) { Perms.overlay(ctx) }; val nf = remember(pt) { Perms.notif(ctx) }
    LaunchedEffect(rev, usage, ov) { Guard.sync(ctx) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { T("NOVA LOCK", 30, FontWeight.Bold); T("Dual password protection", 14, a = .6f) }
            IconButton({ go(Scr.Settings) }) { Icon(Icons.Filled.Settings, "Settings", tint = MaterialTheme.colorScheme.onBackground) }
        }
        Spacer(Modifier.height(16.dp))
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("${list.count { it.enabled }}", 44, FontWeight.Bold); Spacer(Modifier.width(14.dp))
                Column { T("Protected apps", 17, FontWeight.SemiBold); T(if (usage && ov) "Protection is running" else "Permissions needed", 13, a = .6f) }
            }
        }
        if (!usage || !ov || !nf) {
            Spacer(Modifier.height(12.dp))
            Glass(Modifier.fillMaxWidth()) {
                T("Permissions", 17, FontWeight.SemiBold); Spacer(Modifier.height(4.dp))
                T("Usage Access lets NOVA LOCK see which app is open so it can show the lock screen. Display over other apps lets that screen appear on top of the protected app. You grant both in system settings; nothing leaves your device.", 13, a = .7f)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
                    if (!usage) NChip("Usage Access", true) { act.openUsage() }
                    if (!ov) NChip("Display over apps", true) { act.openOverlay() }
                    if (!nf) NChip("Notifications (optional)") { act.askNotif() }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) {
            Glass(Modifier.fillMaxWidth(), pad = 28.dp) {
                Icon(Icons.Filled.Lock, null, Modifier.size(40.dp).align(Alignment.CenterHorizontally), tint = Color(0xFF0A84FF)); Spacer(Modifier.height(12.dp))
                T("Nothing protected yet", 20, FontWeight.SemiBold, align = TextAlign.Center, mod = Modifier.fillMaxWidth()); Spacer(Modifier.height(6.dp))
                T("Add an app, then choose two passwords: one opens it, the other opens a destination you pick.", 14, a = .65f, align = TextAlign.Center, mod = Modifier.fillMaxWidth())
            }
        } else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.pkg }) { c ->
                Glass(Modifier.fillMaxWidth(), onClick = { go(Scr.Edit(c.pkg)) }, pad = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(c.pkg, 48.dp); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { T(c.label, 17, FontWeight.SemiBold); T("A → app · B → ${c.destName(ctx)}", 12, a = .6f) }
                        Switch(c.enabled, { Store.put(c.copy(enabled = it)) }, colors = SwitchDefaults.colors(checkedTrackColor = Green))
                    }
                }
            }
        }
        NovaButton("Add app", Modifier.padding(vertical = 16.dp)) { go(Scr.Pick) }
    }
}

@Composable fun AppList(exclude: Set<String> = emptySet(), onPick: (String) -> Unit) {
    val ctx = LocalContext.current; var q by remember { mutableStateOf("") }
    val apps = remember {
        val pm = ctx.packageManager
        pm.queryIntentActivities(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }.distinctBy { it.first }
            .filter { it.first != ctx.packageName }.sortedBy { it.second.lowercase() }
    }
    val shown = apps.filter { it.first !in exclude && it.second.contains(q, true) }
    Column {
        Glass(Modifier.fillMaxWidth(), pad = 0.dp) {
            TextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search apps") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
        }
        LazyColumn(contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown, key = { it.first }) { (pkg, name) ->
                Glass(Modifier.fillMaxWidth(), onClick = { onPick(pkg) }, pad = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(pkg, 44.dp); Spacer(Modifier.width(12.dp)); T(name, 16, FontWeight.Medium, mod = Modifier.weight(1f))
                        if (Store.get(pkg) != null) Icon(Icons.Filled.Check, "Protected", tint = Green)
                    }
                }
            }
        }
    }
}

@Composable fun PickScreen(go: (Scr) -> Unit) = Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
    NHeader("Choose an app") { go(Scr.Home) }; AppList { go(Scr.Edit(it)) }
}

@Composable fun EditScreen(pkg: String, go: (Scr) -> Unit) {
    val ctx = LocalContext.current
    val existing = remember { Store.get(pkg) }
    var c by remember { mutableStateOf(existing ?: Cfg(pkg, labelOf(ctx, pkg))) }
    var setting by remember { mutableIntStateOf(0) }; var pickDest by remember { mutableStateOf(false) }
    BackHandler(setting != 0 || pickDest) { setting = 0; pickDest = false }
    if (setting != 0) {
        SetPin(if (setting == 1) "Primary password (A)" else "Alternative password (B)", { AppIcon(pkg, 56.dp) },
            validate = { p -> val other = if (setting == 1) c.hashB else c.hashA; if (Crypto.check(p, other)) "Must differ from the other password" else null }) { p ->
            c = if (setting == 1) c.copy(hashA = Crypto.hash(p)) else c.copy(hashB = Crypto.hash(p)); setting = 0
        }; return
    }
    if (pickDest) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            NHeader("Open which app?") { pickDest = false }
            AppList(setOf(pkg)) { c = c.copy(dest = "app", destPkg = it); pickDest = false }
        }; return
    }
    val ready = c.hashA.isNotEmpty() && c.hashB.isNotEmpty() && (c.dest != "app" || c.destPkg.isNotEmpty())
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NHeader("Protection") { go(Scr.Home) }
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(pkg, 56.dp); Spacer(Modifier.width(14.dp)); T(c.label, 20, FontWeight.SemiBold, mod = Modifier.weight(1f))
                Switch(c.enabled, { c = c.copy(enabled = it) }, colors = SwitchDefaults.colors(checkedTrackColor = Green))
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { T("Primary password (A)", 16, FontWeight.SemiBold); T("Opens ${c.label}${if (c.hashA.isEmpty()) " · not set" else " · set"}", 13, a = .6f) }
                NChip(if (c.hashA.isEmpty()) "Set" else "Change", true) { setting = 1 }
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { T("Alternative password (B)", 16, FontWeight.SemiBold); T("Opens ${c.destName(ctx)}${if (c.hashB.isEmpty()) " · not set" else " · set"}", 13, a = .6f) }
                NChip(if (c.hashB.isEmpty()) "Set" else "Change", true) { setting = 2 }
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            T("Alternative destination", 16, FontWeight.SemiBold); Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
                NChip("Calculator", c.dest == "calc") { c = c.copy(dest = "calc") }
                NChip("Notes", c.dest == "notes") { c = c.copy(dest = "notes") }
                NChip(if (c.dest == "app" && c.destPkg.isNotEmpty()) labelOf(ctx, c.destPkg) else "Another app…", c.dest == "app") { pickDest = true }
            }
            Spacer(Modifier.height(8.dp))
            T("NOVA LOCK doesn't clone apps. Password B opens exactly the destination you select here.", 12, a = .6f)
        }
        NovaButton("Save", on = ready) { Store.put(c); go(Scr.Home) }
        if (existing != null) TextButton({ Store.remove(pkg); go(Scr.Home) }, Modifier.fillMaxWidth()) { Text("Remove protection", color = Color(0xFFFF453A)) }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable fun SettingsScreen(act: MainActivity, go: (Scr) -> Unit) {
    val ctx = LocalContext.current
    var sub by remember { mutableIntStateOf(0) }; var shake by remember { mutableIntStateOf(0) }; var confirm by remember { mutableStateOf(false) }
    val pt = act.permTick.intValue
    val usage = remember(pt) { Perms.usage(ctx) }; val ov = remember(pt) { Perms.overlay(ctx) }
    BackHandler(sub != 0) { sub = 0 }
    if (sub == 1) { PinEntry("Current PIN", "Verify it's you", shake) { if (Crypto.check(it, Store.master)) sub = 2 else shake++ }; return }
    if (sub == 2) { SetPin("New master PIN") { Store.master = Crypto.hash(it); sub = 0 }; return }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NHeader("Settings") { go(Scr.Home) }
        Glass(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().clickable { sub = 1 }, verticalAlignment = Alignment.CenterVertically) { T("Change master PIN", 16, FontWeight.Medium, mod = Modifier.weight(1f)); Icon(Icons.Filled.Edit, null, tint = Color.Gray) }
            if (act.canBio()) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { T("Biometrics", 16, FontWeight.Medium); T("Opens NOVA LOCK only. Locked apps always ask for a password.", 12, a = .6f) }
                    Switch(Store.bio, { Store.bio = it }, colors = SwitchDefaults.colors(checkedTrackColor = Green))
                }
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            T("Theme", 16, FontWeight.SemiBold); Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("System", "Light", "Dark").forEachIndexed { i, n -> NChip(n, Store.themeState.intValue == i) { Store.theme = i } } }
        }
        Glass(Modifier.fillMaxWidth()) {
            T("Permissions", 16, FontWeight.SemiBold); Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clickable { act.openUsage() }, verticalAlignment = Alignment.CenterVertically) { T("Usage Access", 15, mod = Modifier.weight(1f)); T(if (usage) "On" else "Off", 14, a = .6f) }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().clickable { act.openOverlay() }, verticalAlignment = Alignment.CenterVertically) { T("Display over other apps", 15, mod = Modifier.weight(1f)); T(if (ov) "On" else "Off", 14, a = .6f) }
        }
        Glass(Modifier.fillMaxWidth()) {
            T("Security", 16, FontWeight.SemiBold); Spacer(Modifier.height(6.dp))
            T("NOVA LOCK watches which app is in the foreground (Usage Access) and shows its lock screen on top (Display over other apps), with a visible notification while it runs. This is a deterrent against casual access, not a hardened sandbox. Passwords are stored only as salted PBKDF2 hashes sealed with an Android Keystore key. NOVA LOCK is not a device administrator: turn protection off or uninstall it normally at any time.", 13, a = .7f)
        }
        Glass(Modifier.fillMaxWidth()) {
            T("Privacy", 16, FontWeight.SemiBold); Spacer(Modifier.height(6.dp))
            T("Everything stays on this device. No internet permission, no ads, no analytics, no backups. The list of apps you protect is stored locally and is removed when you reset or uninstall.", 13, a = .7f)
        }
        TextButton({ confirm = true }, Modifier.fillMaxWidth()) { Text("Reset all configuration", color = Color(0xFFFF453A)) }
        Spacer(Modifier.height(16.dp))
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        title = { Text("Reset NOVA LOCK?") }, text = { Text("This removes the master PIN and every app configuration. Your apps are unlocked and unchanged.") },
        confirmButton = { TextButton({ confirm = false; Store.reset(); Guard.sync(ctx); go(Scr.Onb) }) { Text("Reset", color = Color(0xFFFF453A)) } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } })
}
