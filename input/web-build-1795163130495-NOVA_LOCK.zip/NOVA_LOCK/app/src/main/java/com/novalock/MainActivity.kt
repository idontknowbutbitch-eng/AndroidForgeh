package com.novalock

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

class MainActivity : FragmentActivity() {
    val permTick = mutableIntStateOf(0)
    private var skipGate = false
    private var prompting = false
    private val notifReq = registerForActivityResult(ActivityResultContracts.RequestPermission()) { permTick.intValue++ }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s); enableEdgeToEdge(); Store.init(this)
        setContent { NovaTheme { Root() } }
    }
    override fun onStart() { super.onStart(); skipGate = false }
    override fun onResume() { super.onResume(); permTick.intValue++ }

    fun openUsage() { skipGate = true; startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
    fun openOverlay() { skipGate = true; startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
    fun askNotif() { if (Build.VERSION.SDK_INT >= 33) { skipGate = true; notifReq.launch(Manifest.permission.POST_NOTIFICATIONS) } }
    fun gateOnStop() = !skipGate

    fun canBio() = BiometricManager.from(this).canAuthenticate(BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
    fun tryBio(ok: () -> Unit) {
        if (!Store.bio || !canBio() || prompting) return
        prompting = true
        val p = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { prompting = false; ok() }
            override fun onAuthenticationError(c: Int, m: CharSequence) { prompting = false }
        })
        p.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Unlock NOVA LOCK").setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BIOMETRIC_STRONG).build())
    }

    @Composable private fun Root() {
        var scr by remember { mutableStateOf<Scr>(if (Store.onboarded) Scr.Gate else Scr.Onb) }
        LifecycleEventEffect(Lifecycle.Event.ON_STOP) { if (Store.onboarded && gateOnStop()) scr = Scr.Gate }
        BackHandler(scr != Scr.Home && scr != Scr.Gate && scr != Scr.Onb) { scr = Scr.Home }
        GlassBg {
            AnimatedContent(scr, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "screen") { s ->
                Box(Modifier.fillMaxSize().systemBarsPadding()) {
                    val go: (Scr) -> Unit = { scr = it }
                    when (s) {
                        Scr.Gate -> GateScreen(this@MainActivity, go)
                        Scr.Onb -> OnbScreen(go)
                        Scr.Home -> HomeScreen(this@MainActivity, go)
                        Scr.Pick -> PickScreen(go)
                        Scr.Settings -> SettingsScreen(this@MainActivity, go)
                        is Scr.Edit -> EditScreen(s.pkg, go)
                    }
                }
            }
        }
    }
}
