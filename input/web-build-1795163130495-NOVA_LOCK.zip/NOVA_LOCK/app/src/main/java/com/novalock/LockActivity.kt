package com.novalock

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** The lock screen. Password A opens the protected app; Password B opens the user-chosen destination. */
class LockActivity : ComponentActivity() {
    private var cfg by mutableStateOf<Cfg?>(null)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s); enableEdgeToEdge(); Store.init(this)
        if (!load(intent)) { finish(); return }
        setContent {
            NovaTheme {
                GlassBg {
                    val c = cfg ?: return@GlassBg
                    BackHandler { goHome() }
                    key(c.pkg) {
                        var shake by remember { mutableIntStateOf(0) }
                        Box(Modifier.systemBarsPadding()) {
                            PinEntry(c.label, "Enter password", shake, header = { AppIcon(c.pkg, 76.dp) }) { p ->
                                when {
                                    Crypto.check(p, c.hashA) -> { Store.unlocked = c.pkg; open(c.pkg) }
                                    Crypto.check(p, c.hashB) -> destination(c)
                                    else -> shake++
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); if (!load(i)) finish() }
    override fun onStop() { super.onStop(); finishAndRemoveTask() }

    private fun load(i: Intent): Boolean { cfg = i.getStringExtra("pkg")?.let { Store.get(it) }; return cfg != null }

    private fun open(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
        finish()
    }

    private fun destination(c: Cfg) {
        if (c.dest == "app" && c.destPkg.isNotEmpty()) open(c.destPkg)
        else { startActivity(Intent(this, DecoyActivity::class.java).putExtra("t", c.dest)); finish() }
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
