package com.novalock

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.graphics.drawable.toBitmap

val LocalDark = staticCompositionLocalOf { false }
private val Blue = Color(0xFF0A84FF)

@Composable fun NovaTheme(content: @Composable () -> Unit) {
    val d = when (Store.themeState.intValue) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val cs = if (d) darkColorScheme(primary = Blue, background = Color(0xFF07070C), onBackground = Color(0xFFF5F5F7), surface = Color(0xFF1C1C1E), onSurface = Color(0xFFF5F5F7))
    else lightColorScheme(primary = Color(0xFF007AFF), background = Color(0xFFF2F4FA), onBackground = Color(0xFF111114), surface = Color.White, onSurface = Color(0xFF111114))
    CompositionLocalProvider(LocalDark provides d) { MaterialTheme(colorScheme = cs, content = content) }
}

/** Soft aurora background; the blobs use Modifier.blur (real blur on Android 12+, soft tint below). */
@Composable fun GlassBg(content: @Composable BoxScope.() -> Unit) {
    val d = LocalDark.current
    Box(Modifier.fillMaxSize().background(if (d) Color(0xFF07070C) else Color(0xFFF2F4FA))) {
        Box(Modifier.size(320.dp).offset((-90).dp, (-60).dp).blur(90.dp).background(Blue.copy(if (d) .45f else .35f), CircleShape))
        Box(Modifier.size(280.dp).align(Alignment.BottomEnd).offset(80.dp, 60.dp).blur(90.dp).background(Color(0xFFBF5AF2).copy(if (d) .35f else .28f), CircleShape))
        content()
    }
}

@Composable fun Glass(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, pad: Dp = 16.dp, content: @Composable ColumnScope.() -> Unit) {
    val d = LocalDark.current
    val shape = RoundedCornerShape(26.dp)
    var m = modifier.clip(shape).background(if (d) Color.White.copy(.07f) else Color.White.copy(.6f))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(if (d) .25f else .95f), Color.White.copy(.04f))), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(pad), content = content)
}

@Composable fun T(s: String, size: Int = 16, w: FontWeight = FontWeight.Normal, a: Float = 1f, mod: Modifier = Modifier, align: TextAlign? = null) =
    Text(s, mod, color = MaterialTheme.colorScheme.onBackground.copy(alpha = a), fontSize = size.sp, fontWeight = w, letterSpacing = (-0.2).sp, textAlign = align)

@Composable fun NovaButton(t: String, mod: Modifier = Modifier, on: Boolean = true, onClick: () -> Unit) {
    Box(mod.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp))
        .background(Brush.horizontalGradient(listOf(Color(0xFF0A84FF), Color(0xFF5E5CE6))), alpha = if (on) 1f else .35f)
        .clickable(enabled = on, onClick = onClick), Alignment.Center) { Text(t, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable fun NChip(t: String, sel: Boolean = false, onClick: () -> Unit) {
    val d = LocalDark.current
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(if (sel) Blue else if (d) Color.White.copy(.1f) else Color.Black.copy(.06f))
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp)) {
        Text(t, color = if (sel) Color.White else MaterialTheme.colorScheme.onBackground, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable fun NHeader(title: String, onBack: () -> Unit) = Row(Modifier.padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
    IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = MaterialTheme.colorScheme.onBackground) }
    T(title, 28, FontWeight.Bold)
}

@Composable fun AppIcon(pkg: String, size: Dp) {
    val pm = LocalContext.current.packageManager
    val bmp = remember(pkg) { runCatching { pm.getApplicationIcon(pkg).toBitmap(160, 160).asImageBitmap() }.getOrNull() }
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.26f))) { bmp?.let { Image(it, null, Modifier.fillMaxSize()) } }
}

fun labelOf(c: android.content.Context, pkg: String) = runCatching {
    val pm = c.packageManager; pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
}.getOrDefault(pkg)

@Composable fun Key(t: String, small: Boolean = false, onClick: () -> Unit) {
    val d = LocalDark.current; val hf = LocalHapticFeedback.current
    Box(Modifier.size(78.dp).clip(CircleShape).background(if (d) Color.White.copy(.09f) else Color.White.copy(.65f))
        .border(1.dp, Color.White.copy(if (d) .12f else .9f), CircleShape)
        .clickable { hf.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }, Alignment.Center) {
        T(t, if (small) 24 else 32, FontWeight.Light)
    }
}

@Composable fun Keypad(onDigit: (String) -> Unit, onDel: () -> Unit, onOk: () -> Unit) =
    Column(verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        listOf("123", "456", "789").forEach { r -> Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) { r.forEach { ch -> Key(ch.toString()) { onDigit(ch.toString()) } } } }
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) { Key("⌫", true, onDel); Key("0") { onDigit("0") }; Key("✓", true, onOk) }
    }

@Composable fun Dots(n: Int) = Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.height(20.dp), verticalAlignment = Alignment.CenterVertically) {
    repeat(maxOf(4, n)) { i -> Box(Modifier.size(14.dp).clip(CircleShape).background(if (i < n) MaterialTheme.colorScheme.primary else Color.Gray.copy(.3f))) }
}

/** Reusable PIN screen (4–8 digits, confirm with ✓). Bump [shake] to play the error animation. */
@Composable fun PinEntry(title: String, sub: String, shake: Int = 0, header: @Composable () -> Unit = {}, onSubmit: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    val off = remember { Animatable(0f) }
    LaunchedEffect(shake) {
        if (shake > 0) repeat(3) { off.animateTo(16f, tween(40)); off.animateTo(-16f, tween(40)) }
        off.animateTo(0f, tween(40))
    }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.SpaceEvenly, Alignment.CenterHorizontally) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            header(); Spacer(Modifier.height(12.dp)); T(title, 26, FontWeight.Bold, align = TextAlign.Center); Spacer(Modifier.height(4.dp)); T(sub, 14, a = .6f, align = TextAlign.Center)
        }
        Box(Modifier.offset { IntOffset(off.value.dp.roundToPx(), 0) }) { Dots(pin.length) }
        Keypad({ if (pin.length < 8) pin += it }, { pin = pin.dropLast(1) }, { if (pin.length >= 4) { val p = pin; pin = ""; onSubmit(p) } })
    }
}

/** Enter twice to set a PIN. [validate] can reject a first entry with a message. */
@Composable fun SetPin(title: String, header: @Composable () -> Unit = {}, validate: (String) -> String? = { null }, onDone: (String) -> Unit) {
    var first by remember { mutableStateOf<String?>(null) }
    var shake by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("Use 4–8 digits, then tap ✓") }
    PinEntry(if (first == null) title else "Confirm it", msg, shake, header) { p ->
        if (first == null) { val e = validate(p); if (e != null) { msg = e; shake++ } else { first = p; msg = "Enter it once more" } }
        else if (first == p) onDone(p) else { first = null; msg = "Didn't match — try again"; shake++ }
    }
}
