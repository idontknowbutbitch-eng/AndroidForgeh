package com.ivan.reskin.engine

import android.graphics.Bitmap
import com.reandroid.apk.ApkModule
import com.reandroid.archive.ByteInputSource
import com.reandroid.arsc.chunk.xml.ResXmlAttribute
import com.reandroid.arsc.chunk.xml.ResXmlElement
import java.io.ByteArrayOutputStream
import java.io.File

data class PatchRequest(
    val originalPackage: String,
    val newPackage: String,
    val label: String,
    val icon: Bitmap?,          // null = keep the app's own icon
)

/**
 * Turns an installed app's APK into a side-by-side copy with a new name / icon / package id.
 *
 * Everything that touches ARSCLib is in this file. If a method name differs in the ARSCLib
 * version you pull, fix it in the "ARSCLib shim" block at the bottom - nothing else depends on it.
 */
class ApkPatcher {

    /** Patches the base APK. Returns human-readable warnings (e.g. icon could not be replaced). */
    fun patchBase(input: File, output: File, req: PatchRequest): List<String> {
        val warnings = mutableListOf<String>()
        val apk = ApkModule.loadApkFile(input)
        try {
            val manifest = apk.androidManifest
            val root = manifest.manifestElement
            val old = req.originalPackage
            val suffix = req.newPackage.removePrefix("$old.")

            // 1) Relative class names (".Main", "Main") must become absolute before the package changes.
            walk(root) { el ->
                if (el.name in CLASS_TAGS) {
                    for (a in el.attrs()) {
                        if (a.nameId in CLASS_ATTRS) {
                            val v = a.stringValue() ?: continue
                            val abs = absolutize(v, old)
                            if (abs != v) a.setString(abs)
                        }
                    }
                }
            }

            // 2) New package id.
            manifest.packageName = req.newPackage

            // 3) Provider authorities must be unique device-wide, otherwise the install is rejected.
            walk(root) { el ->
                if (el.name == "provider") {
                    el.attrs().firstOrNull { it.nameId == ATTR_AUTHORITIES }?.let { a ->
                        val v = a.stringValue() ?: return@let
                        a.setString(
                            v.split(';').joinToString(";") {
                                if (it.contains(old)) it.replace(old, req.newPackage) else "$it.$suffix"
                            }
                        )
                    }
                }
            }

            // 4) Custom permissions are also device-wide unique -> rename them and every reference.
            val renamed = HashMap<String, String>()
            walk(root) { el ->
                if (el.name == "permission" || el.name == "permission-tree" || el.name == "permission-group") {
                    el.attrs().firstOrNull { it.nameId == ATTR_NAME }?.let { a ->
                        val v = a.stringValue() ?: return@let
                        val nv = if (v.contains(old)) v.replace(old, req.newPackage) else "$v.$suffix"
                        renamed[v] = nv
                        a.setString(nv)
                    }
                }
            }
            if (renamed.isNotEmpty()) {
                walk(root) { el ->
                    val usesPermission = el.name.startsWith("uses-permission")
                    for (a in el.attrs()) {
                        val isRef = (usesPermission && a.nameId == ATTR_NAME) || a.nameId == ATTR_PERMISSION
                        if (isRef) a.stringValue()?.let { v -> renamed[v]?.let { a.setString(it) } }
                    }
                }
            }

            // 5) Label: application + launcher activities.
            val iconIds = linkedSetOf<Int>()
            walk(root) { el ->
                val isApp = el.name == "application"
                val isLauncher = (el.name == "activity" || el.name == "activity-alias") && el.isLauncher()
                if (isApp || isLauncher) {
                    val existing = el.attrs().firstOrNull { it.nameId == ATTR_LABEL }
                    if (existing != null) existing.setString(req.label)
                    else el.createLabel(req.label)

                    for (a in el.attrs()) {
                        if (a.nameId == ATTR_ICON || a.nameId == ATTR_ROUND_ICON) {
                            a.referenceId()?.let { iconIds += it }
                        }
                    }
                }
            }

            // 6) Icon.
            if (req.icon != null) {
                if (iconIds.isEmpty()) {
                    warnings += "This app has no icon resource, the icon was not changed."
                } else {
                    try {
                        replaceIcons(apk, iconIds, req.icon)
                    } catch (t: Throwable) {
                        warnings += "Icon could not be replaced (${t.javaClass.simpleName}). The name was changed."
                    }
                }
            }

            apk.writeApk(output)
        } finally {
            apk.close()
        }
        return warnings
    }

    /** Split APKs only need the matching package id. */
    fun patchSplit(input: File, output: File, req: PatchRequest) {
        val apk = ApkModule.loadApkFile(input)
        try {
            apk.androidManifest.packageName = req.newPackage
            apk.writeApk(output)
        } finally {
            apk.close()
        }
    }

    // ---------------------------------------------------------------- icons

    private fun replaceIcons(apk: ApkModule, ids: Set<Int>, icon: Bitmap) {
        val table = apk.tableBlock
        val pngBySize = HashMap<Int, ByteArray>()
        val newPathFor = HashMap<String, String>()
        var counter = 0

        for (id in ids) {
            val resource = table.getResource(id) ?: continue
            for (entry in resource) {
                if (entry.isNull) continue
                val value = entry.resValue ?: continue
                val oldPath = value.valueAsString ?: continue
                if (!oldPath.startsWith("res/")) continue

                val size = sizeFor(oldPath)
                val bytes = pngBySize.getOrPut(size) { png(icon, size) }
                val newPath = newPathFor.getOrPut(oldPath) { "res/rk/i${counter++}_$size.png" }

                apk.add(ByteInputSource(bytes, newPath))
                value.setValueAsString(newPath)
            }
        }
        for (old in newPathFor.keys) apk.zipEntryMap.remove(old)
    }

    private fun sizeFor(path: String) = when {
        "xxxhdpi" in path -> 192
        "xxhdpi" in path -> 144
        "xhdpi" in path -> 96
        "hdpi" in path -> 72
        "mdpi" in path -> 48
        else -> 192
    }

    private fun png(src: Bitmap, size: Int): ByteArray {
        val scaled = Bitmap.createScaledBitmap(src, size, size, true)
        return ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
    }

    // ---------------------------------------------------------------- helpers

    private fun absolutize(v: String, pkg: String) = when {
        v.startsWith(".") -> pkg + v
        !v.contains('.') -> "$pkg.$v"
        else -> v
    }

    private fun walk(e: ResXmlElement, visit: (ResXmlElement) -> Unit) {
        visit(e)
        for (c in e.elements) walk(c, visit)
    }

    private fun ResXmlElement.isLauncher(): Boolean {
        var found = false
        walk(this) { el ->
            if (el.name == "category") {
                el.attrs().forEach { a ->
                    if (a.nameId == ATTR_NAME && a.stringValue() == "android.intent.category.LAUNCHER") found = true
                }
            }
        }
        return found
    }

    // ============================================================== ARSCLib shim
    // The only place that depends on exact ARSCLib method names.

    private fun ResXmlElement.attrs(): List<ResXmlAttribute> = attributes.asSequence().toList()

    private val ResXmlAttribute.nameId: Int get() = nameResourceID

    private fun ResXmlAttribute.stringValue(): String? = valueAsString

    private fun ResXmlAttribute.setString(v: String) = setValueAsString(v)

    /** Resource id when the attribute is a reference like @mipmap/ic_launcher, otherwise null. */
    private fun ResXmlAttribute.referenceId(): Int? = if (valueType == com.reandroid.arsc.value.ValueType.REFERENCE) data else null

    private fun ResXmlElement.createLabel(text: String) {
        getOrCreateAndroidAttribute("label", ATTR_LABEL).setValueAsString(text)
    }

    private companion object {
        const val ATTR_LABEL = 0x01010001
        const val ATTR_ICON = 0x01010002
        const val ATTR_NAME = 0x01010003
        const val ATTR_PERMISSION = 0x01010006
        const val ATTR_AUTHORITIES = 0x01010018
        const val ATTR_ROUND_ICON = 0x0101052c
        const val ATTR_TARGET_ACTIVITY = 0x01010202
        const val ATTR_PARENT_ACTIVITY = 0x010103a7
        const val ATTR_BACKUP_AGENT = 0x01010216
        const val ATTR_MANAGE_SPACE = 0x01010217

        val CLASS_ATTRS = setOf(ATTR_NAME, ATTR_TARGET_ACTIVITY, ATTR_PARENT_ACTIVITY, ATTR_BACKUP_AGENT, ATTR_MANAGE_SPACE)
        val CLASS_TAGS = setOf("application", "activity", "activity-alias", "service", "receiver", "provider")
    }
}
