package com.ivan.reskin.data

data class AppEntry(val packageName: String, val label: String)

data class CloneRecord(
    val originalPackage: String,
    val clonePackage: String,
    val label: String,
)
