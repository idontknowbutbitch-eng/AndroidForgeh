package com.ivan.reskin.engine

import kotlinx.coroutines.flow.MutableSharedFlow

sealed interface InstallResult {
    data class Success(val packageName: String?) : InstallResult
    data class Failure(val message: String) : InstallResult
}

object InstallEvents {
    val flow = MutableSharedFlow<InstallResult>(extraBufferCapacity = 8)
}
