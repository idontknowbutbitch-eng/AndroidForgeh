package com.ivan.reskin.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ivan.reskin.data.AppEntry
import com.ivan.reskin.data.AppRepository
import com.ivan.reskin.data.CloneRecord
import com.ivan.reskin.data.CloneStore
import com.ivan.reskin.engine.ApkInstaller
import com.ivan.reskin.engine.ApkPatcher
import com.ivan.reskin.engine.ApkSignerHelper
import com.ivan.reskin.engine.InstallEvents
import com.ivan.reskin.engine.InstallResult
import com.ivan.reskin.engine.PatchRequest
import com.ivan.reskin.engine.ZipAligner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

data class UiState(
    val apps: List<AppEntry> = emptyList(),
    val loading: Boolean = true,
    val query: String = "",
    val tab: Int = 0,
    val clones: List<CloneRecord> = emptyList(),
    val selected: AppEntry? = null,
    val name: String = "",
    val icon: Bitmap? = null,
    val busy: String? = null,
    val message: String? = null,
    val needsInstallPermission: Boolean = false,
)

class ReskinViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository(app)
    private val store = CloneStore(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var pending: CloneRecord? = null

    init {
        viewModelScope.launch {
            val apps = repo.launchableApps()
            _state.update { it.copy(apps = apps, loading = false, clones = installedClones()) }
        }
        viewModelScope.launch {
            InstallEvents.flow.collect { result ->
                when (result) {
                    is InstallResult.Success -> {
                        pending?.let { store.add(it) }
                        val label = pending?.label
                        pending = null
                        val apps = repo.launchableApps()
                        _state.update {
                            it.copy(
                                apps = apps, clones = installedClones(), busy = null,
                                selected = null, icon = null, name = "", tab = 1,
                                message = "“$label” installed",
                            )
                        }
                    }
                    is InstallResult.Failure -> {
                        pending = null
                        _state.update { it.copy(busy = null, message = result.message) }
                    }
                }
            }
        }
    }

    private fun installedClones() = store.all().filter { repo.isInstalled(it.clonePackage) }

    fun refresh() {
        viewModelScope.launch {
            val apps = repo.launchableApps()
            _state.update { it.copy(apps = apps, clones = installedClones()) }
        }
    }

    fun setQuery(q: String) = _state.update { it.copy(query = q) }
    fun setTab(t: Int) = _state.update { it.copy(tab = t) }
    fun setName(n: String) = _state.update { it.copy(name = n) }
    fun resetIcon() = _state.update { it.copy(icon = null) }
    fun consumeMessage() = _state.update { it.copy(message = null) }
    fun dismissPermission() = _state.update { it.copy(needsInstallPermission = false) }

    fun select(app: AppEntry) = _state.update { it.copy(selected = app, name = app.label, icon = null) }
    fun back() = _state.update { if (it.busy == null) it.copy(selected = null, icon = null) else it }

    fun removeClone(pkg: String) {
        store.remove(pkg)
        _state.update { it.copy(clones = installedClones()) }
    }

    fun pickIcon(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeSquare(uri) }
            if (bmp == null) _state.update { it.copy(message = "Couldn’t read that image") }
            else _state.update { it.copy(icon = bmp) }
        }
    }

    private fun decodeSquare(uri: Uri): Bitmap? = try {
        val resolver = getApplication<Application>().contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        raw?.let {
            val side = min(it.width, it.height)
            Bitmap.createBitmap(it, (it.width - side) / 2, (it.height - side) / 2, side, side)
        }
    } catch (e: Exception) { null }

    fun create() {
        val s = _state.value
        val app = s.selected ?: return
        val label = s.name.trim()
        if (label.isEmpty() || s.busy != null) return

        val ctx = getApplication<Application>()
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            _state.update { it.copy(needsInstallPermission = true) }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(busy = "Reading app…") }
            val built = withContext(Dispatchers.IO) { runCatching { build(app, label, s.icon) } }
            built.onSuccess { (files, record, warnings) ->
                pending = record
                _state.update {
                    it.copy(busy = "Waiting for confirmation…", message = warnings.firstOrNull())
                }
                try {
                    ApkInstaller.install(ctx, files, record.clonePackage)
                } catch (e: Exception) {
                    pending = null
                    _state.update { it.copy(busy = null, message = "Install failed: ${e.message}") }
                }
            }.onFailure { e ->
                _state.update { it.copy(busy = null, message = "Couldn’t build: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    private data class Built(val files: List<File>, val record: CloneRecord, val warnings: List<String>)

    private fun build(app: AppEntry, label: String, icon: Bitmap?): Built {
        val ctx = getApplication<Application>()
        val sources = repo.apkPaths(app.packageName)
        val newPkg = app.packageName + ".rk" + System.currentTimeMillis().toString(36)
        val work = File(ctx.cacheDir, "work").apply { deleteRecursively(); mkdirs() }

        val req = PatchRequest(app.packageName, newPkg, label, icon)
        val patcher = ApkPatcher()
        val signer = ApkSignerHelper(ctx)
        val warnings = mutableListOf<String>()
        val out = mutableListOf<File>()

        sources.forEachIndexed { i, path ->
            val base = if (i == 0) "base" else "split_$i"
            val patched = File(work, "$base.patched")
            val aligned = File(work, "$base.aligned")
            val signed = File(work, "$base.apk")

            _state.update { it.copy(busy = if (i == 0) "Editing manifest and icon…" else "Editing split $i of ${sources.size - 1}…") }
            if (i == 0) warnings += patcher.patchBase(File(path), patched, req)
            else patcher.patchSplit(File(path), patched, req)

            _state.update { it.copy(busy = "Aligning and signing…") }
            ZipAligner.align(patched, aligned)
            signer.sign(aligned, signed)
            patched.delete(); aligned.delete()
            out += signed
        }
        return Built(out, CloneRecord(app.packageName, newPkg, label), warnings)
    }
}
