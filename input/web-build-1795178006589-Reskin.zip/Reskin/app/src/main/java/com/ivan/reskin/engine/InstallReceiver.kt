package com.ivan.reskin.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build

class InstallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_INTENT)
                }
                confirm?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(it)
                }
            }
            PackageInstaller.STATUS_SUCCESS ->
                InstallEvents.flow.tryEmit(
                    InstallResult.Success(intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME))
                )
            PackageInstaller.STATUS_FAILURE_ABORTED ->
                InstallEvents.flow.tryEmit(InstallResult.Failure("Install cancelled"))
            else ->
                InstallEvents.flow.tryEmit(
                    InstallResult.Failure(
                        intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "Install failed"
                    )
                )
        }
    }

    companion object { const val ACTION = "com.ivan.reskin.INSTALL_RESULT" }
}
