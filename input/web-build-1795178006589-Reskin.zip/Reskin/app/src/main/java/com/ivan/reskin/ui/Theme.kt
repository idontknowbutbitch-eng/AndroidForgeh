package com.ivan.reskin.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.ivan.reskin.R

object Ink {
    val Bg = Color(0xFF000000)
    val Surface = Color(0xFF0C0C0E)
    val Raised = Color(0xFF161618)
    val Line = Color(0xFF242427)
    val Text = Color(0xFFF5F5F7)
    val Dim = Color(0xFF8E8E93)
    val Faint = Color(0xFF55555A)
    val Accent = Color(0xFF8AB4FF)
    val Danger = Color(0xFFFF6B6B)
}

/** Only the Regular file exists, so every weight maps to it (no synthetic bold). */
val SfPro = FontFamily(
    Font(R.font.sf_pro_display_regular, FontWeight.Normal),
    Font(R.font.sf_pro_display_regular, FontWeight.Medium),
    Font(R.font.sf_pro_display_regular, FontWeight.SemiBold),
    Font(R.font.sf_pro_display_regular, FontWeight.Bold),
)

private val base = Typography()
private val AppTypography = Typography(
    displayLarge = base.displayLarge.copy(fontFamily = SfPro),
    displayMedium = base.displayMedium.copy(fontFamily = SfPro),
    displaySmall = base.displaySmall.copy(fontFamily = SfPro),
    headlineLarge = base.headlineLarge.copy(fontFamily = SfPro),
    headlineMedium = base.headlineMedium.copy(fontFamily = SfPro),
    headlineSmall = base.headlineSmall.copy(fontFamily = SfPro),
    titleLarge = base.titleLarge.copy(fontFamily = SfPro),
    titleMedium = base.titleMedium.copy(fontFamily = SfPro),
    titleSmall = base.titleSmall.copy(fontFamily = SfPro),
    bodyLarge = base.bodyLarge.copy(fontFamily = SfPro),
    bodyMedium = base.bodyMedium.copy(fontFamily = SfPro),
    bodySmall = base.bodySmall.copy(fontFamily = SfPro),
    labelLarge = base.labelLarge.copy(fontFamily = SfPro),
    labelMedium = base.labelMedium.copy(fontFamily = SfPro),
    labelSmall = base.labelSmall.copy(fontFamily = SfPro),
)

private val Scheme = darkColorScheme(
    primary = Ink.Accent,
    onPrimary = Color.Black,
    background = Ink.Bg,
    onBackground = Ink.Text,
    surface = Ink.Surface,
    onSurface = Ink.Text,
    surfaceVariant = Ink.Raised,
    onSurfaceVariant = Ink.Dim,
    surfaceContainerHigh = Ink.Raised,
    surfaceContainerHighest = Ink.Raised,
    outline = Ink.Line,
    error = Ink.Danger,
)

@Composable
fun ReskinTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography, content = content)
}
