package com.ivan.reskin

import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ivan.reskin.ui.EditScreen
import com.ivan.reskin.ui.HomeScreen
import com.ivan.reskin.ui.Ink
import com.ivan.reskin.ui.ReskinTheme
import com.ivan.reskin.ui.ReskinViewModel
import com.ivan.reskin.ui.TextAction
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: ReskinViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        )
        setContent { ReskinTheme { Root(vm) } }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh() // picks up uninstalled copies
    }

    @Composable
    private fun Root(vm: ReskinViewModel) {
        val state by vm.state.collectAsStateWithLifecycle()

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let(vm::pickIcon)
        }

        BackHandler(enabled = state.selected != null) { vm.back() }

        Box(Modifier.fillMaxSize().background(Ink.Bg)) {
            AnimatedContent(
                targetState = state.selected,
                transitionSpec = {
                    if (targetState != null) {
                        (fadeIn(tween(220)) + slideInHorizontally(tween(260)) { it / 10 }) togetherWith fadeOut(tween(120))
                    } else {
                        fadeIn(tween(200)) togetherWith fadeOut(tween(120))
                    }
                },
                label = "screen",
            ) { app ->
                if (app == null) HomeScreen(state, vm)
                else EditScreen(state, app, vm) { picker.launch("image/*") }
            }

            AnimatedVisibility(
                visible = state.message != null,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                LaunchedEffect(state.message) {
                    delay(3800)
                    vm.consumeMessage()
                }
                Text(
                    state.message ?: "",
                    color = Ink.Text,
                    fontSize = 15.sp,
                    modifier = Modifier
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 96.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Ink.Raised)
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                )
            }

            if (state.needsInstallPermission) {
                AlertDialog(
                    onDismissRequest = vm::dismissPermission,
                    containerColor = Ink.Raised,
                    title = { Text("Allow installing", color = Ink.Text) },
                    text = {
                        Text(
                            "Reskin installs the edited copy itself. Turn on “Allow from this source”, then come back and tap Create again.",
                            color = Ink.Dim,
                        )
                    },
                    confirmButton = {
                        TextAction("Open settings", {
                            vm.dismissPermission()
                            startActivity(
                                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                            )
                        })
                    },
                    dismissButton = { TextAction("Not now", vm::dismissPermission, Ink.Dim) },
                )
            }
        }
    }
}
