package com.ivan.reskin.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Remembers which edited copies this app created. */
class CloneStore(context: Context) {
    private val prefs = context.getSharedPreferences("clones", Context.MODE_PRIVATE)

    fun all(): List<CloneRecord> {
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            CloneRecord(o.getString("o"), o.getString("c"), o.getString("l"))
        }
    }

    fun add(r: CloneRecord) = save(all().filterNot { it.clonePackage == r.clonePackage } + r)

    fun remove(clonePackage: String) = save(all().filterNot { it.clonePackage == clonePackage })

    private fun save(list: List<CloneRecord>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("o", it.originalPackage).put("c", it.clonePackage).put("l", it.label))
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private companion object { const val KEY = "list" }
}
