package com.ivan.reskin.engine

import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Minimal zipalign: STORED entries start on a 4-byte boundary (.so files on 4096),
 * which Android 11+ requires for an uncompressed resources.arsc.
 */
object ZipAligner {

    private class Counting(out: OutputStream) : FilterOutputStream(out) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    fun align(input: File, output: File) {
        ZipFile(input).use { zf ->
            val counting = Counting(FileOutputStream(output).buffered())
            ZipOutputStream(counting).use { zos ->
                for (src in zf.entries()) {
                    if (src.isDirectory) continue
                    zos.closeEntry() // flush the previous entry so `counting.count` is exact
                    val name = src.name
                    val dst = ZipEntry(name)

                    val stored = src.method == ZipEntry.STORED || name == "resources.arsc"
                    if (stored) {
                        dst.method = ZipEntry.STORED
                        dst.size = src.size
                        dst.compressedSize = src.size
                        dst.crc = src.crc
                        val alignment = if (name.endsWith(".so")) 4096 else 4
                        val dataStart = counting.count + 30 + name.toByteArray(Charsets.UTF_8).size
                        val need = ((alignment - (dataStart % alignment)) % alignment).toInt()
                        if (need > 0) {
                            val pad = if (need >= 4) need else need + alignment
                            val extra = ByteArray(pad)
                            extra[0] = 0x35; extra[1] = 0xD9.toByte() // 0xD935 = zipalign padding id
                            extra[2] = ((pad - 4) and 0xFF).toByte()
                            extra[3] = (((pad - 4) shr 8) and 0xFF).toByte()
                            dst.extra = extra
                        }
                    }
                    zos.putNextEntry(dst)
                    zf.getInputStream(src).use { it.copyTo(zos) }
                }
            }
        }
    }
}
