package com.ivan.reskin.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ivan.reskin.R
import com.ivan.reskin.data.AppEntry
import com.ivan.reskin.data.CloneRecord

@Composable
fun HomeScreen(state: UiState, vm: ReskinViewModel) {
    val ctx = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .background(Ink.Bg)
            .statusBarsPadding()
    ) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 16.dp)) {
            Text("Reskin", color = Ink.Text, fontSize = 38.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Change an app’s name and icon. The original stays untouched.",
                color = Ink.Dim, fontSize = 15.sp, lineHeight = 21.sp,
            )
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Segmented(
                listOf(R.drawable.ic_apps to "Apps", R.drawable.ic_layers to "Edited"),
                state.tab, vm::setTab,
            )
            if (state.tab == 0) {
                Spacer(Modifier.height(12.dp))
                SearchField(state.query, vm::setQuery)
            }
            Spacer(Modifier.height(8.dp))
        }

        val bottom = WindowInsets.navigationBars.asPaddingValues()
        if (state.tab == 0) {
            val q = state.query.trim()
            val list = if (q.isEmpty()) state.apps
            else state.apps.filter { it.label.contains(q, true) || it.packageName.contains(q, true) }

            when {
                state.loading -> Centered { CircularProgressIndicator(color = Ink.Accent, strokeWidth = 2.dp) }
                list.isEmpty() -> Centered { Text("No apps match “$q”", color = Ink.Dim, fontSize = 15.sp) }
                else -> LazyColumn(contentPadding = PaddingValues(bottom = bottom.calculateBottomPadding() + 16.dp)) {
                    items(list, key = { it.packageName }) { app -> AppRow(app) { vm.select(app) } }
                }
            }
        } else {
            if (state.clones.isEmpty()) {
                Centered {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 40.dp)) {
                        Icon(painterResource(R.drawable.ic_layers), null, Modifier.size(36.dp), Ink.Faint)
                        Spacer(Modifier.height(12.dp))
                        Text("Nothing edited yet", color = Ink.Text, fontSize = 17.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Pick an app from the Apps tab to make your first copy.", color = Ink.Dim, fontSize = 15.sp, lineHeight = 21.sp)
                    }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = bottom.calculateBottomPadding() + 16.dp)) {
                    items(state.clones, key = { it.clonePackage }) { c -> CloneRow(c, ctx, vm) }
                }
            }
        }
    }
}

@Composable
private fun Centered(content: @Composable () -> Unit) =
    Box(Modifier.fillMaxSize().padding(bottom = 80.dp), contentAlignment = Alignment.Center) { content() }

@Composable
private fun AppRow(app: AppEntry, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PackageIcon(app.packageName, 50.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(app.label, color = Ink.Text, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(app.packageName, color = Ink.Faint, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(painterResource(R.drawable.ic_chevron), null, Modifier.size(22.dp), Ink.Faint)
    }
}

@Composable
private fun CloneRow(c: CloneRecord, ctx: android.content.Context, vm: ReskinViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PackageIcon(c.clonePackage, 50.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(c.label, color = Ink.Text, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Copy of ${c.originalPackage}", color = Ink.Faint, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlyphButton(R.drawable.ic_open, {
                ctx.packageManager.getLaunchIntentForPackage(c.clonePackage)?.let(ctx::startActivity)
            })
            GlyphButton(R.drawable.ic_trash, {
                val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:${c.clonePackage}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            }, Ink.Danger)
        }
    }
}
