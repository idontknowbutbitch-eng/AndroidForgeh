package com.ivan.reskin.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.util.LruCache
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppRepository(private val context: Context) {
    private val pm = context.packageManager

    @Suppress("DEPRECATION")
    suspend fun launchableApps(): List<AppEntry> = withContext(Dispatchers.IO) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != context.packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
            .map { AppEntry(it.first, it.second) }
    }

    /** base.apk first, then split APKs. */
    @Suppress("DEPRECATION")
    fun apkPaths(pkg: String): List<String> {
        val ai = pm.getApplicationInfo(pkg, 0)
        return listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
    }

    fun isInstalled(pkg: String): Boolean = try {
        @Suppress("DEPRECATION") pm.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }
}

object IconCache {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun get(context: Context, pkg: String): Bitmap? = cache[pkg] ?: try {
        context.packageManager.getApplicationIcon(pkg).toBitmap(144, 144).also { cache.put(pkg, it) }
    } catch (e: Exception) { null }
}
