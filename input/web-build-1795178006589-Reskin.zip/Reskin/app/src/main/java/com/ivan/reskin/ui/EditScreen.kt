package com.ivan.reskin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ivan.reskin.R
import com.ivan.reskin.data.AppEntry

@Composable
fun EditScreen(state: UiState, app: AppEntry, vm: ReskinViewModel, onPickIcon: () -> Unit) {
    val busy = state.busy != null
    Column(
        Modifier
            .fillMaxSize()
            .background(Ink.Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlyphButton(R.drawable.ic_back, { vm.back() })
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Edit copy", color = Ink.Text, fontSize = 20.sp)
                Text(app.label, color = Ink.Dim, fontSize = 13.sp, maxLines = 1)
            }
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(28.dp))

            Box(Modifier.clickable(enabled = !busy, onClick = onPickIcon)) {
                if (state.icon != null) AppIcon(state.icon.asImageBitmap(), 124.dp)
                else PackageIcon(app.packageName, 124.dp)
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Ink.Text),
                    contentAlignment = Alignment.Center,
                ) { Icon(painterResource(R.drawable.ic_image), null, Modifier.size(20.dp), androidx.compose.ui.graphics.Color.Black) }
            }

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.Center) {
                TextAction("Choose image", onPickIcon)
                if (state.icon != null) TextAction("Use original", vm::resetIcon, Ink.Dim)
            }

            Spacer(Modifier.height(28.dp))
            Text("Name", color = Ink.Dim, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(start = 4.dp, bottom = 8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Ink.Raised)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                BasicTextField(
                    value = state.name,
                    onValueChange = vm::setName,
                    enabled = !busy,
                    singleLine = true,
                    textStyle = TextStyle(color = Ink.Text, fontSize = 18.sp, fontFamily = SfPro),
                    cursorBrush = SolidColor(Ink.Accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(Modifier.height(24.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Ink.Surface)
                    .padding(16.dp)
            ) {
                Text("Installs next to the original", color = Ink.Text, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "${app.packageName}.rk…",
                    color = Ink.Faint, fontSize = 13.sp,
                )
                Spacer(Modifier.height(10.dp))
                Hairline()
                Spacer(Modifier.height(10.dp))
                Text(
                    "The copy starts with empty data, so you sign in again. Apps that check their own signature may not open.",
                    color = Ink.Dim, fontSize = 14.sp, lineHeight = 20.sp,
                )
            }
            Spacer(Modifier.height(24.dp))
        }

        Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            if (busy) {
                Row(
                    Modifier.fillMaxWidth().height(54.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = Ink.Accent, strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(state.busy ?: "", color = Ink.Dim, fontSize = 16.sp)
                }
            } else {
                PrimaryButton("Create and install", state.name.isNotBlank(), vm::create)
            }
        }
    }
}
