# Memo

A minimal notes app that is also a full browser. The home screen is a notes list and editor; the globe icon opens a WebView browser with tabs, bookmarks, history, downloads and PIN-protected private tabs.

Android 10+ (minSdk 29). Kotlin, Material 3, WebView, SQLite (no extra dependencies, no Room/KSP).

## Features
- Notes: create, edit, delete (long-press a note or use the bin), live search, autosave, stored locally in SQLite.
- Browser: address/search bar (Google), back, forward, reload/stop, progress bar, error pages, HTTPS (invalid certificates are blocked), downloads, file upload, fullscreen video, links to other apps, `target=_blank` opens a new tab. Memo can also be chosen to open web links.
- "Home" in the browser returns to the notes screen.
- Tabs: previews, titles, favicons, create/close/switch, drag the grip icon to reorder. Tabs and their back/forward history are restored after a restart.
- Privacy: long-press a tab, "Move to Privacy". Private tabs are only listed in the Privacy segment, need a PIN (created on first use), save no history/bookmarks, hide screenshots (FLAG_SECURE), and lock again when you leave the app. Long-press one and "Restore to Tabs" to move it back. Moving only flips a flag on the same tab, so nothing is deleted.

## Get an installable APK from a phone only
Android phones cannot build this directly, so use GitHub's free build servers:
1. Make a free GitHub account and create a new empty repository.
2. Open the repo in a browser (Chrome menu > Desktop site), press `.`/Code > Codespaces > Create codespace.
3. In the Codespace Explorer, upload `Memo.zip`, then in its terminal run:
   `unzip Memo.zip -d tmp && cp -a tmp/Memo/. . && rm -rf tmp Memo.zip && git add -A && git commit -m init && git push`
4. Open the repo's **Actions** tab > **Build APK** > the latest run > download the **Memo-debug-apk** artifact.
5. Unzip it with your Files app and open `app-debug.apk`. Allow "Install unknown apps" for your browser/Files app when asked.

## Build on a computer
Open the `Memo` folder in Android Studio (Koala or newer, JDK 17), let Gradle sync, then Run, or Build > Build APK(s). From a terminal with Gradle 8.7 installed: `gradle assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`.

## Known limits
- Written without access to an Android SDK, so it was not compiled or run here. If the build prints an error, send me the log and I will fix it.
- The PIN gate protects access inside the app. Private tab data is stored unencrypted in the app's private storage, and WebView shares cookies/cache between normal and private tabs (Android WebView has no separate private profile).
- A forgotten PIN can only be reset by clearing the app's data, which also erases private tabs.
- Notifications permission, location, camera and microphone requests from websites are not granted.
