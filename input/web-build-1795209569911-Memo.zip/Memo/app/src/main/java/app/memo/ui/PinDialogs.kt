package app.memo.ui

import android.content.DialogInterface
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import app.memo.MainActivity
import app.memo.data.Pin
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object PinDialogs {
    private fun field(act: MainActivity, h: String) = EditText(act).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        hint = h
        gravity = Gravity.CENTER
        textSize = 20f
        filters = arrayOf<InputFilter>(InputFilter.LengthFilter(8))
    }

    private fun box(act: MainActivity, vararg v: View) = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(act.dp(24), act.dp(8), act.dp(24), 0)
        v.forEach { addView(it, LinearLayout.LayoutParams(MATCH, WRAP)) }
    }

    fun verify(act: MainActivity, onOk: () -> Unit) {
        val pin = field(act, "PIN")
        val d = MaterialAlertDialogBuilder(act)
            .setTitle("Privacy")
            .setMessage("Enter your PIN to open private tabs.")
            .setView(box(act, pin))
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Unlock", null)
            .create()
        d.setOnShowListener {
            pin.requestFocus()
            d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
            d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (Pin.verify(act, pin.text.toString())) {
                    d.dismiss()
                    onOk()
                } else {
                    pin.error = "Wrong PIN"
                    pin.setText("")
                }
            }
        }
        d.show()
    }

    fun setup(act: MainActivity, onDone: () -> Unit) {
        val a = field(act, "New PIN (4–8 digits)")
        val b = field(act, "Repeat PIN")
        val d = MaterialAlertDialogBuilder(act)
            .setTitle("Create a PIN")
            .setMessage("This PIN locks your private tabs. If you forget it, the only way to reset it is to clear the app's data, which erases private tabs.")
            .setView(box(act, a, b))
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
            .create()
        d.setOnShowListener {
            a.requestFocus()
            d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
            d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val x = a.text.toString()
                if (x.length < 4) {
                    a.error = "Use at least 4 digits"
                } else if (x != b.text.toString()) {
                    b.error = "PINs don't match"
                } else {
                    Pin.set(act, x)
                    d.dismiss()
                    onDone()
                }
            }
        }
        d.show()
    }
}
