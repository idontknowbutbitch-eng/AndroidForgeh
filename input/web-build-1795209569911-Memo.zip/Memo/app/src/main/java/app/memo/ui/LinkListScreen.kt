package app.memo.ui

import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.memo.MainActivity
import app.memo.R
import app.memo.data.Link
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Shared list screen for bookmarks and history. */
class LinkListScreen(act: MainActivity, private val history: Boolean) : Screen(act) {
    private var items: List<Link> = emptyList()
    private val rv = RecyclerView(act)
    private val empty = act.label(if (history) "No history yet." else "No bookmarks yet.", 15f, R.color.text2)
    private val adapter = RowAdapter()

    init {
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), 0)
        }
        val head = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(act.iconButton(R.drawable.ic_back, "Back") { act.back() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        head.addView(act.label(if (history) "History" else "Bookmarks", 22f, R.color.text, true).apply {
            setPadding(dp(8), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (history) {
            head.addView(act.label("Clear", 16f, R.color.accent_text, true).apply {
                setPadding(dp(16), dp(10), dp(16), dp(10))
                setOnClickListener { confirmClear() }
            }, LinearLayout.LayoutParams(WRAP, WRAP))
        }
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        col.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
    }

    override fun refresh() {
        super.refresh()
        items = if (history) act.db.history() else act.db.bookmarks()
        adapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmClear() {
        MaterialAlertDialogBuilder(act).setTitle("Clear all history?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ -> act.db.clearHistory(); refresh() }
            .show()
    }

    private class VH(v: View, val title: TextView, val url: TextView, val del: ImageButton) : RecyclerView.ViewHolder(v)

    private inner class RowAdapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = items.size

        override fun onCreateViewHolder(p: ViewGroup, type: Int): VH {
            val row = LinearLayout(act).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(4), dp(8))
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            }
            val texts = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            val title = act.label("", 15.5f, R.color.text, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            val url = act.label("", 12.5f, R.color.text2).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            texts.addView(title); texts.addView(url)
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
            val del = act.iconButton(R.drawable.ic_close, "Delete", act.getColor(R.color.text2)) {}
            row.addView(del, LinearLayout.LayoutParams(dp(44), dp(44)))
            return VH(row, title, url, del)
        }

        override fun onBindViewHolder(h: VH, i: Int) {
            val l = items[i]
            h.title.text = l.title.ifBlank { l.url }
            h.url.text = l.url
            h.itemView.setOnClickListener { act.openUrl(l.url) }
            h.del.setOnClickListener {
                if (history) act.db.deleteHistory(l.id) else act.db.deleteBookmark(l.id)
                refresh()
            }
        }
    }
}
