package app.memo.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import app.memo.MainActivity
import app.memo.R

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rounded(fill: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
    }

fun Context.tinted(res: Int, color: Int): Drawable = getDrawable(res)!!.mutate().also { it.setTint(color) }

fun Context.label(s: String, sp: Float, colorRes: Int = R.color.text, medium: Boolean = false): TextView =
    TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(getColor(colorRes))
        if (medium) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

fun Context.iconButton(res: Int, desc: String, tint: Int = getColor(R.color.text), onClick: () -> Unit): ImageButton =
    ImageButton(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(tint)
        contentDescription = desc
        val a = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
        background = a.getDrawable(0)
        a.recycle()
        setOnClickListener { onClick() }
    }

fun EditText.onChange(f: (String) -> Unit) = addTextChangedListener(object : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
})

/** Base class for full-screen views managed by MainActivity's simple navigation stack. */
abstract class Screen(val act: MainActivity) : FrameLayout(act) {
    init {
        setBackgroundColor(act.getColor(R.color.bg))
        isClickable = true
    }

    protected fun dp(n: Int) = act.dp(n)
    open fun refresh() { act.setSecure(false) }
    open fun onBack(): Boolean = false
    open fun flush() {}
    open fun onDestroyScreen() {}
    open fun showsPrivate(): Boolean = false
}
