package app.memo.data

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** PIN for the Privacy section. Only a salted PBKDF2 hash is stored. */
object Pin {
    private fun prefs(c: Context) = c.getSharedPreferences("memo_pin", Context.MODE_PRIVATE)

    fun isSet(c: Context) = prefs(c).contains("hash")

    fun set(c: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs(c).edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", hash(pin, salt))
            .apply()
    }

    fun verify(c: Context, pin: String): Boolean {
        val s = prefs(c).getString("salt", null) ?: return false
        val h = prefs(c).getString("hash", null) ?: return false
        return hash(pin, Base64.decode(s, Base64.NO_WRAP)) == h
    }

    private fun hash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 20000, 256)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return Base64.encodeToString(key, Base64.NO_WRAP)
    }
}
