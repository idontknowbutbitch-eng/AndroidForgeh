package app.memo.ui

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.text.TextUtils
import android.text.format.DateUtils
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.memo.MainActivity
import app.memo.R
import app.memo.data.Note
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.content.res.ColorStateList

class NotesScreen(act: MainActivity) : Screen(act) {
    private var items: List<Note> = emptyList()
    private val search = EditText(act)
    private val webRow = act.label("", 15f, R.color.accent_text, true)
    private val empty = act.label("", 15f, R.color.text2)
    private val rv = RecyclerView(act)
    private val adapter = NoteAdapter()

    init {
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val head = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(act.label("Notes", 34f, R.color.text, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(act.iconButton(R.drawable.ic_globe, "Open browser") { act.showBrowser() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        search.apply {
            hint = "Search notes or the web"
            textSize = 16f
            isSingleLine = true
            setTextColor(act.getColor(R.color.text))
            setHintTextColor(act.getColor(R.color.text2))
            background = act.rounded(act.getColor(R.color.surface), 14)
            setPadding(dp(14), 0, dp(14), 0)
            setCompoundDrawablesRelativeWithIntrinsicBounds(
                act.tinted(R.drawable.ic_search, act.getColor(R.color.text2)), null, null, null)
            compoundDrawablePadding = dp(10)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { v, _, _ -> act.hideKeyboard(v); true }
            onChange { reload() }
        }
        col.addView(search, LinearLayout.LayoutParams(MATCH, dp(46)).apply { topMargin = dp(12) })

        webRow.apply {
            setPadding(dp(4), dp(14), dp(4), dp(4))
            visibility = View.GONE
            setOnClickListener { act.openSearch(search.text.toString()) }
        }
        col.addView(webRow, LinearLayout.LayoutParams(MATCH, WRAP))

        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(0, dp(12), 0, dp(96))
        col.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        empty.gravity = Gravity.CENTER
        addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        val fab = FloatingActionButton(act).apply {
            setImageResource(R.drawable.ic_add)
            backgroundTintList = ColorStateList.valueOf(act.getColor(R.color.accent))
            imageTintList = ColorStateList.valueOf(act.getColor(R.color.on_accent))
            contentDescription = "New note"
            setOnClickListener { act.push(EditorScreen(act, null)) }
        }
        addView(fab, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(20), dp(24))
        })
    }

    override fun refresh() {
        super.refresh()
        reload()
    }

    private fun reload() {
        val q = search.text.toString().trim()
        items = act.db.notes(q)
        adapter.notifyDataSetChanged()
        empty.text = if (q.isEmpty()) "No notes yet.\nTap + to write one." else "No matching notes."
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        webRow.visibility = if (q.isEmpty()) View.GONE else View.VISIBLE
        webRow.text = "Search the web for “$q”"
    }

    private fun confirmDelete(n: Note) {
        MaterialAlertDialogBuilder(act).setTitle("Delete note?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> act.db.deleteNote(n.id); reload() }
            .show()
    }

    private class VH(v: View, val title: TextView, val preview: TextView, val date: TextView) : RecyclerView.ViewHolder(v)

    private inner class NoteAdapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = items.size

        override fun onCreateViewHolder(p: ViewGroup, type: Int): VH {
            val card = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = act.rounded(act.getColor(R.color.surface), 16)
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) }
            }
            val title = act.label("", 16f, R.color.text, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            val prev = act.label("", 14f, R.color.text2).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0) }
            val date = act.label("", 12f, R.color.text2).apply { setPadding(0, dp(6), 0, 0) }
            card.addView(title); card.addView(prev); card.addView(date)
            return VH(card, title, prev, date)
        }

        override fun onBindViewHolder(h: VH, i: Int) {
            val n = items[i]
            val firstLine = n.body.lineSequence().firstOrNull { it.isNotBlank() }?.trim() ?: ""
            h.title.text = n.title.ifBlank { firstLine.ifBlank { "Untitled" } }
            h.preview.text = n.body.trim().replace("\n", " ")
            h.preview.visibility = if (h.preview.text.isEmpty()) View.GONE else View.VISIBLE
            val sameDay = DateUtils.isToday(n.updated)
            h.date.text = DateUtils.formatDateTime(act, n.updated,
                if (sameDay) DateUtils.FORMAT_SHOW_TIME else DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH)
            h.itemView.setOnClickListener { act.push(EditorScreen(act, n)) }
            h.itemView.setOnLongClickListener { confirmDelete(n); true }
        }
    }
}
