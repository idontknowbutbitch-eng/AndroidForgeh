package app.memo

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.memo.data.Db
import app.memo.data.Pin
import app.memo.ui.BrowserScreen
import app.memo.ui.MATCH
import app.memo.ui.NotesScreen
import app.memo.ui.PinDialogs
import app.memo.ui.Screen
import app.memo.ui.dp
import app.memo.web.TabManager
import app.memo.web.Url

/** Single activity hosting a tiny navigation stack of full-screen Screens. */
class MainActivity : AppCompatActivity() {
    lateinit var db: Db
    lateinit var tabs: TabManager
    private lateinit var root: FrameLayout
    private val stack = ArrayList<Screen>()
    var privateUnlocked = false

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        tabs = TabManager(this, db)
        tabs.restore()
        root = FrameLayout(this)
        setContentView(root)
        push(NotesScreen(this))
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) hideCustomView()
                else if (!stack.last().onBack()) {
                    if (stack.size > 1) pop() else finish()
                }
            }
        })
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val u = i?.dataString
        if (i?.action == Intent.ACTION_VIEW && u != null) {
            tabs.newTab(u)
            showBrowser()
        }
    }

    override fun onStop() {
        super.onStop()
        stack.lastOrNull()?.flush()
        tabs.saveAll()
        lockPrivate()
    }

    override fun onDestroy() {
        super.onDestroy()
        tabs.destroy()
        db.close()
    }

    /** Leaving the app locks Privacy: private screens close and the active tab becomes a normal one. */
    private fun lockPrivate() {
        privateUnlocked = false
        if (stack.any { it.showsPrivate() }) popToRoot()
        if (tabs.active?.isPrivate == true) tabs.active = null
        setSecure(false)
    }

    // ---- navigation ----
    fun push(s: Screen) {
        val prev = stack.lastOrNull()
        stack.add(s)
        root.addView(s, FrameLayout.LayoutParams(MATCH, MATCH))
        if (prev != null) {
            s.alpha = 0f
            s.translationX = dp(28).toFloat()
            s.animate().alpha(1f).translationX(0f).setDuration(220)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction { if (stack.lastOrNull() !== prev) prev.visibility = View.GONE }
                .start()
        }
        s.refresh()
    }

    fun pop(animated: Boolean = true) {
        if (stack.size < 2) return
        val top = stack.removeAt(stack.size - 1)
        top.flush()
        val below = stack.last()
        below.visibility = View.VISIBLE
        below.refresh()
        val done = { top.onDestroyScreen(); root.removeView(top) }
        if (animated) {
            top.animate().alpha(0f).translationX(dp(28).toFloat()).setDuration(180)
                .withEndAction { done() }.start()
        } else done()
    }

    private fun popToRoot() { while (stack.size > 1) pop(false) }

    fun goHome() = popToRoot()

    fun back() { onBackPressedDispatcher.onBackPressed() }

    fun showBrowser() {
        val b = stack.lastOrNull { it is BrowserScreen } as BrowserScreen?
        if (b == null) { push(BrowserScreen(this)); return }
        while (stack.last() !== b) pop(stack.getOrNull(stack.size - 2) === b)
        b.rebind()
        b.refresh()
    }

    fun openSearch(q: String) {
        val u = Url.resolve(q)
        if (u.isEmpty()) return
        tabs.newTab(u)
        showBrowser()
    }

    fun openUrl(url: String) {
        val t = tabs.ensureActive()
        tabs.load(t, url)
        showBrowser()
    }

    /** Runs [then] once the PIN has been entered (or created on first use). */
    fun requirePin(then: () -> Unit) {
        if (privateUnlocked) { then(); return }
        if (!Pin.isSet(this)) PinDialogs.setup(this) { privateUnlocked = true; then() }
        else PinDialogs.verify(this) { privateUnlocked = true; then() }
    }

    // ---- helpers used by the web layer ----
    fun setSecure(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun showKeyboard(v: View) {
        v.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard(v: View) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    fun chooseFile(cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams): Boolean {
        fileCb?.onReceiveValue(null)
        fileCb = cb
        return try {
            chooser.launch(p.createIntent())
            true
        } catch (e: Exception) {
            fileCb = null
            cb.onReceiveValue(null)
            false
        }
    }

    fun showCustomView(v: View, cb: WebChromeClient.CustomViewCallback) {
        if (customView != null) { cb.onCustomViewHidden(); return }
        customView = v
        customCb = cb
        v.setBackgroundColor(0xFF000000.toInt())
        (window.decorView as FrameLayout).addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    fun hideCustomView() {
        customView?.let { (window.decorView as FrameLayout).removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }
}
