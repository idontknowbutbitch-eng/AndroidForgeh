package app.memo.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import app.memo.MainActivity
import app.memo.R
import app.memo.data.Pin
import app.memo.web.Tab
import app.memo.web.Url
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Collections

/** Tab switcher with a Tabs / Privacy segmented control. */
class TabsScreen(act: MainActivity) : Screen(act) {
    private val tm = act.tabs
    private var privateMode = false
    private val items = ArrayList<Tab>()
    private val rv = RecyclerView(act)
    private val segTabs = seg("Tabs")
    private val segPriv = seg("Privacy")
    private val note = act.label("", 13f, R.color.text2)
    private val empty = act.label("", 15f, R.color.text2)
    private val adapter = TabAdapter()
    private val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
        ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
    ) {
        override fun isLongPressDragEnabled() = false

        override fun onMove(r: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
            val a = vh.bindingAdapterPosition
            val b = target.bindingAdapterPosition
            if (a < 0 || b < 0) return false
            Collections.swap(items, a, b)
            adapter.notifyItemMoved(a, b)
            return true
        }

        override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

        override fun clearView(r: RecyclerView, vh: RecyclerView.ViewHolder) {
            super.clearView(r, vh)
            tm.reorder(items)
        }
    })

    private fun seg(s: String) = act.label(s, 14f, R.color.text, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(18), dp(8), dp(18), dp(8))
    }

    init {
        tm.active?.let { tm.capture(it) }
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), 0)
        }
        val head = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        val segBox = LinearLayout(act).apply {
            background = act.rounded(act.getColor(R.color.seg), 12)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        segBox.addView(segTabs)
        segBox.addView(segPriv)
        head.addView(segBox, LinearLayout.LayoutParams(WRAP, WRAP))
        head.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
        head.addView(act.label("Done", 16f, R.color.accent_text, true).apply {
            setPadding(dp(12), dp(10), dp(6), dp(10))
            setOnClickListener { act.back() }
        })
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        note.setPadding(dp(4), dp(10), dp(4), dp(4))
        col.addView(note, LinearLayout.LayoutParams(MATCH, WRAP))

        rv.layoutManager = GridLayoutManager(act, if (act.resources.configuration.screenWidthDp >= 600) 3 else 2)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(0, dp(4), 0, dp(96))
        touch.attachToRecyclerView(rv)
        col.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        empty.gravity = Gravity.CENTER
        addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        val fab = FloatingActionButton(act).apply {
            setImageResource(R.drawable.ic_add)
            backgroundTintList = ColorStateList.valueOf(act.getColor(R.color.accent))
            imageTintList = ColorStateList.valueOf(act.getColor(R.color.on_accent))
            contentDescription = "New tab"
            setOnClickListener {
                if (privateMode) tm.newTab("", true) else tm.newTab()
                act.showBrowser()
            }
        }
        addView(fab, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(20), dp(24))
        })

        segTabs.setOnClickListener { privateMode = false; load() }
        segPriv.setOnClickListener { act.requirePin { privateMode = true; load() } }
        load()
    }

    override fun refresh() { load() }
    override fun showsPrivate() = privateMode

    private fun load() {
        items.clear()
        items.addAll(tm.all.filter { it.isPrivate == privateMode })
        adapter.notifyDataSetChanged()
        styleSeg(segTabs, !privateMode)
        styleSeg(segPriv, privateMode)
        note.visibility = if (privateMode) View.VISIBLE else View.GONE
        note.text = "Private tabs are hidden from your regular tabs and locked with your PIN. Long-press a tab to restore it."
        empty.text = if (privateMode) "No private tabs.\nLong-press a tab in Tabs to move it here." else "No open tabs."
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        act.setSecure(privateMode)
    }

    private fun styleSeg(v: TextView, on: Boolean) {
        v.background = if (on) act.rounded(act.getColor(R.color.seg_on), 10) else null
        v.setTextColor(act.getColor(if (on) R.color.text else R.color.text2))
    }

    private fun menu(anchor: View, t: Tab) {
        val pm = PopupMenu(act, anchor)
        pm.menu.add(0, 1, 0, if (t.isPrivate) "Restore to Tabs" else "Move to Privacy")
        pm.menu.add(0, 2, 1, "Close tab")
        pm.setOnMenuItemClickListener {
            if (it.itemId == 1) {
                if (t.isPrivate) { tm.setPrivate(t, false); load() } else toPrivate(t)
            } else {
                tm.close(t); load()
            }
            true
        }
        pm.show()
    }

    private fun toPrivate(t: Tab) {
        val go = { tm.setPrivate(t, true); load() }
        if (Pin.isSet(act)) go() else PinDialogs.setup(act) { act.privateUnlocked = true; go() }
    }

    private class Holder(
        val card: LinearLayout, val thumb: ImageView, val fav: ImageView,
        val title: TextView, val close: ImageButton, val grip: ImageView
    ) : RecyclerView.ViewHolder(card)

    private inner class TabAdapter : RecyclerView.Adapter<Holder>() {
        override fun getItemCount() = items.size

        private fun chip(res: Int, gravity: Int): ImageButton = ImageButton(act).apply {
            setImageResource(res)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            background = act.rounded(0x88000000.toInt(), 15)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(7), dp(7), dp(7), dp(7))
        }

        override fun onCreateViewHolder(p: ViewGroup, type: Int): Holder {
            val card = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                clipToOutline = true
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            }
            val top = FrameLayout(act)
            val thumb = ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(act.getColor(R.color.bg))
            }
            top.addView(thumb, FrameLayout.LayoutParams(MATCH, dp(170)))
            val m = dp(6)
            val close = chip(R.drawable.ic_close, 0)
            top.addView(close, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.END).apply { setMargins(m, m, m, m) })
            val grip = chip(R.drawable.ic_drag, 0)
            top.addView(grip, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.START).apply { setMargins(m, m, m, m) })
            val row = LinearLayout(act).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
            }
            val fav = ImageView(act)
            val title = act.label("", 13f, R.color.text, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(8), 0, 0, 0)
            }
            row.addView(fav, LinearLayout.LayoutParams(dp(16), dp(16)))
            row.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
            card.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
            card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            return Holder(card, thumb, fav, title, close, grip)
        }

        override fun onBindViewHolder(h: Holder, i: Int) {
            val t = items[i]
            h.title.text = t.title.ifBlank { Url.display(t.url).ifBlank { "New tab" } }
            h.thumb.setImageBitmap(tm.thumbOf(t))
            val icon = tm.iconOf(t)
            if (icon != null) {
                h.fav.imageTintList = null
                h.fav.setImageBitmap(icon)
            } else {
                h.fav.setImageResource(if (t.isPrivate) R.drawable.ic_lock else R.drawable.ic_globe)
                h.fav.imageTintList = ColorStateList.valueOf(act.getColor(R.color.text2))
            }
            val stroke = if (t === tm.active) 2 else 0
            h.card.background = act.rounded(act.getColor(R.color.surface), 18, act.getColor(R.color.accent), stroke)
            h.card.setOnClickListener { tm.activate(t); act.showBrowser() }
            h.card.setOnLongClickListener { menu(it, t); true }
            h.close.setOnClickListener { tm.close(t); load() }
            h.grip.setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) touch.startDrag(h)
                false
            }
        }
    }
}
