package app.memo.ui

import android.app.DownloadManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import app.memo.MainActivity
import app.memo.R
import app.memo.web.Tab
import app.memo.web.TabListener
import app.memo.web.Url

/** Browser chrome: address pill on top, WebView in the middle, minimal toolbar below. */
class BrowserScreen(act: MainActivity) : Screen(act), TabListener {
    private val tm = act.tabs
    private val bar = EditText(act)
    private val lockIcon = ImageView(act)
    private val reloadBtn = act.iconButton(R.drawable.ic_reload, "Reload") { onReload() }
    private val backBtn = act.iconButton(R.drawable.ic_back, "Back") {
        tm.active?.webView?.let { if (it.canGoBack()) it.goBack() }
    }
    private val fwdBtn = act.iconButton(R.drawable.ic_forward, "Forward") {
        tm.active?.webView?.let { if (it.canGoForward()) it.goForward() }
    }
    private val homeBtn = act.iconButton(R.drawable.ic_home, "Home") { act.goHome() }
    private val menuBtn = act.iconButton(R.drawable.ic_more, "More") { showMenu() }
    private val tabsBtn = TextView(act)
    private val pill = LinearLayout(act)
    private val progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
    private val webFrame = FrameLayout(act)
    private val start = LinearLayout(act)

    init {
        tm.listener = this
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }

        lockIcon.imageTintList = ColorStateList.valueOf(act.getColor(R.color.text2))
        bar.apply {
            background = null
            textSize = 15f
            isSingleLine = true
            setTextColor(act.getColor(R.color.text))
            setHintTextColor(act.getColor(R.color.text2))
            hint = "Search or enter address"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setPadding(0, 0, 0, 0)
            setOnEditorActionListener { v, actionId, ev ->
                if (actionId == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                    go(v.text.toString()); true
                } else false
            }
            setOnFocusChangeListener { _, focused ->
                val t = tm.active
                if (focused) { setText(t?.url ?: ""); selectAll() } else setText(Url.display(t?.url ?: ""))
            }
        }
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(12), 0, dp(2), 0)
        pill.addView(lockIcon, LinearLayout.LayoutParams(dp(16), dp(16)))
        pill.addView(bar, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = dp(8) })
        pill.addView(reloadBtn, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(pill, LinearLayout.LayoutParams(MATCH, dp(44)).apply { setMargins(dp(12), dp(8), dp(12), dp(6)) })

        progress.max = 100
        progress.progressTintList = ColorStateList.valueOf(act.getColor(R.color.accent))
        progress.visibility = View.GONE
        col.addView(progress, LinearLayout.LayoutParams(MATCH, dp(3)))

        val content = FrameLayout(act)
        content.addView(webFrame, FrameLayout.LayoutParams(MATCH, MATCH))
        start.apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(act.getColor(R.color.bg))
            isClickable = true
        }
        content.addView(start, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        col.addView(View(act).apply { setBackgroundColor(act.getColor(R.color.divider)) }, LinearLayout.LayoutParams(MATCH, 1))
        val bottom = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        for (v in listOf<View>(backBtn, fwdBtn, homeBtn)) bottom.addView(v, LinearLayout.LayoutParams(0, dp(52), 1f))
        tabsBtn.apply {
            gravity = Gravity.CENTER
            textSize = 12f
            includeFontPadding = false
            setTextColor(act.getColor(R.color.text))
            background = act.rounded(Color.TRANSPARENT, 7, act.getColor(R.color.text), 2)
        }
        val tabsWrap = FrameLayout(act).apply { setOnClickListener { act.push(TabsScreen(act)) } }
        tabsWrap.addView(tabsBtn, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        bottom.addView(tabsWrap, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottom.addView(menuBtn, LinearLayout.LayoutParams(0, dp(52), 1f))
        col.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        rebind()
    }

    override fun onTabChanged(t: Tab) { if (t === tm.active) refreshChrome() }
    override fun onActiveChanged() { rebind() }
    override fun showsPrivate() = tm.active?.isPrivate == true

    override fun refresh() {
        act.setSecure(tm.active?.isPrivate == true)
        refreshChrome()
        if (tm.active?.url.isNullOrEmpty() && !bar.hasFocus()) bar.post { if (isShown) act.showKeyboard(bar) }
    }

    /** Attach the active tab's WebView (creating a blank tab if needed). */
    fun rebind() {
        val t = tm.ensureActive()
        (webFrame.getChildAt(0) as? android.webkit.WebView)?.onPause()
        webFrame.removeAllViews()
        if (t.url.isNotEmpty() || t.webView != null) attach(t)
        refreshStart(t)
        act.setSecure(t.isPrivate)
        refreshChrome()
        if (t.url.isEmpty()) bar.post { if (isShown) act.showKeyboard(bar) }
    }

    private fun attach(t: Tab) {
        val wv = tm.ensureWebView(t)
        if (wv.parent !== webFrame) {
            (wv.parent as? ViewGroup)?.removeView(wv)
            webFrame.removeAllViews()
            webFrame.addView(wv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        wv.onResume()
    }

    private fun go(input: String) {
        val u = Url.resolve(input)
        if (u.isEmpty()) return
        val t = tm.ensureActive()
        bar.clearFocus()
        act.hideKeyboard(bar)
        tm.load(t, u)
        attach(t)
        refreshChrome()
    }

    private fun onReload() {
        val t = tm.active ?: return
        val wv = t.webView ?: return
        if (t.loading) { wv.stopLoading(); t.loading = false } else wv.reload()
        refreshChrome()
    }

    private fun refreshChrome() {
        val t = tm.active ?: return
        pill.background = act.rounded(act.getColor(if (t.isPrivate) R.color.private_tint else R.color.surface), 14)
        if (!bar.hasFocus()) {
            val s = Url.display(t.url)
            if (bar.text.toString() != s) bar.setText(s)
        }
        lockIcon.visibility = if (t.url.isEmpty()) View.GONE else View.VISIBLE
        lockIcon.setImageResource(if (t.url.startsWith("https://")) R.drawable.ic_lock else R.drawable.ic_globe)
        reloadBtn.setImageResource(if (t.loading) R.drawable.ic_close else R.drawable.ic_reload)
        progress.visibility = if (t.loading && t.progress in 1..99) View.VISIBLE else View.GONE
        progress.progress = t.progress
        val wv = t.webView
        backBtn.alpha = if (wv?.canGoBack() == true) 1f else 0.3f
        fwdBtn.alpha = if (wv?.canGoForward() == true) 1f else 0.3f
        tabsBtn.text = tm.all.count { it.isPrivate == t.isPrivate }.toString()
        start.visibility = if (t.url.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun refreshStart(t: Tab) {
        start.removeAllViews()
        if (t.isPrivate) {
            start.addView(act.label("Private tab", 24f, R.color.private_accent, true))
            start.addView(act.label(
                "History and bookmarks aren't saved from private tabs. They stay locked behind your PIN.",
                14f, R.color.text2).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
            return
        }
        start.addView(act.label("New tab", 24f, R.color.text, true))
        val bms = act.db.bookmarks().take(6)
        if (bms.isEmpty()) {
            start.addView(act.label("Type an address or a search above.", 14f, R.color.text2)
                .apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
        } else {
            for (b in bms) {
                val row = act.label(b.title.ifBlank { Url.display(b.url) }, 15f, R.color.text).apply {
                    maxLines = 1
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                    background = act.rounded(act.getColor(R.color.surface), 14)
                    setOnClickListener { go(b.url) }
                }
                start.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
            }
        }
    }

    private fun showMenu() {
        val t = tm.active ?: return
        val pm = PopupMenu(act, menuBtn)
        val m = pm.menu
        m.add(0, 1, 0, "New tab")
        if (t.isPrivate) m.add(0, 2, 1, "New private tab")
        if (!t.isPrivate && t.url.isNotEmpty()) m.add(0, 3, 2, if (act.db.isBookmarked(t.url)) "Remove bookmark" else "Add bookmark")
        if (!t.isPrivate) {
            m.add(0, 4, 3, "Bookmarks")
            m.add(0, 5, 4, "History")
        }
        m.add(0, 6, 5, "Downloads")
        if (t.url.isNotEmpty()) m.add(0, 7, 6, "Share")
        m.add(0, 8, 7, "Notes")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> tm.newTab()
                2 -> tm.newTab("", true)
                3 -> {
                    val added = act.db.toggleBookmark(t.title.ifBlank { t.url }, t.url)
                    act.toast(if (added) "Bookmark added" else "Bookmark removed")
                }
                4 -> act.push(LinkListScreen(act, false))
                5 -> act.push(LinkListScreen(act, true))
                6 -> try { act.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (e: Exception) { act.toast("No downloads app found") }
                7 -> act.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, t.url)
                }, null))
                8 -> act.goHome()
            }
            true
        }
        pm.show()
    }

    override fun onBack(): Boolean {
        if (bar.hasFocus()) {
            bar.clearFocus()
            act.hideKeyboard(bar)
            return true
        }
        val wv = tm.active?.webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
            return true
        }
        return false
    }

    override fun onDestroyScreen() {
        (webFrame.getChildAt(0) as? android.webkit.WebView)?.let {
            it.onPause()
            webFrame.removeView(it)
        }
        if (tm.listener === this) tm.listener = null
    }
}
