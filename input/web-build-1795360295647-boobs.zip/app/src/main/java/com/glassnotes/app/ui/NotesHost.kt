package com.glassnotes.app.ui

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.glassnotes.app.MainActivity
import com.glassnotes.app.R
import com.glassnotes.app.data.Note
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Notes home: glass list of notes (Pinned + by month) and Settings, switched by a floating glass bar.
 * Three quick taps on the Settings tab open the hidden area.
 */
class NotesHost(act: MainActivity) : BScreen(act, act.isNight()) {
    private val night = act.isNight()
    private val ink = act.getColor(R.color.text)
    private val dim = act.getColor(R.color.text2)
    private val handler = Handler(Looper.getMainLooper())
    private var tab = act.prefs.tab
    private var taps = 0
    private val resetTaps = Runnable { taps = 0 }
    private var lastX = 0
    private var lastY = 0

    private val page = FrameLayout(act)
    private val fab: View
    private val pill = View(act)
    private val tabViews = ArrayList<View>()
    private val tabW = dp(92)

    init {
        addView(page, FrameLayout.LayoutParams(MATCH, MATCH))

        // floating compose button (glass circle)
        fab = act.circleButton(R.drawable.ic_compose, "New note", night) { act.push(EditorScreen(act, null)) }
        addView(fab, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(18), dp(92))
        })

        // floating glass bar with a sliding pill
        val nav = FrameLayout(act).apply {
            background = act.rounded(
                if (night) Color.argb(31, 255, 255, 255) else Color.argb(140, 255, 255, 255), 28,
                if (night) Color.argb(56, 255, 255, 255) else Color.argb(26, 0, 0, 0), 1)
            elevation = dp(10).toFloat()
        }
        pill.background = act.rounded(
            if (night) Color.argb(140, 0, 0, 0) else Color.argb(20, 0, 0, 0), 30,
            if (night) Color.argb(66, 255, 255, 255) else Color.argb(31, 0, 0, 0), 1)
        nav.addView(pill, FrameLayout.LayoutParams(tabW - dp(10), dp(45), Gravity.CENTER_VERTICAL).apply { marginStart = dp(5) })
        val row = LinearLayout(act)
        val items = listOf(Triple(R.drawable.ic_home, "Notes", 0), Triple(R.drawable.ic_settings, "Settings", 1))
        for ((icon, name, idx) in items) {
            val t = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener {
                    if (idx == 1) settingsTap()
                    show(idx)
                }
            }
            t.addView(ImageView(act).apply {
                setImageResource(icon)
                imageTintList = ColorStateList.valueOf(ink)
            }, LinearLayout.LayoutParams(dp(21), dp(21)))
            t.addView(act.labelC(name, 11f, ink).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) },
                LinearLayout.LayoutParams(WRAP, WRAP))
            row.addView(t, LinearLayout.LayoutParams(tabW, MATCH))
            tabViews.add(t)
        }
        nav.addView(row, FrameLayout.LayoutParams(tabW * 2, MATCH))
        addView(nav, FrameLayout.LayoutParams(tabW * 2, dp(55), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(20)
        })
        show(tab, false)
    }

    private fun settingsTap() {
        taps++
        handler.removeCallbacks(resetTaps)
        handler.postDelayed(resetTaps, 700)
        if (taps >= 3) {
            taps = 0
            act.showBrowser()
        }
    }

    private fun show(i: Int, animate: Boolean = true) {
        tab = i
        act.prefs.tab = i
        page.removeAllViews()
        if (i == 0) mountNotes() else mountSettings()
        fab.visibility = if (i == 0) View.VISIBLE else View.GONE
        tabViews.forEachIndexed { k, v -> v.alpha = if (k == i) 1f else 0.5f }
        if (animate) pill.animate().translationX((i * tabW).toFloat()).setDuration(350).start()
        else pill.translationX = (i * tabW).toFloat()
    }

    override fun refresh() {
        super.refresh()
        show(tab, false)
    }

    // ---------------------------------------------------------------- notes
    private fun glassEdit(hint: String): Pair<LinearLayout, EditText> {
        val box = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = act.surf(23)
            setPadding(dp(18), 0, dp(10), 0)
        }
        val et = EditText(act).apply {
            this.hint = hint
            textSize = 16f
            typeface = Fonts.get(act)
            background = null
            isSingleLine = true
            setTextColor(ink)
            setHintTextColor(dim)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(0, 0, 0, 0)
            setOnEditorActionListener { v, _, _ -> act.hideKeyboard(v); true }
        }
        box.addView(et, LinearLayout.LayoutParams(0, MATCH, 1f))
        return Pair(box, et)
    }

    private fun mountNotes() {
        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(150))
        }
        val top = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(act.titleC("Notes", 36f, ink), LinearLayout.LayoutParams(0, WRAP, 1f))
        val results = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val (sbox, input) = glassEdit("Search")
        sbox.visibility = View.GONE
        val clear = act.iconButton(R.drawable.ic_close, "Clear", dim) { input.setText("") }
        clear.alpha = 0.6f
        sbox.addView(clear, LinearLayout.LayoutParams(dp(36), dp(36)))
        top.addView(act.circleButton(R.drawable.ic_search, "Search", night) {
            if (sbox.visibility == View.VISIBLE) {
                input.setText("")
                sbox.visibility = View.GONE
                act.hideKeyboard(input)
            } else {
                sbox.visibility = View.VISIBLE
                act.showKeyboard(input)
            }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(18) })
        col.addView(sbox, LinearLayout.LayoutParams(MATCH, dp(46)).apply { bottomMargin = dp(6) })
        col.addView(results, LinearLayout.LayoutParams(MATCH, WRAP))
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        page.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        input.onChange { q -> clear.visibility = if (q.isEmpty()) View.GONE else View.VISIBLE; draw(results, q.trim()) }
        clear.visibility = View.GONE
        draw(results, "")
    }

    private fun draw(out: LinearLayout, q: String) {
        out.removeAllViews()
        if (q.isNotEmpty()) {
            val found = act.db.notes(q, act.prefs.sort)
            if (found.isEmpty()) out.addView(emptyText("No matches"))
            else group(out, "Results", found, false)
            return
        }
        val all = act.db.notes("", act.prefs.sort)
        if (all.isEmpty()) { out.addView(emptyText("No notes yet.\nTap the pencil to write one.")); return }
        group(out, "Pinned", all.filter { it.pinned }, true)
        val rest = all.filter { !it.pinned }
        if (act.prefs.sort != 0) { group(out, "Notes", rest, false); return }
        val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        val groups = LinkedHashMap<String, ArrayList<Note>>()
        for (n in rest) {
            val c = java.util.Calendar.getInstance().apply { timeInMillis = n.updated }
            val fmt = if (c.get(java.util.Calendar.YEAR) == year) "LLLL" else "LLLL yyyy"
            groups.getOrPut(SimpleDateFormat(fmt, Locale.getDefault()).format(Date(n.updated))) { ArrayList() }.add(n)
        }
        for ((title, list) in groups) group(out, title, list, false)
    }

    private fun emptyText(s: String) = act.labelC(s, 14f, dim).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(40), 0, dp(40))
    }

    private fun group(out: LinearLayout, title: String, list: List<Note>, pin: Boolean) {
        if (list.isEmpty()) return
        val head = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(22), dp(4), dp(8))
        }
        if (pin) head.addView(ImageView(act).apply {
            setImageResource(R.drawable.ic_pin)
            imageTintList = ColorStateList.valueOf(ink)
        }, LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginEnd = dp(6) })
        head.addView(act.labelC(title, 20f, ink, true).apply { letterSpacing = -0.02f })
        out.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = act.surf(20)
            clipToOutline = true
        }
        val df = DateFormat.getDateInstance(DateFormat.SHORT)
        list.forEachIndexed { i, n ->
            if (i > 0) box.addView(View(act).apply { setBackgroundColor(act.getColor(R.color.divider)) },
                LinearLayout.LayoutParams(MATCH, 1).apply { marginStart = dp(16); marginEnd = dp(16) })
            box.addView(row(n, df), LinearLayout.LayoutParams(MATCH, WRAP))
        }
        out.addView(box, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun row(n: Note, df: DateFormat): View {
        val r = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = RippleDrawable(ColorStateList.valueOf(Color.argb(40, 128, 128, 128)), null, ColorDrawable(Color.WHITE))
        }
        val first = n.body.lineSequence().firstOrNull { it.isNotBlank() }?.trim() ?: ""
        r.addView(act.labelC(n.title.ifBlank { first.ifBlank { "Untitled" } }, 17f, ink, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, 0, 0, dp(2))
        })
        val line = LinearLayout(act)
        line.addView(act.labelC(df.format(Date(n.updated)), 15f, dim))
        val preview = (if (n.title.isBlank()) n.body.trim().removePrefix(first) else n.body).replace(Regex("\\s+"), " ").trim()
        line.addView(act.labelC(preview.ifBlank { "No additional text" }, 15f, dim).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        r.addView(line, LinearLayout.LayoutParams(MATCH, WRAP))
        r.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { lastX = e.rawX.toInt(); lastY = e.rawY.toInt() }
            false
        }
        r.setOnClickListener { act.push(EditorScreen(act, n)) }
        r.setOnLongClickListener {
            it.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            Menus.showAt(this, lastX, lastY, listOf(
                MenuItem("Open") { act.push(EditorScreen(act, n)) },
                MenuItem(if (n.pinned) "Unpin" else "Pin") { act.db.setPinned(n.id, !n.pinned); show(tab, false) },
                MenuItem("Export") { act.shareText(n.title, n.body) },
                MenuItem("Delete", true) {
                    act.confirm("Delete this note?", "Delete") { act.db.deleteNote(n.id); show(tab, false) }
                }
            ), night)
            true
        }
        return r
    }

    // ------------------------------------------------------------- settings
    private fun mountSettings() {
        val p = act.prefs
        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(150))
        }
        val top = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(act.titleC("Settings", 36f, ink), LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(act.circleButton(if (night) R.drawable.ic_moon else R.drawable.ic_sun, "Theme", night) {
            p.theme = if (night) 1 else 2
            act.applyTheme()
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(18) })

        val choose = act.rowView(false, "Choose photo", null, act.chevron(night)) {
            act.pickImage { ok ->
                if (ok) { p.bgPreset = -1; backdrop.reload(); show(1, false) } else act.toast("Couldn't use that image")
            }
        }
        val rows = ArrayList<View>()
        rows.add(choose)
        if (p.bgPreset != -2) {
            val remove = act.rowView(false, "Remove background")
            ((remove.getChildAt(0) as LinearLayout).getChildAt(0) as TextView).setTextColor(DANGER)
            remove.setOnClickListener { p.bgPreset = -2; backdrop.reload(); show(1, false) }
            rows.add(remove)
        }
        rows.add(act.slider("Blur", 0, 100, p.blur, "", false) { p.blur = it; backdrop.reload() })
        rows.add(act.slider("Dimming", 0, 70, p.dim, "%", false) { p.dim = it; backdrop.reload() })
        col.addView(act.cardView(false, *rows.toTypedArray()), LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(20) })

        col.addView(act.cardView(false,
            act.rowView(false, "Sort by", null, act.segmented(listOf("Edited", "Created", "Title"), p.sort, false) { p.sort = it }),
            act.rowView(false, "Text size", null, act.segmented(listOf("S", "M", "L"), p.textSize, false) { p.textSize = it })
        ), LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(20) })

        col.addView(act.cardView(false, act.rowView(false, "Version", null, act.labelC("v2.0", 16f, dim))),
            LinearLayout.LayoutParams(MATCH, WRAP))
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        page.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
    }
}
