# NOVA LOCK — prototype project

Native Android Kotlin starter for a Dual Password App Locker concept.

- Primary PIN: opens the protected app.
- Alternative PIN: opens a user-selected alternative installed app.
- Per-app PIN configuration.
- Local preference storage (PIN hashes, not plaintext).
- Accessibility-based foreground app monitoring prototype.

## Build
Open this folder in Android Studio, allow Gradle sync, then build APK.

## Setup
1. Install and open NOVA LOCK.
2. Add apps and configure two distinct PINs (minimum 4 digits).
3. Choose an alternative destination.
4. Open Setup protection permissions and manually enable the Accessibility service.

## Important prototype limitations
- The foreground monitoring service is a starter implementation; OEM battery management and Android background restrictions can affect it.
- A production release should use a stronger per-user salted hash, rate limiting, secure recovery, and thorough lifecycle/testing.
- This prototype's alternative destination is a separately installed app, not a clone or sandbox of the protected app.
- Android permission settings are controlled by the user. This project does not silently enable them.
