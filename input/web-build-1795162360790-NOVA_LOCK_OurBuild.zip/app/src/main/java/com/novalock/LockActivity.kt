package com.novalock

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.view.WindowManager

class LockActivity : Activity() {
    private var targetPkg=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        targetPkg=intent.getStringExtra("target_pkg") ?: ""
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(28,24,28,24); setBackgroundColor(Color.rgb(14,16,25)) }
        root.addView(TextView(this).apply { text="NOVA LOCK"; textSize=14f; setTextColor(Color.rgb(150,165,255)) })
        root.addView(TextView(this).apply { text="Protected app"; textSize=28f; setTextColor(Color.WHITE); setPadding(0,18,0,10) })
        val input=EditText(this).apply { hint="Enter PIN"; inputType=2; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); gravity=Gravity.CENTER }
        root.addView(input)
        val message=TextView(this).apply { text=""; textSize=14f; setTextColor(Color.RED); gravity=Gravity.CENTER; setPadding(0,12,0,12) }
        root.addView(message)
        root.addView(Button(this).apply { text="Unlock"; setOnClickListener {
            val pin=input.text.toString()
            when {
                AppConfig.verifyPin(this@LockActivity,targetPkg,1,pin) -> open(targetPkg)
                AppConfig.verifyPin(this@LockActivity,targetPkg,2,pin) -> {
                    val alt=AppConfig.alternativePackage(this@LockActivity,targetPkg)
                    if(alt.isNotBlank()) open(alt) else message.text="No alternative destination configured."
                }
                else -> message.text="Incorrect PIN"
            }
        } })
        setContentView(root)
    }
    private fun open(pkg:String) {
        val intent=packageManager.getLaunchIntentForPackage(pkg)
        if(intent!=null){ intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(intent) }
        finish()
    }
}
