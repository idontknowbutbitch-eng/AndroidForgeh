package com.novalock

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 14, 22)
    private val card = Color.rgb(27, 30, 42)
    private val accent = Color.rgb(132, 155, 255)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }
    private fun round(color: Int, radius: Float = 28f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null, Typeface.BOLD) }
    private fun render() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,28,22,20); setBackgroundColor(bg) }
        root.addView(text("NOVA LOCK", 13f, accent, true))
        root.addView(text("Your apps.\nYour two paths.", 30f, Color.WHITE, true).apply { setPadding(0,18,0,8) })
        root.addView(text("Dual Password protection", 15f, Color.LTGRAY))
        val top = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(16,18,16,18); background=round(card); }
        top.addView(text("Protected apps",16f,Color.WHITE,true), LinearLayout.LayoutParams(0,-2,1f))
        top.addView(text(AppConfig.protectedApps(this).size.toString(),22f,accent,true))
        val topParams=LinearLayout.LayoutParams(-1,-2); topParams.setMargins(0,22,0,18); root.addView(top,topParams)
        val list = ScrollView(this)
        val listInner = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val protected = AppConfig.protectedApps(this)
        if(protected.isEmpty()) listInner.addView(text("No apps protected yet. Add an app to configure its two passwords.",15f,Color.LTGRAY).apply { setPadding(4,18,4,18) })
        protected.forEach { pkg ->
            val label = appLabel(pkg)
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(16,14,12,14); background=round(card) }
            row.addView(text(label,16f,Color.WHITE,true), LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Button(this).apply { text="Configure"; setOnClickListener { configure(pkg) } })
            row.addView(Button(this).apply { text="Remove"; setOnClickListener { AppConfig.removeProtected(this@MainActivity,pkg); render() } })
            val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,10); listInner.addView(row,p)
        }
        list.addView(listInner); root.addView(list, LinearLayout.LayoutParams(-1,0,1f))
        val add=Button(this).apply { text="+  Add app"; setOnClickListener { selectApp() } }
        root.addView(add,LinearLayout.LayoutParams(-1,-2))
        val permissions=Button(this).apply { text="Setup protection permissions"; setOnClickListener { showPermissions() } }
        root.addView(permissions)
        root.addView(text("Prototype • Local-only setup • No account",12f,Color.GRAY).apply { gravity=Gravity.CENTER; setPadding(0,12,0,0) })
        setContentView(root)
    }
    private fun appLabel(pkg:String): String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString() } catch(e:Exception){pkg}
    private fun selectApp() {
        val apps=packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName)!=null && it.packageName!=packageName }
            .sortedBy { appLabel(it.packageName).lowercase() }
        val names=apps.map { appLabel(it.packageName) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose an app").setItems(names) { _, i ->
            val pkg=apps[i].packageName; AppConfig.addProtected(this,pkg); configure(pkg)
        }.setNegativeButton("Cancel",null).show()
    }
    private fun configure(pkg:String) {
        val label=appLabel(pkg)
        val altOptions=packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName)!=null && it.packageName!=packageName && it.packageName!=pkg }
            .sortedBy { appLabel(it.packageName).lowercase() }
        val altLabels=altOptions.map { appLabel(it.packageName) }.toTypedArray()
        val selected=altOptions.indexOfFirst { it.packageName==AppConfig.alternativePackage(this,pkg) }
        val altChoice=TextView(this).apply { text="Alternative destination: ${if(selected>=0) altLabels[selected] else "Not selected"}"; setPadding(24,20,24,20); setTextColor(Color.DKGRAY) }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val pinA=EditText(this).apply { hint="Primary PIN (4–12 digits)"; inputType=2 }
        val pinB=EditText(this).apply { hint="Alternative PIN (4–12 digits)"; inputType=2 }
        box.addView(text("Primary PIN opens $label",14f,Color.DKGRAY).apply { setPadding(24,12,24,4) }); box.addView(pinA)
        box.addView(text("Alternative PIN opens the destination below",14f,Color.DKGRAY).apply { setPadding(24,12,24,4) }); box.addView(pinB)
        box.addView(altChoice)
        altChoice.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Alternative destination").setItems(altLabels) { _, idx ->
                AppConfig.setAlternative(this,pkg,altOptions[idx].packageName)
                altChoice.text="Alternative destination: ${altLabels[idx]}"
            }.setNegativeButton("Cancel",null).show()
        }
        AlertDialog.Builder(this).setTitle("Configure $label").setView(box)
            .setPositiveButton("Save") { _,_ ->
                val a=pinA.text.toString(); val b=pinB.text.toString()
                if(a.length>=4 && b.length>=4 && a!=b) {
                    AppConfig.setPin(this,pkg,1,a); AppConfig.setPin(this,pkg,2,b)
                    Toast.makeText(this,"PINs saved locally",Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this,"Use two different PINs, each at least 4 digits",Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancel",null).show()
    }
    private fun showPermissions() {
        val usage=Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        val accessibility=Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        AlertDialog.Builder(this).setTitle("Protection setup")
            .setMessage("For app-lock monitoring, Android requires you to manually enable NOVA LOCK in Accessibility settings. Usage Access is also available for monitoring. This prototype explains permissions and does not enable them for you.")
            .setPositiveButton("Accessibility settings") { _,_ -> startActivity(accessibility) }
            .setNeutralButton("Usage Access") { _,_ -> startActivity(usage) }
            .setNegativeButton("Cancel",null).show()
    }
}
