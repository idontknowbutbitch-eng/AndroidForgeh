package com.novalock

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent

class AppWatcherService : AccessibilityService() {
    private var lastLockedPkg=""
    private var lastLaunch=0L
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if(event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg=event.packageName?.toString() ?: return
        if(pkg==packageName || pkg=="com.android.systemui") return
        val protected=AppConfig.protectedApps(this)
        if(pkg !in protected) { lastLockedPkg=""; return }
        if(lastLockedPkg==pkg && System.currentTimeMillis()-lastLaunch<1500) return
        if(!AppConfig.hasPin(this,pkg,1) || !AppConfig.hasPin(this,pkg,2)) return
        lastLockedPkg=pkg; lastLaunch=System.currentTimeMillis()
        val i=Intent(this,LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        i.putExtra("target_pkg",pkg)
        startActivity(i)
    }
    override fun onInterrupt() {}
}
