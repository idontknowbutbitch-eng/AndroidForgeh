package com.novalock

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

object AppConfig {
    private const val PREF = "nova_lock_settings"
    fun protectedApps(ctx: Context): Set<String> = prefs(ctx).getStringSet("protected", emptySet())?.toSet() ?: emptySet()
    fun addProtected(ctx: Context, pkg: String) {
        prefs(ctx).edit().putStringSet("protected", protectedApps(ctx) + pkg).apply()
    }
    fun removeProtected(ctx: Context, pkg: String) {
        prefs(ctx).edit().putStringSet("protected", protectedApps(ctx) - pkg).apply()
    }
    fun alternativePackage(ctx: Context, pkg: String): String = prefs(ctx).getString("alt_$pkg", "") ?: ""
    fun setAlternative(ctx: Context, pkg: String, alt: String) { prefs(ctx).edit().putString("alt_$pkg", alt).apply() }
    fun setPin(ctx: Context, pkg: String, which: Int, pin: String) { prefs(ctx).edit().putString("pin_${which}_$pkg", hash(pin)).apply() }
    fun verifyPin(ctx: Context, pkg: String, which: Int, pin: String): Boolean {
        val saved = prefs(ctx).getString("pin_${which}_$pkg", null) ?: return false
        return saved == hash(pin)
    }
    fun hasPin(ctx: Context, pkg: String, which: Int): Boolean = prefs(ctx).contains("pin_${which}_$pkg")
    private fun hash(pin: String): String {
        val salt = "NOVA_LOCK_local_v1"
        return MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    }
    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
