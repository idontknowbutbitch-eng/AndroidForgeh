# Notes (GlassNotes, package com.glassnotes.app)

A notes app with a glass design taken from iNotes: SF Pro Display (Regular, Semibold, Black), the iOS Arabic font as fallback for Arabic text, the iNotes icon set, grouped note lists, a floating glass bar with a sliding pill, and a long-press action panel.

Android 10+ (minSdk 29). Kotlin, Material 3, WebView, SQLite. No extra dependencies.

## Notes
- Home: Pinned + notes grouped by month, search (top-right circle), compose button, dark/light theme (sun/moon button in Settings).
- Long-press a note: Open, Pin/Unpin, Export (share as text), Delete.
- The editor slides up from the bottom and autosaves. Empty notes are discarded.
- Settings: background photo (blur, dimming), sort order, text size.

## Hidden area
Tap the **Settings** tab icon in the bottom bar **three times** quickly. A glass browser opens (tabs, bookmarks, history, downloads, blurred background home page, slide-up options sheet).
- Long-press a tab > **Hide tab**. Hidden tabs are removed from the tab list and can only be reached in **Browser settings > Developer options** (code **1111**).
- Hidden tabs keep no history, block screenshots, and re-lock when you leave the app.
- The app does not register itself as a web browser with Android.

## Get an APK
- Upload the ZIP contents to a GitHub repo (the included workflow `.github/workflows/build.yml` builds `app-debug.apk`; download it from the Actions tab), or
- Open the folder in Android Studio (JDK 17) and press Run, or run `gradle assembleDebug` (Gradle 8.7).

## Notes
- Fonts and icons come from the iNotes project you supplied.
- Blur is real GPU blur on Android 12+; on Android 10-11 a softened wallpaper is used.
- Written without an Android SDK, so it has not been compiled or run here. If the build prints an error, send me the log.
