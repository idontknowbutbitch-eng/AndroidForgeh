package com.glassnotes.app.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import com.glassnotes.app.MainActivity
import com.glassnotes.app.R

/** Background / blur / search / data settings, plus the code-protected Developer options. */
class BrowserSettingsScreen(act: MainActivity) : BScreen(act) {
    private val swatches = LinearLayout(act)

    init {
        val inner = page("Settings", true)
        val p = act.prefs

        inner.addView(act.sectionLabel(true, "Background"))
        val strip = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false }
        swatches.setPadding(dp(12), dp(12), dp(12), dp(12))
        strip.addView(swatches)
        buildSwatches()
        inner.addView(act.cardView(true,
            strip,
            act.slider("Blur", 0, 100, p.blur, "") { p.blur = it; backdrop.reload() },
            act.slider("Dimming", 0, 70, p.dim, "%") { p.dim = it; backdrop.reload() }))

        inner.addView(act.sectionLabel(true, "Search"))
        inner.addView(act.cardView(true,
            act.rowView(true, "Search engine", null, act.segmented(listOf("Google", "DuckDuckGo", "Bing"), p.engine, true) { p.engine = it })))

        inner.addView(act.sectionLabel(true, "Pages"))
        inner.addView(act.cardView(true,
            act.slider("Text size", 50, 200, p.zoom, "%") { p.zoom = it; act.tabs.applySettings() }))

        inner.addView(act.sectionLabel(true, "Data"))
        inner.addView(act.cardView(true,
            act.rowView(true, "Clear browsing data", "History, cookies and cache") {
            }.also { r ->
                r.setOnClickListener {
                    act.confirm("Clear browsing data?", "Clear") { act.tabs.clearData(); act.toast("Cleared") }
                }
            }))

        inner.addView(act.sectionLabel(true, "Advanced"))
        val lock = ImageView(act).apply {
            setImageResource(R.drawable.ic_lock)
            imageTintList = android.content.res.ColorStateList.valueOf(W2)
        }
        inner.addView(act.cardView(true,
            act.rowView(true, "Developer options", null, lock) {
                act.requireDev { act.push(DevOptionsScreen(act)) }
            }))
        inner.addView(act.sectionLabel(true, ""))
        inner.addView(act.cardView(true,
            act.rowView(true, "Back to Notes") { act.goHome() }))
    }

    private fun swatch(selected: Boolean, content: View?, onClick: () -> Unit): View {
        val v = FrameLayout(act)
        content?.let { v.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }
        v.setOnClickListener { onClick() }
        v.tag = selected
        return v
    }

    private fun buildSwatches() {
        swatches.removeAllViews()
        val p = act.prefs
        val plain = View(act).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(PAGE_DARK)
                if (p.bgPreset == -2) setStroke(dp(3), Color.WHITE) else setStroke(dp(1), Color.argb(80, 255, 255, 255))
            }
        }
        swatches.addView(swatch(p.bgPreset == -2, plain) {
            p.bgPreset = -2
            backdrop.reload()
            buildSwatches()
        }, LinearLayout.LayoutParams(dp(56), dp(56)).apply { marginEnd = dp(12) })
        Backdrop.presets.forEachIndexed { i, _ ->
            val d = Backdrop.gradient(i).apply {
                shape = GradientDrawable.OVAL
                if (p.bgPreset == i) setStroke(dp(3), Color.WHITE) else setStroke(dp(1), Color.argb(80, 255, 255, 255))
            }
            val s = View(act).apply { background = d }
            swatches.addView(swatch(p.bgPreset == i, s) {
                p.bgPreset = i
                backdrop.reload()
                buildSwatches()
            }, LinearLayout.LayoutParams(dp(56), dp(56)).apply { marginEnd = dp(12) })
        }
        val photoSel = p.bgPreset < 0
        val icon = ImageView(act).apply {
            setImageResource(R.drawable.ic_image)
            imageTintList = android.content.res.ColorStateList.valueOf(W)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = act.rounded(Color.argb(60, 255, 255, 255), 28,
                if (photoSel) Color.WHITE else Color.argb(80, 255, 255, 255), if (photoSel) 3 else 1)
        }
        swatches.addView(swatch(photoSel, icon) {
            act.pickImage { ok ->
                if (ok) {
                    p.bgPreset = -1
                    backdrop.reload()
                    buildSwatches()
                } else act.toast("Couldn't use that image")
            }
        }, LinearLayout.LayoutParams(dp(56), dp(56)))
    }
}
