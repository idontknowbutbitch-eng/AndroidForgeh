package com.glassnotes.app

import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.glassnotes.app.data.Db
import com.glassnotes.app.data.Prefs
import com.glassnotes.app.ui.BrowserScreen
import com.glassnotes.app.ui.Backdrop
import com.glassnotes.app.ui.Dialogs
import com.glassnotes.app.ui.MATCH
import com.glassnotes.app.ui.NotesHost
import com.glassnotes.app.ui.Screen
import com.glassnotes.app.ui.dp
import com.glassnotes.app.web.TabManager

/** Single activity hosting a tiny navigation stack of full-screen Screens. */
class MainActivity : AppCompatActivity() {
    lateinit var db: Db
    lateinit var prefs: Prefs
    lateinit var tabs: TabManager
    private lateinit var root: FrameLayout
    private val stack = ArrayList<Screen>()
    var devUnlocked = false

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pickCb: ((Boolean) -> Unit)? = null
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val cb = pickCb
        pickCb = null
        if (cb != null) cb(uri != null && Backdrop.save(this, uri))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        applyTheme()
        super.onCreate(savedInstanceState)
        db = Db(this)
        tabs = TabManager(this, db)
        tabs.restore()
        root = FrameLayout(this)
        setContentView(root)
        push(NotesHost(this))
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) hideCustomView()
                else if (!stack.last().onBack()) {
                    if (stack.size > 1) pop() else finish()
                }
            }
        })
    }

    fun applyTheme() {
        AppCompatDelegate.setDefaultNightMode(
            when (prefs.theme) {
                1 -> AppCompatDelegate.MODE_NIGHT_NO
                2 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    fun isNight() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    override fun onStop() {
        super.onStop()
        stack.lastOrNull()?.flush()
        tabs.saveAll()
        lockHidden()
    }

    override fun onDestroy() {
        super.onDestroy()
        tabs.destroy()
        db.close()
    }

    /** Leaving the app re-locks hidden content: those screens close and a normal tab becomes active. */
    private fun lockHidden() {
        devUnlocked = false
        if (stack.any { it.showsPrivate() }) popToRoot()
        if (tabs.active?.isHidden == true) tabs.active = null
        setSecure(false)
    }

    // ---- navigation ----
    fun push(s: Screen) {
        val prev = stack.lastOrNull()
        stack.add(s)
        root.addView(s, FrameLayout.LayoutParams(MATCH, MATCH))
        if (prev != null) {
            s.alpha = if (s.slideUp) 1f else 0f
            if (s.slideUp) s.translationY = resources.displayMetrics.heightPixels.toFloat()
            else s.translationX = dp(28).toFloat()
            s.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(if (s.slideUp) 350 else 220)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction { if (stack.lastOrNull() !== prev) prev.visibility = View.GONE }
                .start()
        }
        s.refresh()
    }

    fun pop(animated: Boolean = true) {
        if (stack.size < 2) return
        val top = stack.removeAt(stack.size - 1)
        top.flush()
        val below = stack.last()
        below.visibility = View.VISIBLE
        below.refresh()
        val done = { top.onDestroyScreen(); root.removeView(top) }
        if (animated) {
            if (top.slideUp) {
                top.animate().translationY(resources.displayMetrics.heightPixels.toFloat()).setDuration(300)
                    .withEndAction { done() }.start()
            } else {
                top.animate().alpha(0f).translationX(dp(28).toFloat()).setDuration(180)
                    .withEndAction { done() }.start()
            }
        } else done()
    }

    private fun popToRoot() { while (stack.size > 1) pop(false) }

    fun goHome() = popToRoot()

    fun back() { onBackPressedDispatcher.onBackPressed() }

    fun showBrowser() {
        val b = stack.lastOrNull { it is BrowserScreen } as BrowserScreen?
        if (b == null) { push(BrowserScreen(this)); return }
        while (stack.last() !== b) pop(stack.getOrNull(stack.size - 2) === b)
        b.rebind()
        b.refresh()
    }

    fun openUrl(url: String) {
        val t = tabs.ensureActive()
        tabs.load(t, url)
        showBrowser()
    }

    /** Runs [then] once the developer code has been entered. */
    fun requireDev(then: () -> Unit) {
        if (devUnlocked) then() else Dialogs.code(this) { devUnlocked = true; then() }
    }

    fun pickImage(cb: (Boolean) -> Unit) {
        pickCb = cb
        picker.launch("image/*")
    }

    // ---- helpers ----
    fun setSecure(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    fun setBars(color: Int, lightBg: Boolean) {
        window.statusBarColor = color
        window.navigationBarColor = color
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.isAppearanceLightStatusBars = lightBg
        c.isAppearanceLightNavigationBars = lightBg
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun showKeyboard(v: View) {
        v.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard(v: View) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    fun chooseFile(cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams): Boolean {
        fileCb?.onReceiveValue(null)
        fileCb = cb
        return try {
            chooser.launch(p.createIntent())
            true
        } catch (e: Exception) {
            fileCb = null
            cb.onReceiveValue(null)
            false
        }
    }

    fun showCustomView(v: View, cb: WebChromeClient.CustomViewCallback) {
        if (customView != null) { cb.onCustomViewHidden(); return }
        customView = v
        customCb = cb
        v.setBackgroundColor(0xFF000000.toInt())
        (window.decorView as FrameLayout).addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    fun hideCustomView() {
        customView?.let { (window.decorView as FrameLayout).removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }
}
