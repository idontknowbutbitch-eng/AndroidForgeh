package com.glassnotes.app.data

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("notes_prefs", Context.MODE_PRIVATE)
    private fun int(k: String, d: Int) = p.getInt(k, d)
    private fun put(k: String, v: Int) = p.edit().putInt(k, v).apply()

    /** 0 system, 1 light, 2 dark */
    var theme: Int get() = int("theme", 0); set(v) = put("theme", v)
    /** 0 modified, 1 created, 2 title */
    var sort: Int get() = int("sort", 0); set(v) = put("sort", v)
    /** 0 small, 1 medium, 2 large (editor text) */
    var textSize: Int get() = int("textSize", 1); set(v) = put("textSize", v)
    /** -2 = plain, -1 = chosen photo, otherwise gradient preset index */
    var bgPreset: Int get() = int("bgPreset", -2); set(v) = put("bgPreset", v)
    /** last tab on the notes home bar: 0 notes, 1 settings */
    var tab: Int get() = int("tab", 0); set(v) = put("tab", v)
    var blur: Int get() = int("blur", 55); set(v) = put("blur", v)
    var dim: Int get() = int("dim", 30); set(v) = put("dim", v)
    var zoom: Int get() = int("zoom", 100); set(v) = put("zoom", v)
    /** 0 Google, 1 DuckDuckGo, 2 Bing */
    var engine: Int get() = int("engine", 0); set(v) = put("engine", v)
    var js: Boolean get() = p.getBoolean("js", true); set(v) = p.edit().putBoolean("js", v).apply()
}
