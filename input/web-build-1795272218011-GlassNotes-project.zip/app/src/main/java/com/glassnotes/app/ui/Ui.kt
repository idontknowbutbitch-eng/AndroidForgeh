package com.glassnotes.app.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.fonts.Font
import android.graphics.fonts.FontFamily
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.glassnotes.app.MainActivity
import com.glassnotes.app.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val DARK_BAR = Color.parseColor("#08090D")
val PAGE_DARK = Color.parseColor("#08090D")
val W = Color.WHITE
val W2 = Color.argb(170, 255, 255, 255)
val DANGER = Color.parseColor("#FF6B6B")

/**
 * SF Pro Display (Regular / Semibold / Black) with the iOS Arabic font as fallback,
 * so Arabic notes are drawn in the iOS Arabic face.
 */
object Fonts {
    private val cache = HashMap<Int, Typeface>()

    private fun build(c: Context, w: Int): Typeface = cache.getOrPut(w) {
        val id = when (w) { 600 -> R.font.sfpd_semibold; 900 -> R.font.sfpd_black; else -> R.font.sfpd_regular }
        try {
            val main = FontFamily.Builder(Font.Builder(c.resources, id).build()).build()
            val arabic = FontFamily.Builder(
                Font.Builder(c.resources, R.font.arabic_ios)
                    .setFontVariationSettings("'wght' $w")
                    .setWeight(w)
                    .build()
            ).build()
            Typeface.CustomFallbackBuilder(main).addCustomFallback(arabic).setSystemFallback("sans-serif").build()
        } catch (e: Exception) {
            c.resources.getFont(id)
        }
    }

    fun get(c: Context): Typeface = build(c, 400)
    fun semibold(c: Context): Typeface = build(c, 600)
    fun black(c: Context): Typeface = build(c, 900)

    fun applyTo(v: View) {
        if (v is TextView) v.typeface = get(v.context)
        if (v is ViewGroup) for (i in 0 until v.childCount) applyTo(v.getChildAt(i))
    }
}

fun Context.dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rounded(fill: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
    }

/** Dark frosted-glass panel (browser-side screens). */
fun Context.glass(radius: Int, fill: Int = Color.argb(105, 0, 0, 0), stroke: Int = Color.argb(45, 255, 255, 255)) =
    rounded(fill, radius, stroke, 1)

/** Theme-aware glass surface (notes-side): translucent fill + hairline border. */
fun Context.surf(radius: Int) = rounded(getColor(R.color.surface), radius, getColor(R.color.line), 1)

fun Context.sizedIcon(res: Int, color: Int, hDp: Int): Drawable {
    val d = getDrawable(res)!!.mutate()
    d.setTint(color)
    val h = dp(hDp)
    val w = if (d.intrinsicHeight > 0) d.intrinsicWidth * h / d.intrinsicHeight else h
    d.setBounds(0, 0, w, h)
    return d
}

fun Context.labelC(s: String, sp: Float, color: Int, heavy: Boolean = false): TextView = TextView(this).apply {
    text = s
    textSize = sp
    setTextColor(color)
    typeface = if (heavy) Fonts.semibold(context) else Fonts.get(context)
}

fun Context.label(s: String, sp: Float, colorRes: Int = R.color.text, heavy: Boolean = false): TextView =
    labelC(s, sp, getColor(colorRes), heavy)

/** Big screen title: SF Pro Black, tight tracking (as in iNotes). */
fun Context.titleC(s: String, sp: Float, color: Int): TextView = labelC(s, sp, color).apply {
    typeface = Fonts.black(context)
    letterSpacing = -0.03f
}

fun Context.iconButton(res: Int, desc: String, tint: Int = getColor(R.color.text), onClick: () -> Unit): ImageButton =
    ImageButton(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(tint)
        contentDescription = desc
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        val a = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
        background = a.getDrawable(0)
        a.recycle()
        setOnClickListener { onClick() }
    }

/** Round glass button (the iNotes ".glass.circ"). */
fun Context.circleButton(res: Int, desc: String, dark: Boolean, onClick: () -> Unit): ImageButton {
    val ink = if (dark) W else getColor(R.color.text)
    val fill = if (dark) Color.argb(40, 255, 255, 255) else getColor(R.color.g)
    val stroke = if (dark) Color.argb(60, 255, 255, 255) else getColor(R.color.line)
    return ImageButton(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(ink)
        contentDescription = desc
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(13), dp(13), dp(13), dp(13))
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(fill); setStroke(dp(1), stroke) }
        setOnClickListener { onClick() }
    }
}

fun Context.chevron(dark: Boolean): ImageView = ImageView(this).apply {
    setImageResource(R.drawable.ic_back)
    imageTintList = ColorStateList.valueOf(if (dark) W else getColor(R.color.text))
    alpha = 0.4f
    scaleX = -1f
    layoutParams = LinearLayout.LayoutParams(dp(9), dp(14))
}

fun EditText.onChange(f: (String) -> Unit) = addTextChangedListener(object : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
})

fun MainActivity.confirm(title: String, yes: String, onYes: () -> Unit) {
    val d = MaterialAlertDialogBuilder(this).setTitle(title)
        .setNegativeButton("Cancel", null)
        .setPositiveButton(yes) { _, _ -> onYes() }
        .create()
    d.show()
    d.window?.decorView?.let { Fonts.applyTo(it) }
}

fun MainActivity.shareText(title: String, body: String) {
    startActivity(android.content.Intent.createChooser(android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(android.content.Intent.EXTRA_SUBJECT, title)
        putExtra(android.content.Intent.EXTRA_TEXT, if (title.isBlank()) body else "$title\n\n$body")
    }, null))
}

/** Segmented control. [dark] = glass style for browser screens. */
fun Context.segmented(opts: List<String>, sel: Int, dark: Boolean, onSel: (Int) -> Unit): LinearLayout {
    val box = LinearLayout(this)
    val cells = ArrayList<TextView>()
    val fillBox = if (dark) Color.argb(50, 255, 255, 255) else getColor(R.color.seg)
    val fillOn = if (dark) Color.argb(120, 255, 255, 255) else getColor(R.color.seg_on)
    val on = if (dark) W else getColor(R.color.text)
    val off = if (dark) W2 else getColor(R.color.text2)
    box.background = rounded(fillBox, 10)
    box.setPadding(dp(2), dp(2), dp(2), dp(2))
    fun style(s: Int) {
        cells.forEachIndexed { i, c ->
            c.background = if (i == s) rounded(fillOn, 8) else null
            c.setTextColor(if (i == s) on else off)
        }
    }
    opts.forEachIndexed { i, o ->
        val c = labelC(o, 13.5f, off).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setOnClickListener { style(i); onSel(i) }
        }
        cells.add(c)
        box.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
    }
    style(sel)
    return box
}

/** iOS-style slider: thick rounded track, ink fill, no thumb. */
fun Context.iosSeek(minV: Int, maxV: Int, value: Int, ink: Int, onVal: (Int, Boolean) -> Unit): SeekBar {
    val sb = SeekBar(this)
    sb.max = maxV - minV
    sb.progress = value - minV
    val r = dp(6).toFloat()
    val track = GradientDrawable().apply { setColor(Color.argb(92, 120, 120, 128)); cornerRadius = r }
    val fill = ClipDrawable(GradientDrawable().apply { setColor(ink); cornerRadius = r }, Gravity.START, ClipDrawable.HORIZONTAL)
    val layers = LayerDrawable(arrayOf<Drawable>(track, fill))
    layers.setId(0, android.R.id.background)
    layers.setId(1, android.R.id.progress)
    layers.setLayerHeight(0, dp(12))
    layers.setLayerHeight(1, dp(12))
    layers.setLayerGravity(0, Gravity.CENTER_VERTICAL)
    layers.setLayerGravity(1, Gravity.CENTER_VERTICAL)
    sb.progressDrawable = layers
    sb.thumb = null
    sb.splitTrack = false
    sb.setPadding(0, 0, 0, 0)
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { onVal(p + minV, fromUser) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    })
    return sb
}

fun Context.slider(
    title: String, minV: Int, maxV: Int, value: Int, unit: String,
    dark: Boolean = true, onChange: (Int) -> Unit
): LinearLayout {
    val fg = if (dark) W else getColor(R.color.text)
    val fg2 = if (dark) W2 else getColor(R.color.text2)
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(12), dp(16), dp(6))
    }
    val top = LinearLayout(this)
    val v = labelC("$value$unit", 15f, fg2)
    top.addView(labelC(title, 17f, fg), LinearLayout.LayoutParams(0, WRAP, 1f))
    top.addView(v)
    val sb = iosSeek(minV, maxV, value, fg) { p, fromUser ->
        v.text = "$p$unit"
        if (fromUser) onChange(p)
    }
    box.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
    box.addView(sb, LinearLayout.LayoutParams(MATCH, dp(28)))
    return box
}

// ---- grouped settings rows ----
fun Context.rowView(dark: Boolean, title: String, sub: String? = null, trailing: View? = null, onClick: (() -> Unit)? = null): LinearLayout {
    val fg = if (dark) W else getColor(R.color.text)
    val fg2 = if (dark) W2 else getColor(R.color.text2)
    val r = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        minimumHeight = dp(52)
        setPadding(dp(16), dp(8), dp(16), dp(8))
    }
    val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    tx.addView(labelC(title, 17f, fg))
    if (sub != null) tx.addView(labelC(sub, 13f, fg2).apply {
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setPadding(0, dp(2), 0, 0)
    })
    r.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
    if (trailing != null) r.addView(trailing, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(12) })
    if (onClick != null) r.setOnClickListener { onClick() }
    return r
}

fun Context.cardView(dark: Boolean, vararg rows: View): LinearLayout {
    val c = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = if (dark) glass(20) else surf(20)
        clipToOutline = true
    }
    rows.forEachIndexed { i, r ->
        if (i > 0) c.addView(View(this).apply {
            setBackgroundColor(if (dark) Color.argb(40, 255, 255, 255) else getColor(R.color.divider))
        }, LinearLayout.LayoutParams(MATCH, 1).apply { marginStart = dp(16); marginEnd = dp(16) })
        c.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
    }
    return c
}

fun Context.sectionLabel(dark: Boolean, s: String): TextView =
    labelC(s, 20f, if (dark) W else getColor(R.color.text), true).apply {
        letterSpacing = -0.02f
        setPadding(dp(4), dp(22), dp(4), dp(8))
    }

class MenuItem(val label: String, val danger: Boolean = false, val fn: () -> Unit)

/** Compact rounded action panel (iNotes ".sheet"). */
object Menus {
    /** Dark panel under a view. */
    fun show(anchor: View, items: List<Pair<String, () -> Unit>>) {
        val ctx = anchor.context
        val pw = panel(ctx, true, items.map { MenuItem(it.first, false, it.second) })
        pw.showAsDropDown(anchor, 0, -anchor.height / 2)
    }

    /** Panel near the finger (x, y in screen coordinates). */
    fun showAt(parent: View, x: Int, y: Int, items: List<MenuItem>, dark: Boolean) {
        val ctx = parent.context
        val pw = panel(ctx, dark, items)
        val box = pw.contentView
        box.measure(View.MeasureSpec.makeMeasureSpec(ctx.dp(240), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val dm = ctx.resources.displayMetrics
        val w = ctx.dp(240)
        val px = (x - w / 2).coerceIn(ctx.dp(12), maxOf(ctx.dp(12), dm.widthPixels - w - ctx.dp(12)))
        val py = (y + ctx.dp(12)).coerceAtMost(maxOf(ctx.dp(12), dm.heightPixels - box.measuredHeight - ctx.dp(40)))
        pw.showAtLocation(parent, Gravity.NO_GRAVITY, px, py)
    }

    private fun panel(ctx: Context, dark: Boolean, items: List<MenuItem>): PopupWindow {
        val bg = if (dark) Color.argb(248, 30, 32, 42) else Color.argb(248, 246, 247, 250)
        val fg = if (dark) W else ctx.getColor(R.color.text)
        val div = if (dark) Color.argb(26, 255, 255, 255) else Color.argb(26, 0, 0, 0)
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = ctx.rounded(bg, 16, ctx.getColor(R.color.line), 1)
            clipToOutline = true
        }
        val pw = PopupWindow(box, ctx.dp(240), WRAP, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.elevation = ctx.dp(12).toFloat()
        items.forEachIndexed { i, m ->
            if (i > 0) box.addView(View(ctx).apply { setBackgroundColor(div) }, LinearLayout.LayoutParams(MATCH, 1))
            box.addView(ctx.labelC(m.label, 16f, if (m.danger) DANGER else fg).apply {
                setPadding(ctx.dp(16), ctx.dp(13), ctx.dp(16), ctx.dp(13))
                setOnClickListener { pw.dismiss(); m.fn() }
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return pw
    }
}

object Dialogs {
    const val DEV_CODE = "1111"

    fun code(act: MainActivity, onOk: () -> Unit) {
        val et = EditText(act).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Code"
            gravity = Gravity.CENTER
            textSize = 22f
            typeface = Fonts.get(act)
        }
        val box = FrameLayout(act).apply { setPadding(act.dp(24), act.dp(8), act.dp(24), 0) }
        box.addView(et, FrameLayout.LayoutParams(MATCH, WRAP))
        val d = MaterialAlertDialogBuilder(act).setTitle("Developer options")
            .setMessage("Enter the developer code.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("OK", null)
            .create()
        d.setOnShowListener {
            et.requestFocus()
            d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (et.text.toString() == DEV_CODE) { d.dismiss(); onOk() }
                else { et.error = "Wrong code"; et.setText("") }
            }
        }
        d.show()
        d.window?.decorView?.let { Fonts.applyTo(it) }
    }
}

/** Base class for full-screen views managed by MainActivity's tiny navigation stack. */
abstract class Screen(val act: MainActivity) : FrameLayout(act) {
    init {
        setBackgroundColor(act.getColor(R.color.bg))
        isClickable = true
    }

    /** Slides up from the bottom instead of in from the side (note editor). */
    open val slideUp: Boolean get() = false

    protected fun dp(n: Int) = act.dp(n)
    open fun refresh() {
        act.setSecure(false)
        act.setBars(act.getColor(R.color.bg), !act.isNight())
    }
    open fun onBack(): Boolean = false
    open fun flush() {}
    open fun onDestroyScreen() {}
    open fun showsPrivate(): Boolean = false

    protected fun header(title: String, dark: Boolean, trailing: View? = null): LinearLayout {
        val h = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(6))
        }
        h.addView(act.circleButton(R.drawable.ic_back, "Back", dark) { act.back() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        h.addView(act.labelC(title, 20f, if (dark) W else act.getColor(R.color.text), true).apply {
            setPadding(dp(12), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (trailing != null) h.addView(trailing)
        return h
    }

    /** A header plus a scrolling column; returns the column to fill. */
    protected fun page(title: String, dark: Boolean, trailing: View? = null): LinearLayout {
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header(title, dark, trailing), LinearLayout.LayoutParams(MATCH, WRAP))
        val inner = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(32))
        }
        val sv = ScrollView(act)
        sv.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        return inner
    }
}
