package com.glassnotes.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.annotation.RequiresApi
import com.glassnotes.app.MainActivity
import com.glassnotes.app.R
import java.io.File
import java.io.FileOutputStream

/** Gradient presets and the user's chosen photo. */
object Backdrop {
    val presets = listOf(
        "Midnight" to listOf("#0F0C29", "#302B63", "#24243E"),
        "Ocean" to listOf("#0F2027", "#2C5364", "#2193B0"),
        "Sunset" to listOf("#3A1C71", "#D76D77", "#FFAF7B"),
        "Aurora" to listOf("#134E5E", "#2BC0A0", "#71B280"),
        "Graphite" to listOf("#141414", "#2B2B2E", "#3E3E44"),
        "Violet" to listOf("#1D0B3F", "#4A00E0", "#8E2DE2")
    )
    private var cache: Bitmap? = null
    private var stamp = 0L

    fun file(ctx: Context) = File(ctx.filesDir, "bg.jpg")

    fun photo(ctx: Context): Bitmap? {
        val f = file(ctx)
        if (!f.exists()) return null
        if (cache == null || stamp != f.lastModified()) {
            cache = BitmapFactory.decodeFile(f.path)
            stamp = f.lastModified()
        }
        return cache
    }

    fun gradient(i: Int): GradientDrawable {
        val cols = presets[i.coerceIn(0, presets.size - 1)].second.map { Color.parseColor(it) }.toIntArray()
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, cols)
    }

    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var s = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / s > 1600) s *= 2
            val o = BitmapFactory.Options().apply { inSampleSize = s }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            if (bmp == null) false else {
                FileOutputStream(file(ctx)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                cache = null
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}

/** Full-screen background (plain, gradient or photo) with blur + scrim, behind every screen. */
class BackgroundView(private val act: MainActivity, private val dark: Boolean = true) : FrameLayout(act) {
    private val img = ImageView(act)
    private val dimV = View(act)

    init {
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(dimV, FrameLayout.LayoutParams(MATCH, MATCH))
        reload()
    }

    fun reload() {
        val p = act.prefs
        val level = p.blur
        val bmp = if (p.bgPreset == -1) Backdrop.photo(act) else null
        val plain = p.bgPreset == -2 || (p.bgPreset == -1 && bmp == null)
        if (plain) {
            img.setImageDrawable(ColorDrawable(if (dark) PAGE_DARK else act.getColor(R.color.bg)))
            if (Build.VERSION.SDK_INT >= 31) setBlur(0)
            img.scaleX = 1f
            img.scaleY = 1f
            dimV.setBackgroundColor(Color.TRANSPARENT)
            return
        }
        if (bmp != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                img.setImageBitmap(bmp)
            } else {
                val f = 1 + level / 10
                img.setImageBitmap(
                    if (f > 1) Bitmap.createScaledBitmap(bmp, maxOf(1, bmp.width / f), maxOf(1, bmp.height / f), true) else bmp
                )
            }
        } else {
            img.setImageDrawable(Backdrop.gradient(maxOf(p.bgPreset, 0)))
        }
        if (Build.VERSION.SDK_INT >= 31) setBlur(level)
        img.scaleX = 1.15f
        img.scaleY = 1.15f
        dimV.setBackgroundColor(if (dark) Color.argb(p.dim * 255 / 100, 0, 0, 0) else Color.argb(64 + p.dim, 255, 255, 255))
    }

    @RequiresApi(31)
    private fun setBlur(level: Int) {
        val r = level * 0.35f
        img.setRenderEffect(if (level > 0) RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP) else null)
    }
}

/**
 * Base for screens that sit on the shared background.
 * dark = true: browser side (always dark glass). dark = false: notes side in the light theme.
 */
abstract class BScreen(act: MainActivity, private val dark: Boolean = true) : Screen(act) {
    protected val backdrop = BackgroundView(act, dark)

    init { addView(backdrop, FrameLayout.LayoutParams(MATCH, MATCH)) }

    override fun refresh() {
        backdrop.reload()
        act.setSecure(false)
        if (dark) act.setBars(DARK_BAR, false) else act.setBars(act.getColor(R.color.bg), true)
    }
}
