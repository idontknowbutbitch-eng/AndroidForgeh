package com.glassnotes.app.web

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.os.Parcel
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import com.glassnotes.app.MainActivity
import com.glassnotes.app.R
import com.glassnotes.app.data.Db
import java.io.File
import java.io.FileOutputStream

const val ERROR_TITLE = "Page unavailable"

class Tab(val id: Long, var title: String, var url: String, var isHidden: Boolean) {
    var webView: WebView? = null
    var favicon: Bitmap? = null
    var thumb: Bitmap? = null
    var pendingState: ByteArray? = null
    var progress = 0
    var loading = false
    var desktop = false
}

interface TabListener {
    fun onTabChanged(t: Tab)
    fun onActiveChanged()
}

/**
 * Owns every tab (normal and private in one list; the isHidden flag is the only
 * thing that changes when a tab moves between sections, so nothing is ever deleted).
 */
class TabManager(private val act: MainActivity, private val db: Db) {
    val all = ArrayList<Tab>()
    var active: Tab? = null
    var listener: TabListener? = null

    private val prefs = act.getSharedPreferences("memo_tabs", Context.MODE_PRIVATE)
    private val thumbDir = File(act.filesDir, "thumbs").apply { mkdirs() }
    private val iconDir = File(act.filesDir, "icons").apply { mkdirs() }

    fun normal() = all.filter { !it.isHidden }

    fun restore() {
        for (r in db.tabs()) {
            val t = Tab(r.id, r.title, r.url, r.isHidden)
            t.pendingState = r.state
            all.add(t)
        }
        val id = prefs.getLong("active", -1L)
        active = all.firstOrNull { it.id == id && !it.isHidden }
    }

    private fun persistMeta(t: Tab) = db.saveTab(t.id, t.title, t.url, t.isHidden, all.indexOf(t))

    private fun createTab(url: String, hidden: Boolean): Tab {
        val id = maxOf(System.currentTimeMillis(), (all.maxOfOrNull { it.id } ?: 0L) + 1)
        val t = Tab(id, "", url, hidden)
        all.add(t)
        persistMeta(t)
        return t
    }

    fun newTab(url: String = "", hidden: Boolean = false): Tab {
        val t = createTab(url, hidden)
        activate(t)
        return t
    }

    /** Active tab, creating a blank normal tab if there is none (no listener callback). */
    fun ensureActive(): Tab {
        active?.let { return it }
        val t = normal().lastOrNull() ?: createTab("", false)
        active = t
        return t
    }

    fun activate(t: Tab) {
        val old = active
        if (old != null && old !== t) {
            capture(old)
            old.webView?.onPause()
        }
        active = t
        listener?.onActiveChanged()
    }

    fun load(t: Tab, url: String) {
        t.url = url
        ensureWebView(t).loadUrl(url)
        persistMeta(t)
        listener?.onTabChanged(t)
    }

    fun close(t: Tab) {
        val section = all.filter { it.isHidden == t.isHidden }
        val idx = section.indexOf(t)
        all.remove(t)
        db.deleteTab(t.id)
        File(thumbDir, "${t.id}.jpg").delete()
        File(iconDir, "${t.id}.png").delete()
        t.webView?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        t.webView = null
        if (active === t) {
            val rest = all.filter { it.isHidden == t.isHidden }
            active = rest.getOrNull(idx - 1) ?: rest.firstOrNull() ?: normal().lastOrNull()
            listener?.onActiveChanged()
        }
    }

    /** Moves a tab between sections by flipping its flag. The row, web state and history are kept. */
    fun setHidden(t: Tab, p: Boolean) {
        if (t.isHidden == p) return
        val wasActive = active === t
        t.isHidden = p
        if (p) {
            File(thumbDir, "${t.id}.jpg").delete()
            File(iconDir, "${t.id}.png").delete()
        }
        persistMeta(t)
        if (wasActive && p) {
            active = normal().lastOrNull()
            listener?.onActiveChanged()
        }
    }

    fun reorder(items: List<Tab>) {
        if (items.isEmpty()) return
        val slots = all.indices.filter { all[it].isHidden == items[0].isHidden }
        if (slots.size != items.size) return
        slots.forEachIndexed { i, idx -> all[idx] = items[i] }
        all.forEach { persistMeta(it) }
    }

    // ---- web views ----
    @SuppressLint("SetJavaScriptEnabled")
    fun ensureWebView(t: Tab): WebView {
        t.webView?.let { return it }
        val wv = WebView(act)
        wv.setBackgroundColor(act.getColor(R.color.bg))
        with(wv.settings) {
            javaScriptEnabled = act.prefs.js
            domStorageEnabled = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = false
            textZoom = act.prefs.zoom
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        if (t.desktop) applyDesktop(wv, true)
        wv.webViewClient = client(t)
        wv.webChromeClient = chrome(t)
        wv.setDownloadListener { url, ua, cd, mime, _ -> download(url, ua, cd, mime) }
        t.webView = wv
        val st = t.pendingState
        t.pendingState = null
        var restored = false
        if (st != null) {
            val b = toBundle(st)
            if (b != null) restored = wv.restoreState(b) != null
        }
        if (!restored && t.url.isNotEmpty()) wv.loadUrl(t.url)
        return wv
    }

    private fun changed(t: Tab) { listener?.onTabChanged(t) }

    private fun client(t: Tab) = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
            val u = r.url
            when (u.scheme) {
                "http", "https", "about", "javascript", "data", "blob" -> return false
                "file", "content" -> return true
            }
            if (r.hasGesture()) {
                try {
                    val i = if (u.scheme == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                    else Intent(Intent.ACTION_VIEW, u)
                    i.addCategory(Intent.CATEGORY_BROWSABLE)
                    i.component = null
                    i.selector = null
                    act.startActivity(i)
                } catch (e: Exception) {
                    act.toast("No app found to open this link")
                }
            }
            return true
        }

        override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) {
            t.loading = true
            t.progress = 0
            if (url != null && !url.startsWith("data:")) t.url = url
            changed(t)
        }

        override fun doUpdateVisitedHistory(v: WebView, url: String?, isReload: Boolean) {
            if (url != null && !url.startsWith("data:")) t.url = url
            changed(t)
        }

        override fun onPageFinished(v: WebView, url: String?) {
            t.loading = false
            t.progress = 100
            val title = v.title ?: ""
            if (title.isNotBlank() && title != ERROR_TITLE) t.title = title
            persistMeta(t)
            if (!t.isHidden && title != ERROR_TITLE && url != null &&
                (url.startsWith("http://") || url.startsWith("https://"))
            ) db.addHistory(title.ifBlank { url }, url)
            changed(t)
        }

        override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
            if (!r.isForMainFrame) return
            val d = e.description.toString()
            if (d.contains("ERR_ABORTED") || d.contains("ERR_UNKNOWN_URL_SCHEME")) return
            showError(v, r.url.toString(), d)
        }

        override fun onReceivedSslError(v: WebView, h: SslErrorHandler, e: SslError) {
            h.cancel()
            showError(v, e.url ?: "", "The site's security certificate isn't valid, so the connection was blocked.")
        }
    }

    private fun hex(c: Int) = String.format("#%06X", 0xFFFFFF and c)

    private fun showError(v: WebView, url: String, msg: String) {
        val bg = hex(act.getColor(R.color.bg))
        val fg = hex(act.getColor(R.color.text))
        val dim = hex(act.getColor(R.color.text2))
        val acc = hex(act.getColor(R.color.accent))
        val u = TextUtils.htmlEncode(url)
        val m = TextUtils.htmlEncode(msg)
        val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<title>$ERROR_TITLE</title><style>" +
            "body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;" +
            "font-family:sans-serif;background:$bg;color:$fg;text-align:center}" +
            ".b{max-width:320px;padding:24px}h1{font-size:22px;font-weight:600}" +
            "p{color:$dim;font-size:15px;word-break:break-word}" +
            "a{display:inline-block;margin-top:16px;padding:12px 26px;border-radius:14px;" +
            "background:$acc;color:#1a1a1a;text-decoration:none;font-weight:600}" +
            "</style></head><body><div class='b'><h1>Can&rsquo;t open this page</h1><p>$m</p><p>$u</p>" +
            "<a href=\"$u\">Try again</a></div></body></html>"
        v.loadDataWithBaseURL(url, html, "text/html", "utf-8", url)
    }

    private fun chrome(t: Tab) = object : WebChromeClient() {
        override fun onProgressChanged(v: WebView, p: Int) {
            t.progress = p
            changed(t)
        }

        override fun onReceivedTitle(v: WebView, title: String?) {
            if (!title.isNullOrBlank() && title != ERROR_TITLE) t.title = title
            changed(t)
        }

        override fun onReceivedIcon(v: WebView, icon: Bitmap?) {
            if (icon == null) return
            t.favicon = icon
            if (!t.isHidden) {
                try { save(File(iconDir, "${t.id}.png"), Bitmap.createScaledBitmap(icon, 48, 48, true), Bitmap.CompressFormat.PNG) }
                catch (e: Exception) { }
            }
            changed(t)
        }

        override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            if (!isUserGesture) return false
            val n = createTab("", t.isHidden)
            val wv = ensureWebView(n)
            (resultMsg.obj as WebView.WebViewTransport).webView = wv
            resultMsg.sendToTarget()
            activate(n)
            act.showBrowser()
            return true
        }

        override fun onCloseWindow(window: WebView) {
            all.firstOrNull { it.webView === window }?.let { close(it) }
        }

        override fun onShowFileChooser(
            webView: WebView, cb: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams
        ): Boolean = act.chooseFile(cb, params)

        override fun onShowCustomView(view: View, cb: WebChromeClient.CustomViewCallback) {
            act.showCustomView(view, cb)
        }

        override fun onHideCustomView() { act.hideCustomView() }
    }

    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            act.toast("This kind of download isn't supported"); return
        }
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
            if (mime != null) req.setMimeType(mime)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("cookie", it) }
            if (ua != null) req.addRequestHeader("User-Agent", ua)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            act.toast("Downloading $name")
        } catch (e: Exception) {
            act.toast("Download failed")
        }
    }

    // ---- settings ----
    fun setDesktop(t: Tab, on: Boolean) {
        t.desktop = on
        t.webView?.let { applyDesktop(it, on); it.reload() }
    }

    private fun applyDesktop(wv: WebView, on: Boolean) {
        val s = wv.settings
        s.userAgentString = null
        if (on) s.userAgentString = s.userAgentString.replace(Regex("\\(Linux; Android [^)]*\\)"), "(X11; Linux x86_64)").replace(" Mobile", "")
        s.useWideViewPort = true
        s.loadWithOverviewMode = on
    }

    fun applySettings() {
        for (t in all) t.webView?.settings?.apply {
            javaScriptEnabled = act.prefs.js
            textZoom = act.prefs.zoom
        }
    }

    fun clearData() {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        all.forEach { it.webView?.clearCache(true) }
        db.clearHistory()
    }

    // ---- thumbnails / icons ----
    fun capture(t: Tab) {
        val wv = t.webView ?: return
        if (!wv.isShown || wv.width == 0 || wv.height == 0) return
        try {
            val w = 360
            val h = 480
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
            val c = Canvas(bmp)
            c.drawColor(act.getColor(R.color.bg))
            val s = w.toFloat() / wv.width
            c.scale(s, s)
            wv.draw(c)
            t.thumb = bmp
            if (!t.isHidden) save(File(thumbDir, "${t.id}.jpg"), bmp, Bitmap.CompressFormat.JPEG)
        } catch (e: Exception) { }
    }

    fun thumbOf(t: Tab): Bitmap? = t.thumb
        ?: if (t.isHidden) null else BitmapFactory.decodeFile(File(thumbDir, "${t.id}.jpg").path)?.also { t.thumb = it }

    fun iconOf(t: Tab): Bitmap? = t.favicon
        ?: if (t.isHidden) null else BitmapFactory.decodeFile(File(iconDir, "${t.id}.png").path)?.also { t.favicon = it }

    private fun save(f: File, b: Bitmap, fmt: Bitmap.CompressFormat) {
        FileOutputStream(f).use { b.compress(fmt, 75, it) }
    }

    // ---- persistence ----
    fun saveAll() {
        active?.let { capture(it) }
        all.forEachIndexed { i, t ->
            db.saveTab(t.id, t.title, t.url, t.isHidden, i)
            t.webView?.let { wv ->
                val b = Bundle()
                wv.saveState(b)
                val bytes = toBytes(b)
                if (bytes.size in 1..1_500_000) db.saveTabState(t.id, bytes)
            }
        }
        prefs.edit().putLong("active", active?.id ?: -1L).apply()
    }

    fun destroy() {
        for (t in all) {
            t.webView?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
            t.webView = null
        }
    }

    private fun toBytes(b: Bundle): ByteArray {
        val p = Parcel.obtain()
        try { p.writeBundle(b); return p.marshall() } finally { p.recycle() }
    }

    private fun toBundle(bytes: ByteArray): Bundle? {
        val p = Parcel.obtain()
        return try {
            p.unmarshall(bytes, 0, bytes.size)
            p.setDataPosition(0)
            p.readBundle(TabManager::class.java.classLoader)
        } catch (e: Exception) {
            null
        } finally {
            p.recycle()
        }
    }
}
