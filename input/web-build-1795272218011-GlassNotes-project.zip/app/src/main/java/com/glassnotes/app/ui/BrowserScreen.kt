package com.glassnotes.app.ui

import android.app.DownloadManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import androidx.annotation.RequiresApi
import com.glassnotes.app.MainActivity
import com.glassnotes.app.R
import com.glassnotes.app.web.Tab
import com.glassnotes.app.web.TabListener
import com.glassnotes.app.web.Url

/** Glass-style web view: address pill, home page over a blurred background, slide-up options sheet. */
class BrowserScreen(act: MainActivity) : BScreen(act), TabListener {
    private val tm = act.tabs
    private val bar = EditText(act)
    private val lockIcon = ImageView(act)
    private val reloadBtn = act.iconButton(R.drawable.ic_reload, "Reload", W) { onReload() }
    private val backBtn = act.iconButton(R.drawable.ic_back, "Back", W) {
        tm.active?.webView?.let { if (it.canGoBack()) it.goBack() }
    }
    private val fwdBtn = act.iconButton(R.drawable.ic_forward, "Forward", W) {
        tm.active?.webView?.let { if (it.canGoForward()) it.goForward() }
    }
    private val homeBtn = act.iconButton(R.drawable.ic_home, "Home", W) { toggleHome() }
    private val moreBtn = act.iconButton(R.drawable.ic_chevron_up, "Options", W) { openSheet() }
    private val tabsBtn = TextView(act)
    private val pill = LinearLayout(act)
    private val progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
    private val webFrame = FrameLayout(act)
    private val home = ScrollView(act)
    private val homeBody = LinearLayout(act)
    private val content = FrameLayout(act)
    private val scrim = View(act)
    private val sheet = LinearLayout(act)
    private var homeOverlay = false
    private var sheetOpen = false

    init {
        tm.listener = this
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }

        // ---- top: address pill + settings ----
        val top = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(6))
        }
        lockIcon.imageTintList = ColorStateList.valueOf(W2)
        bar.apply {
            background = null
            textSize = 15f
            typeface = Fonts.get(act)
            isSingleLine = true
            setTextColor(W)
            setHintTextColor(W2)
            hint = "Search or enter address"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setPadding(0, 0, 0, 0)
            setOnEditorActionListener { v, actionId, ev ->
                if (actionId == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                    go(v.text.toString()); true
                } else false
            }
            setOnFocusChangeListener { _, focused ->
                val t = tm.active
                if (focused) { setText(t?.url ?: ""); selectAll() } else setText(Url.display(t?.url ?: ""))
            }
        }
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(14), 0, dp(2), 0)
        pill.addView(lockIcon, LinearLayout.LayoutParams(dp(15), dp(15)))
        pill.addView(bar, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = dp(8) })
        pill.addView(reloadBtn, LinearLayout.LayoutParams(dp(40), dp(40)))
        top.addView(pill, LinearLayout.LayoutParams(0, dp(46), 1f))
        val gear = act.iconButton(R.drawable.ic_settings, "Settings", W) { act.push(BrowserSettingsScreen(act)) }
        gear.background = act.glass(23)
        top.addView(gear, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(8) })
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        progress.max = 100
        progress.progressTintList = ColorStateList.valueOf(act.getColor(R.color.accent))
        progress.visibility = View.GONE
        col.addView(progress, LinearLayout.LayoutParams(MATCH, dp(3)))

        // ---- content: web view + home page ----
        content.addView(webFrame, FrameLayout.LayoutParams(MATCH, MATCH))
        homeBody.orientation = LinearLayout.VERTICAL
        homeBody.gravity = Gravity.CENTER_HORIZONTAL
        homeBody.setPadding(dp(24), dp(40), dp(24), dp(24))
        home.isFillViewport = true
        home.addView(homeBody, FrameLayout.LayoutParams(MATCH, WRAP))
        content.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // ---- bottom: floating glass toolbar with a grabber ----
        val tb = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = act.glass(26)
        }
        val handle = FrameLayout(act)
        handle.addView(View(act).apply { background = act.rounded(Color.argb(110, 255, 255, 255), 2) },
            FrameLayout.LayoutParams(dp(36), dp(4), Gravity.CENTER))
        val gd = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { openSheet(); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -300) openSheet()
                return true
            }
        })
        handle.setOnTouchListener { _, e -> gd.onTouchEvent(e) }
        tb.addView(handle, LinearLayout.LayoutParams(MATCH, dp(16)))
        val row = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        for (v in listOf<View>(backBtn, fwdBtn, homeBtn)) row.addView(v, LinearLayout.LayoutParams(0, dp(44), 1f))
        tabsBtn.apply {
            gravity = Gravity.CENTER
            textSize = 12f
            typeface = Fonts.get(act)
            includeFontPadding = false
            setTextColor(W)
            background = act.rounded(Color.TRANSPARENT, 7, W, 2)
        }
        val tabsWrap = FrameLayout(act).apply { setOnClickListener { act.push(TabsScreen(act)) } }
        tabsWrap.addView(tabsBtn, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        row.addView(tabsWrap, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(moreBtn, LinearLayout.LayoutParams(0, dp(44), 1f))
        tb.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(tb, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(14), dp(4), dp(14), dp(12)) })
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---- slide-up sheet ----
        scrim.setBackgroundColor(Color.argb(110, 0, 0, 0))
        scrim.visibility = View.GONE
        scrim.setOnClickListener { closeSheet() }
        addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        val r = dp(28).toFloat()
        sheet.orientation = LinearLayout.VERTICAL
        sheet.setPadding(dp(14), 0, dp(14), dp(20))
        sheet.background = GradientDrawable().apply {
            setColor(Color.argb(238, 28, 28, 32))
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        sheet.visibility = View.GONE
        sheet.isClickable = true
        addView(sheet, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        rebind()
    }

    override fun onTabChanged(t: Tab) { if (t === tm.active) refreshChrome() }
    override fun onActiveChanged() { rebind() }
    override fun showsPrivate() = tm.active?.isHidden == true

    override fun refresh() {
        backdrop.reload()
        act.setBars(DARK_BAR, false)
        act.setSecure(tm.active?.isHidden == true)
        refreshChrome()
    }

    /** Attach the active tab's WebView (creating a blank tab if needed). */
    fun rebind() {
        val t = tm.ensureActive()
        homeOverlay = false
        (webFrame.getChildAt(0) as? android.webkit.WebView)?.onPause()
        webFrame.removeAllViews()
        if (t.url.isNotEmpty() || t.webView != null) attach(t)
        buildHome(t)
        act.setSecure(t.isHidden)
        refreshChrome()
    }

    private fun attach(t: Tab) {
        val wv = tm.ensureWebView(t)
        if (wv.parent !== webFrame) {
            (wv.parent as? ViewGroup)?.removeView(wv)
            webFrame.removeAllViews()
            webFrame.addView(wv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        wv.onResume()
    }

    private fun go(input: String) {
        val u = Url.resolve(input, act.prefs.engine)
        if (u.isEmpty()) return
        val t = tm.ensureActive()
        bar.clearFocus()
        act.hideKeyboard(bar)
        homeOverlay = false
        tm.load(t, u)
        attach(t)
        refreshChrome()
    }

    private fun onReload() {
        val t = tm.active ?: return
        val wv = t.webView ?: return
        if (t.loading) { wv.stopLoading(); t.loading = false } else wv.reload()
        refreshChrome()
    }

    private fun toggleHome() {
        val t = tm.active ?: return
        if (t.url.isEmpty()) return
        homeOverlay = !homeOverlay
        buildHome(t)
        refreshChrome()
    }

    private fun refreshChrome() {
        val t = tm.active ?: return
        pill.background = act.glass(16, if (t.isHidden) Color.argb(140, 88, 60, 200) else Color.argb(105, 0, 0, 0))
        if (!bar.hasFocus()) {
            val s = Url.display(t.url)
            if (bar.text.toString() != s) bar.setText(s)
        }
        lockIcon.visibility = if (t.url.isEmpty()) View.GONE else View.VISIBLE
        lockIcon.setImageResource(if (t.url.startsWith("https://")) R.drawable.ic_lock else R.drawable.ic_globe)
        reloadBtn.setImageResource(if (t.loading) R.drawable.ic_close else R.drawable.ic_reload)
        progress.visibility = if (t.loading && t.progress in 1..99) View.VISIBLE else View.GONE
        progress.progress = t.progress
        val wv = t.webView
        backBtn.alpha = if (wv?.canGoBack() == true) 1f else 0.35f
        fwdBtn.alpha = if (wv?.canGoForward() == true) 1f else 0.35f
        tabsBtn.text = tm.all.count { !it.isHidden }.toString()
        val showHome = t.url.isEmpty() || homeOverlay
        home.visibility = if (showHome) View.VISIBLE else View.GONE
        webFrame.visibility = if (showHome) View.INVISIBLE else View.VISIBLE
    }

    // ---- home page ----
    private fun buildHome(t: Tab) {
        homeBody.removeAllViews()
        val clock = TextClock(act).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            textSize = 68f
            typeface = Fonts.get(act)
            setTextColor(W)
            gravity = Gravity.CENTER
        }
        val date = TextClock(act).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            textSize = 16f
            typeface = Fonts.get(act)
            setTextColor(W2)
            gravity = Gravity.CENTER
        }
        homeBody.addView(clock, LinearLayout.LayoutParams(WRAP, WRAP))
        homeBody.addView(date, LinearLayout.LayoutParams(WRAP, WRAP).apply { bottomMargin = dp(28) })
        val search = act.labelC("Search or enter address", 15f, W2).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            background = act.glass(26, Color.argb(60, 255, 255, 255), Color.argb(70, 255, 255, 255))
            setOnClickListener { bar.requestFocus(); act.showKeyboard(bar) }
        }
        homeBody.addView(search, LinearLayout.LayoutParams(MATCH, dp(52)))
        if (t.isHidden) {
            homeBody.addView(act.labelC("Hidden tab", 13f, W2).apply { setPadding(0, dp(24), 0, 0) })
            return
        }
        val bms = act.db.bookmarks().take(8)
        if (bms.isEmpty()) {
            homeBody.addView(act.labelC("Bookmarks you add will show up here.", 13f, W2).apply { setPadding(0, dp(28), 0, 0) })
            return
        }
        for (chunk in bms.chunked(4)) {
            val rowV = LinearLayout(act).apply { gravity = Gravity.CENTER }
            for (i in 0 until 4) {
                val b = chunk.getOrNull(i)
                val cell = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                if (b != null) {
                    val name = b.title.ifBlank { Url.display(b.url) }
                    cell.addView(act.labelC(name.take(1).uppercase(), 20f, W, true).apply {
                        gravity = Gravity.CENTER
                        background = act.glass(18, Color.argb(60, 255, 255, 255), Color.argb(70, 255, 255, 255))
                    }, LinearLayout.LayoutParams(dp(56), dp(56)))
                    cell.addView(act.labelC(name, 11f, W).apply {
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        gravity = Gravity.CENTER
                        setPadding(dp(2), dp(6), dp(2), 0)
                    }, LinearLayout.LayoutParams(dp(68), WRAP))
                    cell.setOnClickListener { go(b.url) }
                }
                rowV.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
            homeBody.addView(rowV, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(22) })
        }
    }

    // ---- options sheet ----
    private fun tile(res: Int, label: String, a: () -> Unit): View = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = act.glass(18, Color.argb(34, 255, 255, 255), Color.argb(30, 255, 255, 255))
        setPadding(0, dp(12), 0, dp(10))
        addView(ImageView(act).apply {
            setImageResource(res)
            imageTintList = ColorStateList.valueOf(W)
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        addView(act.labelC(label, 11f, W).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(0, dp(6), 0, 0)
        })
        setOnClickListener { a() }
    }

    private fun buildSheet() {
        val t = tm.active ?: return
        sheet.removeAllViews()
        val handleWrap = FrameLayout(act)
        handleWrap.addView(View(act).apply { background = act.rounded(Color.argb(100, 255, 255, 255), 3) },
            FrameLayout.LayoutParams(dp(40), dp(5), Gravity.CENTER))
        var startY = 0f
        handleWrap.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startY = e.rawY; true }
                MotionEvent.ACTION_MOVE -> { sheet.translationY = maxOf(0f, e.rawY - startY); true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (sheet.translationY > dp(90)) closeSheet()
                    else sheet.animate().translationY(0f).setDuration(150).start()
                    true
                }
                else -> false
            }
        }
        sheet.addView(handleWrap, LinearLayout.LayoutParams(MATCH, dp(32)))

        val tiles = ArrayList<View>()
        tiles.add(tile(R.drawable.ic_add, "New tab") { closeSheet(); tm.newTab() })
        if (!t.isHidden && t.url.isNotEmpty()) {
            val on = act.db.isBookmarked(t.url)
            tiles.add(tile(if (on) R.drawable.ic_star else R.drawable.ic_bookmark, if (on) "Saved" else "Bookmark") {
                act.db.toggleBookmark(t.title.ifBlank { t.url }, t.url)
                buildHome(t)
                buildSheet()
            })
        }
        if (!t.isHidden) {
            tiles.add(tile(R.drawable.ic_bookmark, "Bookmarks") { closeSheet(); act.push(LinkListScreen(act, false)) })
            tiles.add(tile(R.drawable.ic_history, "History") { closeSheet(); act.push(LinkListScreen(act, true)) })
        }
        tiles.add(tile(R.drawable.ic_download, "Downloads") {
            closeSheet()
            try { act.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (e: Exception) { act.toast("No downloads app found") }
        })
        if (t.url.isNotEmpty()) {
            tiles.add(tile(R.drawable.ic_share, "Share") {
                closeSheet()
                act.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, t.url)
                }, null))
            })
            tiles.add(tile(R.drawable.ic_desktop, if (t.desktop) "Mobile site" else "Desktop") {
                closeSheet()
                tm.setDesktop(t, !t.desktop)
            })
        }
        if (t.isHidden) tiles.add(tile(R.drawable.ic_eye_off, "Unhide") { closeSheet(); tm.setHidden(t, false); refreshChrome() })
        else tiles.add(tile(R.drawable.ic_eye_off, "Hide tab") { closeSheet(); tm.setHidden(t, true); act.toast("Tab hidden") })
        tiles.add(tile(R.drawable.ic_settings, "Settings") { closeSheet(); act.push(BrowserSettingsScreen(act)) })
        tiles.add(tile(R.drawable.ic_notes, "Notes") { closeSheet(); act.goHome() })

        for (chunk in tiles.chunked(4)) {
            val rowV = LinearLayout(act)
            for (i in 0 until 4) {
                val v = chunk.getOrNull(i) ?: View(act)
                rowV.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            sheet.addView(rowV, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        sheet.addView(act.slider("Text size", 50, 200, act.prefs.zoom, "%") {
            act.prefs.zoom = it
            tm.applySettings()
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        sheet.addView(act.slider("Background blur", 0, 100, act.prefs.blur, "") {
            act.prefs.blur = it
            backdrop.reload()
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        Fonts.applyTo(sheet)
    }

    private fun openSheet() {
        if (sheetOpen || tm.active == null) return
        buildSheet()
        sheetOpen = true
        scrim.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(200).start()
        sheet.visibility = View.VISIBLE
        sheet.translationY = dp(700).toFloat()
        sheet.animate().translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        blurContent(true)
    }

    private fun closeSheet() {
        if (!sheetOpen) return
        sheetOpen = false
        scrim.animate().alpha(0f).setDuration(180).withEndAction { if (!sheetOpen) scrim.visibility = View.GONE }.start()
        sheet.animate().translationY(sheet.height.toFloat()).setDuration(200)
            .withEndAction { if (!sheetOpen) sheet.visibility = View.GONE }.start()
        blurContent(false)
    }

    private fun blurContent(on: Boolean) { if (Build.VERSION.SDK_INT >= 31) blur31(on) }

    @RequiresApi(31)
    private fun blur31(on: Boolean) {
        content.setRenderEffect(if (on) RenderEffect.createBlurEffect(28f, 28f, Shader.TileMode.CLAMP) else null)
    }

    override fun onBack(): Boolean {
        if (sheetOpen) { closeSheet(); return true }
        if (bar.hasFocus()) {
            bar.clearFocus()
            act.hideKeyboard(bar)
            return true
        }
        val t = tm.active
        if (homeOverlay && t != null && t.url.isNotEmpty()) {
            homeOverlay = false
            refreshChrome()
            return true
        }
        val wv = t?.webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
            return true
        }
        return false
    }

    override fun onDestroyScreen() {
        (webFrame.getChildAt(0) as? android.webkit.WebView)?.let {
            it.onPause()
            webFrame.removeView(it)
        }
        if (tm.listener === this) tm.listener = null
    }
}
