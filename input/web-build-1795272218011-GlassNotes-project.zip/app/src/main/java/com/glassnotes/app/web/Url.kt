package com.glassnotes.app.web

import android.net.Uri

object Url {
    private val ip = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")

    /** Turns whatever was typed into a loadable URL, or a Google search. */
    fun resolve(input: String, engine: Int = 0): String {
        val s = input.trim()
        if (s.isEmpty()) return ""
        if (s.startsWith("http://") || s.startsWith("https://")) return s
        if (ip.matches(s) || s.startsWith("localhost")) return "http://$s"
        if (!s.contains(' ') && s.contains('.') && !s.endsWith(".")) return "https://$s"
        val base = when (engine) {
            1 -> "https://duckduckgo.com/?q="
            2 -> "https://www.bing.com/search?q="
            else -> "https://www.google.com/search?q="
        }
        return base + Uri.encode(s)
    }

    fun display(url: String): String {
        if (url.isEmpty()) return ""
        val host = Uri.parse(url).host ?: return url
        return host.removePrefix("www.")
    }
}
